// HTLK — API auxiliar do Vistas Defender 27K6.
// A varredura delega para o Microsoft Defender instalado; não é um scanner próprio.
#define HTLK_BUILD
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "htlk_api.h"
#include <shlobj.h>
#include <wintrust.h>
#include <softpub.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <filesystem>
#include <string>
#include <vector>
#include <algorithm>
#include <mutex>
#include <atomic>
#include <cwctype>
#include <climits>
#include <cstring>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "crypt32.lib")

namespace fs = std::filesystem;
static std::atomic_bool g_initialized{ false };
static std::atomic_bool g_cancelRequested{ false };
static std::mutex g_processMutex;
static std::mutex g_scanMutex;
static std::atomic_bool g_scanActive{ false };
static HANDLE g_activeScanProcess = nullptr; // Borrowed while protected by g_processMutex.
static constexpr wchar_t kProductVersion[] = L"27K6";
static constexpr DWORD kAbiVersion = 1;
static constexpr DWORD kScanWaitMs = 691200000UL; // 8 days, after the 7-day MpCmdRun custom-scan timeout.

static bool CopyOut(const std::wstring& value, wchar_t* output, DWORD capacity) {
    if (!output || capacity == 0 || value.size() + 1 > capacity) {
        if (output && capacity) output[0] = L'\0';
        SetLastError(ERROR_INSUFFICIENT_BUFFER);
        return false;
    }
    memcpy(output, value.c_str(), (value.size() + 1) * sizeof(wchar_t));
    return true;
}

static std::wstring Lower(std::wstring value) {
    if (!value.empty()) CharLowerBuffW(value.data(), static_cast<DWORD>(value.size()));
    return value;
}

static bool IsSuccessfulAuthenticode(const std::wstring& path) {
    WINTRUST_FILE_INFO file{};
    file.cbStruct = sizeof(file);
    file.pcwszFilePath = path.c_str();
    WINTRUST_DATA data{};
    data.cbStruct = sizeof(data);
    data.dwUIChoice = WTD_UI_NONE;
    data.fdwRevocationChecks = WTD_REVOKE_NONE;
    data.dwUnionChoice = WTD_CHOICE_FILE;
    data.pFile = &file;
    data.dwStateAction = WTD_STATEACTION_VERIFY;
    data.dwProvFlags = WTD_CACHE_ONLY_URL_RETRIEVAL;
    GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    const LONG status = WinVerifyTrust(nullptr, &action, &data);
    data.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(nullptr, &action, &data);
    // WinVerifyTrust documents ERROR_SUCCESS (exactly zero) as the only success.
    if (status != ERROR_SUCCESS) return false;

    HCERTSTORE store = nullptr;
    HCRYPTMSG message = nullptr;
    DWORD encoding = 0, contentType = 0, formatType = 0;
    if (!CryptQueryObject(CERT_QUERY_OBJECT_FILE, path.c_str(),
            CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY, 0,
            &encoding, &contentType, &formatType, &store, &message, nullptr)) {
        return false;
    }
    bool microsoftOrg = false;
    bool sha256Signer = false;
    DWORD signerBytes = 0;
    if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, nullptr, &signerBytes)) {
        std::vector<BYTE> signerBuffer(signerBytes);
        if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, signerBuffer.data(), &signerBytes)) {
            auto signer = reinterpret_cast<PCMSG_SIGNER_INFO>(signerBuffer.data());
            sha256Signer = signer->HashAlgorithm.pszObjId &&
                strcmp(signer->HashAlgorithm.pszObjId, szOID_NIST_sha256) == 0;
            CERT_INFO find{};
            find.Issuer = signer->Issuer;
            find.SerialNumber = signer->SerialNumber;
            PCCERT_CONTEXT cert = CertFindCertificateInStore(
                store, encoding, 0, CERT_FIND_SUBJECT_CERT, &find, nullptr);
            if (cert) {
                wchar_t org[256]{};
                DWORD n = CertGetNameStringW(cert, CERT_NAME_ATTR_TYPE, 0,
                    const_cast<LPSTR>(szOID_ORGANIZATION_NAME), org, _countof(org));
                if (n > 1 && _wcsicmp(org, L"Microsoft Corporation") == 0)
                    microsoftOrg = true;
                CertFreeCertificateContext(cert);
            }
        }
    }
    if (store) CertCloseStore(store, 0);
    if (message) CryptMsgClose(message);
    return microsoftOrg && sha256Signer;
}

static std::wstring GetKnownFolderPath(REFKNOWNFOLDERID id) {
    PWSTR raw = nullptr;
    if (FAILED(SHGetKnownFolderPath(id, KF_FLAG_DEFAULT, nullptr, &raw)) || !raw)
        return L"";
    std::wstring out(raw);
    CoTaskMemFree(raw);
    return out;
}

static bool ParseVersionTuple(const std::wstring& input, std::vector<unsigned long long>& out) {
    out.clear();
    size_t i = 0;
    while (i < input.size()) {
        while (i < input.size() && !iswdigit(input[i])) ++i;
        if (i == input.size()) break;
        unsigned long long value = 0;
        while (i < input.size() && iswdigit(input[i])) {
            const unsigned digit = static_cast<unsigned>(input[i] - L'0');
            if (value > (ULLONG_MAX - digit) / 10) return false;
            value = value * 10 + digit;
            ++i;
        }
        out.push_back(value);
    }
    return !out.empty();
}

static std::wstring LocateTrustedMpCmdRun() {
    const std::wstring programData = GetKnownFolderPath(FOLDERID_ProgramData);
    const std::wstring programFiles = GetKnownFolderPath(FOLDERID_ProgramFiles);
    const std::wstring programFilesX86 = GetKnownFolderPath(FOLDERID_ProgramFilesX86);
    std::vector<fs::path> candidates;
    if (!programData.empty()) {
        fs::path platform = fs::path(programData) / L"Microsoft" / L"Windows Defender" / L"Platform";
        std::error_code ec;
        std::vector<std::pair<std::vector<unsigned long long>, fs::path>> versions;
        if (fs::exists(platform, ec) && !ec) {
            for (fs::directory_iterator it(platform, ec), end; !ec && it != end; it.increment(ec)) {
                std::error_code itemError;
                if (!it->is_directory(itemError) || itemError) continue;
                std::vector<unsigned long long> tuple;
                if (ParseVersionTuple(it->path().filename().wstring(), tuple))
                    versions.emplace_back(std::move(tuple), it->path() / L"MpCmdRun.exe");
            }
        }
        std::sort(versions.begin(), versions.end(), [](const auto& a, const auto& b) {
            const size_t n = (std::max)(a.first.size(), b.first.size());
            for (size_t i = 0; i < n; ++i) {
                const auto av = i < a.first.size() ? a.first[i] : 0;
                const auto bv = i < b.first.size() ? b.first[i] : 0;
                if (av != bv) return av > bv;
            }
            return a.second.wstring() > b.second.wstring();
        });
        for (const auto& item : versions) candidates.push_back(item.second);
    }
    if (!programFiles.empty()) {
        candidates.push_back(fs::path(programFiles) / L"Windows Defender" / L"MpCmdRun.exe");
        candidates.push_back(fs::path(programFiles) / L"Microsoft Security Client" / L"Antimalware" / L"MpCmdRun.exe");
        candidates.push_back(fs::path(programFiles) / L"Microsoft Security Client" / L"MpCmdRun.exe");
    }
    if (!programFilesX86.empty()) {
        candidates.push_back(fs::path(programFilesX86) / L"Microsoft Security Client" / L"Antimalware" / L"MpCmdRun.exe");
        candidates.push_back(fs::path(programFilesX86) / L"Microsoft Security Client" / L"MpCmdRun.exe");
    }
    for (const fs::path& candidate : candidates) {
        std::error_code ec;
        if (!fs::is_regular_file(candidate, ec) || ec) continue;
        const std::wstring value = candidate.wstring();
        if (IsSuccessfulAuthenticode(value)) return value;
    }
    return L"";
}

static std::wstring QuoteArg(const std::wstring& value) {
    std::wstring out = L"\"";
    size_t slashes = 0;
    for (wchar_t c : value) {
        if (c == L'\\') { ++slashes; continue; }
        if (c == L'\"') {
            out.append(slashes * 2 + 1, L'\\');
            out.push_back(c);
            slashes = 0;
            continue;
        }
        out.append(slashes, L'\\');
        slashes = 0;
        out.push_back(c);
    }
    out.append(slashes * 2, L'\\');
    out.push_back(L'\"');
    return out;
}

static bool ResolveLocalScanPath(const wchar_t* requested, std::wstring& result) {
    if (!requested || !requested[0]) { SetLastError(ERROR_INVALID_PARAMETER); return false; }
    std::wstring raw(requested);
    if (raw.size() > 32760 || raw.rfind(L"\\\\.\\", 0) == 0 ||
        Lower(raw).rfind(L"\\\\?\\globalroot", 0) == 0 ||
        raw.rfind(L"\\\\?\\", 0) == 0 || raw.rfind(L"\\\\", 0) == 0) {
        SetLastError(ERROR_INVALID_NAME);
        return false;
    }
    DWORD needed = GetFullPathNameW(raw.c_str(), 0, nullptr, nullptr);
    if (!needed || needed > 32760) return false;
    std::vector<wchar_t> full(needed + 2);
    DWORD written = GetFullPathNameW(raw.c_str(), static_cast<DWORD>(full.size()), full.data(), nullptr);
    if (!written || written >= full.size()) return false;
    result.assign(full.data(), written);
    DWORD attrs = GetFileAttributesW(result.c_str());
    if (attrs == INVALID_FILE_ATTRIBUTES) return false;
    // Require a drive path; reject UNC/device namespaces and ambiguous paths.
    if (result.size() < 3 || !iswalpha(result[0]) || result[1] != L':' || result[2] != L'\\') {
        SetLastError(ERROR_INVALID_NAME);
        return false;
    }
    return true;
}

static void SetResultMessage(HTLK_SCAN_RESULT* r, const std::wstring& text) {
    if (!r) return;
    wcsncpy_s(r->message, _countof(r->message), text.c_str(), _TRUNCATE);
}

struct ActiveScanGuard {
    ActiveScanGuard() { g_scanActive.store(true, std::memory_order_release); }
    ~ActiveScanGuard() { g_scanActive.store(false, std::memory_order_release); }
};

BOOL WINAPI Htlk_Initialize(void) {
    g_initialized.store(true, std::memory_order_release);
    return TRUE;
}

DWORD WINAPI Htlk_GetVersion(void) { return kAbiVersion; }
BOOL WINAPI Htlk_IsInitialized(void) { return g_initialized.load(std::memory_order_acquire) ? TRUE : FALSE; }
void WINAPI Htlk_Shutdown(void) { g_initialized.store(false, std::memory_order_release); }

BOOL WINAPI Htlk_GetProductVersionW(wchar_t* output, DWORD outputCharacters) {
    return CopyOut(kProductVersion, output, outputCharacters) ? TRUE : FALSE;
}
BOOL WINAPI Htlk_GetBuildInfoW(wchar_t* output, DWORD outputCharacters) {
    const std::wstring info = std::wstring(L"Vistas Defender ") + kProductVersion +
        L"; HTLK ABI " + std::to_wstring(kAbiVersion) + L"; revision 27K6-RC1";
    return CopyOut(info, output, outputCharacters) ? TRUE : FALSE;
}
BOOL WINAPI Htlk_GetCapabilitiesW(wchar_t* output, DWORD outputCharacters) {
    return CopyOut(L"product-version;build-info;capabilities;authenticated-MpCmdRun-path;custom-disk-scan;cancel-scan", output, outputCharacters) ? TRUE : FALSE;
}
BOOL WINAPI Htlk_GetMpCmdRunPathW(wchar_t* output, DWORD outputCharacters) {
    const std::wstring path = LocateTrustedMpCmdRun();
    if (path.empty()) { SetLastError(ERROR_FILE_NOT_FOUND); if (output && outputCharacters) output[0] = 0; return FALSE; }
    return CopyOut(path, output, outputCharacters) ? TRUE : FALSE;
}

BOOL WINAPI Htlk_ScanPathW(const wchar_t* requestedPath, HTLK_SCAN_RESULT* result) {
    if (!result || result->cbSize < sizeof(HTLK_SCAN_RESULT)) { SetLastError(ERROR_INVALID_PARAMETER); return FALSE; }
    const DWORD requestedSize = result->cbSize;
    ZeroMemory(result, sizeof(*result));
    result->cbSize = requestedSize;
    result->status = HTLK_SCAN_UNAVAILABLE;
    if (!g_initialized.load(std::memory_order_acquire)) {
        result->status = HTLK_SCAN_FAILED; result->win32Error = ERROR_INVALID_STATE;
        SetResultMessage(result, L"HTLK não foi inicializada."); return FALSE;
    }

    std::unique_lock<std::mutex> scanLock(g_scanMutex, std::try_to_lock);
    if (!scanLock.owns_lock()) {
        result->status = HTLK_SCAN_FAILED; result->win32Error = ERROR_BUSY;
        SetResultMessage(result, L"Outra verificação já está em andamento."); return FALSE;
    }
    g_cancelRequested.store(false, std::memory_order_release);
    ActiveScanGuard activeScanGuard;

    std::wstring scanPath;
    if (!ResolveLocalScanPath(requestedPath, scanPath)) {
        result->status = HTLK_SCAN_FAILED; result->win32Error = GetLastError();
        SetResultMessage(result, L"Caminho inválido, inacessível ou fora de um volume local suportado."); return FALSE;
    }
    const std::wstring scanner = LocateTrustedMpCmdRun();
    if (scanner.empty()) {
        result->status = HTLK_SCAN_UNAVAILABLE; result->win32Error = ERROR_FILE_NOT_FOUND;
        SetResultMessage(result, L"Não foi encontrado um MpCmdRun.exe confiável da Microsoft. Nenhuma conclusão de segurança foi feita."); return FALSE;
    }
    wcsncpy_s(result->scannerPath, _countof(result->scannerPath), scanner.c_str(), _TRUNCATE);

    std::wstring args = L"-Scan -ScanType 3 -File " + QuoteArg(scanPath) + L" -Timeout 7";
    const DWORD attrs = GetFileAttributesW(scanPath.c_str());
    if ((attrs & FILE_ATTRIBUTE_DIRECTORY) && scanPath.size() == 3 && scanPath[1] == L':')
        args += L" -BootSectorScan";
    std::wstring commandLine = QuoteArg(scanner) + L" " + args;
    std::vector<wchar_t> mutableLine(commandLine.begin(), commandLine.end());
    mutableLine.push_back(L'\0');

    STARTUPINFOW startup{}; startup.cb = sizeof(startup); startup.dwFlags = STARTF_USESHOWWINDOW; startup.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    if (g_cancelRequested.load(std::memory_order_acquire)) {
        result->status = HTLK_SCAN_CANCELLED;
        SetResultMessage(result, L"Verificação cancelada antes de iniciar.");
        return FALSE;
    }
    if (!CreateProcessW(scanner.c_str(), mutableLine.data(), nullptr, nullptr, FALSE,
        CREATE_NO_WINDOW, nullptr, nullptr, &startup, &pi)) {
        result->status = HTLK_SCAN_FAILED; result->win32Error = GetLastError();
        SetResultMessage(result, L"Não foi possível iniciar o Microsoft Defender. Verifique elevação/permissões."); return FALSE;
    }
    CloseHandle(pi.hThread);
    {
        std::lock_guard<std::mutex> lock(g_processMutex);
        g_activeScanProcess = pi.hProcess;
        if (g_cancelRequested.load(std::memory_order_acquire))
            TerminateProcess(g_activeScanProcess, ERROR_CANCELLED);
    }
    const DWORD wait = WaitForSingleObject(pi.hProcess, kScanWaitMs);
    if (wait == WAIT_TIMEOUT) {
        TerminateProcess(pi.hProcess, ERROR_TIMEOUT);
        WaitForSingleObject(pi.hProcess, 3000);
        result->status = HTLK_SCAN_TIMED_OUT; result->win32Error = WAIT_TIMEOUT;
        SetResultMessage(result, L"A verificação excedeu o limite de 8 dias; resultado inconclusivo.");
    } else if (wait != WAIT_OBJECT_0) {
        result->status = HTLK_SCAN_FAILED; result->win32Error = GetLastError();
        SetResultMessage(result, L"Não foi possível aguardar o mecanismo antimalware.");
    } else {
        DWORD exitCode = ERROR_GEN_FAILURE;
        if (!GetExitCodeProcess(pi.hProcess, &exitCode)) {
            result->status = HTLK_SCAN_FAILED; result->win32Error = GetLastError();
            SetResultMessage(result, L"Não foi possível obter o resultado do mecanismo.");
        } else {
            result->exitCode = exitCode;
            if (g_cancelRequested.load(std::memory_order_acquire)) {
                result->status = HTLK_SCAN_CANCELLED;
                SetResultMessage(result, L"Verificação cancelada; nenhum resultado de segurança é inferido.");
            } else if (exitCode == 0) {
                result->status = HTLK_SCAN_COMPLETED;
                SetResultMessage(result, L"Comando de verificação concluído (código 0). Isso não garante ausência absoluta: o Defender pode ter remediado itens; confira o Histórico de proteção.");
            } else if (exitCode == 2) {
                result->status = HTLK_SCAN_ATTENTION_REQUIRED;
                SetResultMessage(result, L"O Defender retornou código 2: pode ser ameaça não remediada, ação do usuário necessária ou erro de verificação. Confira o Histórico de proteção.");
            } else {
                result->status = HTLK_SCAN_FAILED;
                result->win32Error = ERROR_GEN_FAILURE;
                SetResultMessage(result, L"A verificação terminou com um código não reconhecido; resultado inconclusivo.");
            }
        }
    }
    {
        std::lock_guard<std::mutex> lock(g_processMutex);
        if (g_activeScanProcess == pi.hProcess) g_activeScanProcess = nullptr;
    }
    CloseHandle(pi.hProcess);
    return result->status == HTLK_SCAN_COMPLETED ? TRUE : FALSE;
}

BOOL WINAPI Htlk_CancelScan(void) {
    if (!g_scanActive.load(std::memory_order_acquire)) return FALSE;
    std::lock_guard<std::mutex> lock(g_processMutex);
    // Cancellation may arrive while the scanner is being located/launched. In that
    // case the request stays latched and Htlk_ScanPathW checks it before/after launch.
    if (!g_activeScanProcess) {
        g_cancelRequested.store(true, std::memory_order_release);
        return TRUE;
    }
    DWORD processExit = STILL_ACTIVE;
    if (GetExitCodeProcess(g_activeScanProcess, &processExit) && processExit != STILL_ACTIVE)
        return FALSE; // The scan ended already; do not relabel a completed result as cancelled.
    g_cancelRequested.store(true, std::memory_order_release);
    return TerminateProcess(g_activeScanProcess, ERROR_CANCELLED);
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    UNREFERENCED_PARAMETER(instance); UNREFERENCED_PARAMETER(reserved);
    if (reason == DLL_PROCESS_DETACH) g_initialized.store(false, std::memory_order_release);
    return TRUE;
}
