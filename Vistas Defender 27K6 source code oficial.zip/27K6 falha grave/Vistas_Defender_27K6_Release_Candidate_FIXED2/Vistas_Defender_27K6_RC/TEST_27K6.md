# Plano de regressão 27K6

**Não marque nenhum teste como aprovado sem executá-lo na máquina Windows alvo.** Teste inicialmente numa VM ou máquina de laboratório com snapshot, não num computador cuja disponibilidade seja crítica.

## Build e integridade

- [ ] Execute `BUILD_27K6.bat` no Developer Command Prompt com MSVC/SDK, confira código de saída zero e existência dos cinco binários em `bin\`.
- [ ] Assine todos os binários com o certificado válido; verifique que publicador é exatamente `OArthurMamaco Security`, Authenticode retorna `ERROR_SUCCESS` e algoritmo de digestão é SHA-256.
- [ ] Confirme que `htlk.dll` expõe `Htlk_GetVersion`, `Htlk_GetProductVersionW`, `Htlk_GetBuildInfoW`, `Htlk_GetCapabilitiesW`, `Htlk_GetMpCmdRunPathW`, `Htlk_ScanPathW` e `Htlk_CancelScan`.
- [ ] Confirme que a API rejeita HTLK ausente, sem assinatura, publicador incorreto, ABI incompatível e versão de produto diferente.
- [ ] Confirme que verificação local de componentes não apresenta a versão local como versão remota atual.

## Interface e preferências

- [ ] Inicie `VistasUI.exe`; confirme pedido/elevacão de administrador, navegação e ausência de travamento.
- [ ] Alterne Português, English e Español; confirme botões, títulos e páginas principais e anote qualquer texto herdado sem tradução.
- [ ] Reinicie UI e confirme idioma/configurações persistidos.
- [ ] Em modo equilibrado, inicie aplicativos assinados conhecidos, aplicativos assinados não-Microsoft e executáveis sem assinatura; verifique os eventos e decisões.
- [ ] Em modo observação, confirme que evidência ambígua não gera bloqueio preventivo e que isso está claro na UI.
- [ ] Em modo rigoroso, confirme que prompts podem ocorrer para vários processos não protegidos; verifique que há saída de recuperação e que os processos do sistema enumerados não são interrompidos.

## Falsos positivos de processos do Windows

- [ ] Verifique processos reais `TrustedInstaller.exe` em `Windows\servicing`, `svchost.exe` em `Windows\System32`/`SysWOW64`, `explorer.exe` no diretório Windows, e `MsMpEng.exe`/`MpCmdRun.exe` no diretório canônico da plataforma Defender. Confirme assinatura Microsoft válida e que não entram no cativeiro.
- [ ] Coloque uma cópia renomeada de um executável em pasta temporária de teste (não como serviço) e confirme que o nome sozinho não concede exceção.
- [ ] Modifique/corrompa uma cópia de teste de binário protegido e confirme que falha a validação de assinatura; nunca substitua arquivos reais do Windows para testar.
- [ ] Teste em Windows com Microsoft Defender ativo, inativo, com exclusões e com assinatura atualizada; estados indisponíveis/inconclusivos não devem ser reportados como malware confirmado.

## HTLK / varredura de disco

- [ ] Selecione uma pasta de teste local pequena e confira início, mensagem final, log e ausência de congelamento da UI.
- [ ] Execute uma varredura de um volume de laboratório com confirmação prévia; verifique o Histórico de proteção do Microsoft Defender.
- [ ] Teste caminhos inexistentes, UNC, `\\.\`, `\\?\GLOBALROOT` e pasta de rede; devem falhar sem alegar que o caminho está limpo.
- [ ] Teste sem Microsoft Defender/MpCmdRun disponível ou se assinatura não puder ser verificada; resultado esperado é indisponível/falha, nunca sucesso.
- [ ] Feche a UI durante a varredura; confirme cancelamento best-effort, ausência de use-after-free e que o cancelamento não seja registrado como resultado limpo.
- [ ] Verifique que duas chamadas de varredura simultâneas são recusadas com `ERROR_BUSY`.
- [ ] Compare os códigos de retorno do MpCmdRun com o Histórico de proteção: código 0 deve ser descrito como conclusão do comando/sem ação pendente reportada, nunca como prova de que não houve detecção; código 2 deve permanecer “atenção necessária/resultado ambíguo”.
- [ ] Em modo equilibrado, confirme que um caminho excluído no Microsoft Defender não é automaticamente considerado limpo e solicita decisão, pois não houve análise do caminho.

## Agendamentos

- [ ] Habilite/desabilite verificação ao iniciar e confirme tarefa `VistasDefender-StartupScan` em Task Scheduler.
- [ ] Selecione um, vários e todos os dias; confira `VistasDefender-WeeklyScan` e horário de 03:00.
- [ ] Desative todas as opções e confirme que as tarefas sejam removidas; se Task Scheduler negar acesso/falhar, a UI deve exibir erro em vez de declarar que foi desativado.
- [ ] Simule falha de permissão/política do Agendador de Tarefas; a UI deve mostrar falha em vez de sucesso.
- [ ] Depois de atualizar a plataforma do Microsoft Defender, abra a UI e confirme que o caminho das tarefas está atual; verifique o histórico do Task Scheduler.

## Visne / regras de caminho

- [ ] Manifesto ausente, truncado ou inválido não deve apagar as regras anteriormente carregadas nem indicar sucesso.
- [ ] Teste nome exato, caminho completo e wildcard explicitamente documentado.
- [ ] Confirme que padrões como `app.exe` não correspondem por substring a `app.exe.backup`.
- [ ] Teste 0 regras, excesso de linhas/comprimentos e caracteres de controle; falha sem corromper estado anterior.
