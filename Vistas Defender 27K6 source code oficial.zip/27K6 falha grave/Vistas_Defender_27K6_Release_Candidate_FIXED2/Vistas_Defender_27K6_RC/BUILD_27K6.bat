@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where cl >nul 2>nul
if errorlevel 1 (
  echo ERRO: execute este arquivo no Developer Command Prompt do Visual Studio.
  exit /b 1
)

if not exist bin mkdir bin
if not exist bin\obj mkdir bin\obj

echo [1/5] Compilando htlk.dll...
cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE /utf-8 /LD htlk.cpp /Fo"bin\obj\htlk.obj" /Fe"bin\htlk.dll" /link /IMPLIB:"bin\htlk.lib" shell32.lib ole32.lib wintrust.lib crypt32.lib user32.lib
if errorlevel 1 exit /b 1

echo [2/5] Compilando Visne.dll...
cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE /utf-8 /LD Visne.cpp /Fo"bin\obj\Visne.obj" /Fe"bin\Visne.dll" /link /IMPLIB:"bin\Visne.lib" user32.lib wintrust.lib crypt32.lib
if errorlevel 1 exit /b 1

echo [3/5] Compilando Update.dll...
cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE /utf-8 /LD Update.cpp /Fo"bin\obj\Update.obj" /Fe"bin\Update.dll" /link /IMPLIB:"bin\Update.lib" wininet.lib shell32.lib crypt32.lib wintrust.lib bcrypt.lib
if errorlevel 1 exit /b 1

echo [4/5] Compilando Defender.exe...
cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE /utf-8 Defender.cpp /Fo"bin\obj\Defender.obj" /Fe"bin\Defender.exe" /link /SUBSYSTEM:WINDOWS advapi32.lib bcrypt.lib crypt32.lib wintrust.lib comctl32.lib wbemuuid.lib ole32.lib oleaut32.lib shell32.lib user32.lib gdi32.lib
if errorlevel 1 exit /b 1

echo [5/5] Compilando VistasUI.exe...
cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE /utf-8 VistasUI.cpp /Fo"bin\obj\VistasUI.obj" /Fe"bin\VistasUI.exe" /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib shell32.lib advapi32.lib crypt32.lib wintrust.lib ole32.lib oleaut32.lib taskschd.lib
if errorlevel 1 exit /b 1

echo.
echo BUILD 27K6 concluido. Binarios foram colocados em bin\.
echo IMPORTANTE: os binarios ainda precisam ser assinados com o certificado valido configurado para OArthurMamaco Security.
echo Nao distribua a build sem verificar o certificado, o thumbprint em Update.cpp e o conjunto de testes TEST_27K6.md.
exit /b 0
