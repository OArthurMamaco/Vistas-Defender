#pragma once
#ifndef VISTAS_DEFENDER_HTLK_API_H
#define VISTAS_DEFENDER_HTLK_API_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#ifdef HTLK_BUILD
#define HTLK_API __declspec(dllexport)
#else
#define HTLK_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

enum HTLK_SCAN_STATUS : DWORD {
    HTLK_SCAN_COMPLETED = 0,          // Command completed; not an absolute "clean" guarantee.
    HTLK_SCAN_ATTENTION_REQUIRED = 1, // MpCmdRun exit code 2 is ambiguous by Microsoft documentation.
    HTLK_SCAN_FAILED = 2,
    HTLK_SCAN_TIMED_OUT = 3,
    HTLK_SCAN_UNAVAILABLE = 4,
    HTLK_SCAN_CANCELLED = 5
};

struct HTLK_SCAN_RESULT {
    DWORD cbSize;
    DWORD status;
    DWORD exitCode;
    DWORD win32Error;
    wchar_t scannerPath[MAX_PATH];
    wchar_t message[640];
};

HTLK_API BOOL WINAPI Htlk_Initialize(void);
HTLK_API DWORD WINAPI Htlk_GetVersion(void); // Stable ABI version.
HTLK_API BOOL WINAPI Htlk_IsInitialized(void);
HTLK_API void WINAPI Htlk_Shutdown(void);
HTLK_API BOOL WINAPI Htlk_GetProductVersionW(wchar_t* output, DWORD outputCharacters);
HTLK_API BOOL WINAPI Htlk_GetBuildInfoW(wchar_t* output, DWORD outputCharacters);
HTLK_API BOOL WINAPI Htlk_GetCapabilitiesW(wchar_t* output, DWORD outputCharacters);
HTLK_API BOOL WINAPI Htlk_GetMpCmdRunPathW(wchar_t* output, DWORD outputCharacters);
HTLK_API BOOL WINAPI Htlk_ScanPathW(const wchar_t* path, HTLK_SCAN_RESULT* result);
HTLK_API BOOL WINAPI Htlk_CancelScan(void);

#ifdef __cplusplus
}
#endif
#endif
