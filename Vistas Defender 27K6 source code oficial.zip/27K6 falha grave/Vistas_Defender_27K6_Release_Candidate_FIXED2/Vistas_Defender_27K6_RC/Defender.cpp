// ============================================================================
// Vistas Defender 27K6 - OArthurMamaco Security
// Feito por Arthur Carvalho Rodrigues da Silva
// Windows 7 SP1 ate Windows 11
//
// Recursos:
//  - Detecta a versao real do Windows com RtlGetVersion.
//  - Eventos WMI Win32_ProcessStartTrace (fallback: varredura de 100 ms).
//  - Contencao adaptativa: processos suspeitos entram em cativeiro sem congelamento preventivo.
//  - Cativeiro kernel-enforced com Job Object, kill-on-close, sem breakaway e limite de processos.
//  - Pesquisa manual na Internet antes da decisao sobre um processo desconhecido.
//  - Adaptador para Microsoft Defender / Microsoft Security Essentials.
//  - Resultado de analise detalhado.
//  - Permissao temporaria por PID e confianca persistente por hash.
//  - Politica de descendentes: nenhum, mesma pasta, todos.
//  - Defender.dnt: lista autenticada de internos ignorados e permissões permanentes.
//  - Banco binario autenticado com HMAC-SHA256 e chave protegida por DPAPI.
//  - Gravacao atomica, backup e ACL para SYSTEM/Administradores.
//  - Quarentena DPAPI com metadados e verificacao contra troca de arquivo.
//  - Fronteira de comunicacao endurecida: restricao de handles do Job Object; named pipes/COM genericos nao sao
//    tratados como bloqueados, pois isso exige politicas especificas do recurso.
//
// Compilacao (Developer Command Prompt do Visual Studio):
//   cl /nologo /std:c++17 /EHsc /O2 /DUNICODE /D_UNICODE Defender.cpp ^
//      /link /SUBSYSTEM:WINDOWS advapi32.lib bcrypt.lib crypt32.lib ^
//      wintrust.lib comctl32.lib wbemuuid.lib ole32.lib oleaut32.lib ^
//      shell32.lib user32.lib gdi32.lib
// ============================================================================

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <winternl.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <tlhelp32.h>
#include <wintrust.h>
#include <softpub.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <sddl.h>
#include <aclapi.h>
#include <wbemidl.h>
#include <comdef.h>
#include <commctrl.h>
#include <netfw.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cwctype>
#include <climits>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <stdexcept>
#include <thread>
#include <vector>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")

namespace fs = std::filesystem;

namespace vd {

// -----------------------------------------------------------------------------
// Constantes e modelos
// -----------------------------------------------------------------------------

constexpr wchar_t kEngineMutex[] = L"Global\\Macrobyte.VistasDefender.Engine.v8";
constexpr wchar_t kProductName[] = L"Vistas Defender 27K6";
constexpr DWORD kScanTimeoutMs = 45000;
constexpr DWORD kFallbackPollingMs = 1000;
constexpr DWORD kCaptiveIntegrityCheckMs = 500;
constexpr DWORD kDatabaseVersion = 6;
constexpr wchar_t kSettingsRegistryKey[] = L"SOFTWARE\\OArthurMamaco\\Vistas Defender";
constexpr UINT WM_VD_DECISION = WM_APP + 91;

enum class WindowsFamily : uint32_t {
    Unsupported,
    Windows7,
    Windows8,
    Windows81,
    Windows10,
    Windows11
};

struct WindowsVersion {
    WindowsFamily family = WindowsFamily::Unsupported;
    DWORD major = 0;
    DWORD minor = 0;
    DWORD build = 0;
    WORD servicePackMajor = 0;
    bool isServer = false;
    std::wstring displayName;
};

enum class NativeDefenderResult : uint32_t {
    ScanCompleted,
    Excluded,
    AttentionRequired,
    ScanFailed,
    Timeout,
    Unavailable
};

struct NativeDefenderScanResult {
    NativeDefenderResult result = NativeDefenderResult::Unavailable;
    DWORD exitCode = ERROR_GEN_FAILURE;
    DWORD win32Error = ERROR_SUCCESS;
    std::wstring details;
    std::wstring enginePath;
    std::wstring commandDescription;
};

enum class DescendantPolicy : uint32_t {
    None = 0,
    SameExecutableDirectory = 1,
    AllDescendants = 2
};

enum class TrustRecordKind : uint32_t {
    PermanentAllow = 0,
    InternalIgnore = 1
};

enum class UserDecision : uint32_t {
    AllowOnce,
    AllowAlways,
    Quarantine,
    Terminate
};

struct ProcessInfo {
    DWORD pid = 0;
    DWORD parentPid = 0;
    std::wstring path;
    std::wstring parentPath;
};

struct FileId {
    DWORD volumeSerial = 0;
    DWORD indexHigh = 0;
    DWORD indexLow = 0;

    bool operator==(const FileId& other) const {
        return volumeSerial == other.volumeSerial &&
               indexHigh == other.indexHigh &&
               indexLow == other.indexLow;
    }
};

struct FileIdentity {
    std::wstring path;
    std::wstring normalizedPath;
    std::wstring sha256;
    std::wstring publisher;
    ULONGLONG size = 0;
    ULONGLONG writeTime = 0;
    FileId fileId{};
    bool signatureValid = false;
};

// Forward declaration used by the decision dialog.
bool OpenInternetResearch(const FileIdentity& identity);

struct TrustRecord {
    std::wstring normalizedPath;
    std::wstring sha256;
    ULONGLONG size = 0;
    ULONGLONG writeTime = 0;
    DescendantPolicy descendantPolicy = DescendantPolicy::None;
    TrustRecordKind kind = TrustRecordKind::PermanentAllow;
    ULONGLONG createdAt = 0;
};

struct DecisionRequest {
    ProcessInfo process;
    FileIdentity identity;
    NativeDefenderScanResult scan;
    UserDecision decision = UserDecision::Terminate;
    DescendantPolicy descendantPolicy = DescendantPolicy::None;
    HANDLE completed = nullptr;
};

// -----------------------------------------------------------------------------
// RAII
// -----------------------------------------------------------------------------

class UniqueHandle {
public:
    UniqueHandle() = default;
    explicit UniqueHandle(HANDLE value) : value_(value) {}
    ~UniqueHandle() { reset(); }

    UniqueHandle(const UniqueHandle&) = delete;
    UniqueHandle& operator=(const UniqueHandle&) = delete;

    UniqueHandle(UniqueHandle&& other) noexcept : value_(other.release()) {}
    UniqueHandle& operator=(UniqueHandle&& other) noexcept {
        if (this != &other) reset(other.release());
        return *this;
    }

    HANDLE get() const { return value_; }
    explicit operator bool() const {
        return value_ && value_ != INVALID_HANDLE_VALUE;
    }

    HANDLE release() {
        HANDLE old = value_;
        value_ = nullptr;
        return old;
    }

    void reset(HANDLE value = nullptr) {
        if (value_ && value_ != INVALID_HANDLE_VALUE) CloseHandle(value_);
        value_ = value;
    }

private:
    HANDLE value_ = nullptr;
};

struct LocalFreeDeleter {
    void operator()(void* p) const { if (p) LocalFree(p); }
};
using UniqueLocal = std::unique_ptr<void, LocalFreeDeleter>;

// -----------------------------------------------------------------------------
// Utilitarios
// -----------------------------------------------------------------------------

std::wstring ToLower(std::wstring value) {
    std::transform(value.begin(), value.end(), value.begin(),
        [](wchar_t c) { return static_cast<wchar_t>(std::towlower(c)); });
    return value;
}

std::wstring NormalizePath(const std::wstring& input) {
    if (input.empty()) return {};
    std::wstring value;
    try {
        value = fs::weakly_canonical(fs::path(input)).wstring();
    } catch (...) {
        value = fs::path(input).lexically_normal().wstring();
    }
    return ToLower(value);
}

// Regra de quoting do runtime da Microsoft: barras invertidas so sao
// especiais quando precedem uma aspa. As barras finais precisam ser
// duplicadas, senao escapam a aspa de fechamento e o argumento seguinte
// vaza para a linha de comando.

std::wstring Quote(const std::wstring& value) {
    std::wstring result = L"\"";
    for (auto it = value.begin();; ++it) {
        size_t backslashes = 0;
        while (it != value.end() && *it == L'\\') {
            ++it;
            ++backslashes;
        }
        if (it == value.end()) {
            result.append(backslashes * 2, L'\\');
            break;
        }
        if (*it == L'"') {
            result.append(backslashes * 2 + 1, L'\\');
        } else {
            result.append(backslashes, L'\\');
        }
        result.push_back(*it);
    }
    result.push_back(L'"');
    return result;
}

ULONGLONG FileTimeToU64(const FILETIME& ft) {
    ULARGE_INTEGER value{};
    value.LowPart = ft.dwLowDateTime;
    value.HighPart = ft.dwHighDateTime;
    return value.QuadPart;
}

ULONGLONG NowFileTime() {
    FILETIME ft{};
    GetSystemTimeAsFileTime(&ft);
    return FileTimeToU64(ft);
}

std::wstring Hex32(DWORD value) {
    std::wostringstream out;
    out << L"0x" << std::hex << std::uppercase << std::setw(8)
        << std::setfill(L'0') << value;
    return out.str();
}

fs::path ProgramDataRoot() {
    PWSTR raw = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_ProgramData, KF_FLAG_DEFAULT, nullptr, &raw)) && raw) {
        fs::path base(raw);
        CoTaskMemFree(raw);
        return base / L"Macrobyte" / L"VistasDefender";
    }
    wchar_t windows[MAX_PATH]{};
    if (GetWindowsDirectoryW(windows, MAX_PATH) > 0)
        return fs::path(windows).root_path() / L"ProgramData" / L"Macrobyte" / L"VistasDefender";
    return fs::path(L"C:\\ProgramData") / L"Macrobyte" / L"VistasDefender";
}

fs::path DataDirectory() { return ProgramDataRoot() / L"Data"; }
fs::path LogDirectory() { return ProgramDataRoot() / L"Logs"; }
fs::path QuarantineDirectory() { return ProgramDataRoot() / L"Quarantine"; }
// O arquivo .dnt reúne componentes internos ignorados e programas
// permitidos permanentemente. O conteúdo é binário e autenticado por HMAC.
fs::path DatabasePath() { return DataDirectory() / L"Defender.dnt"; }
fs::path DatabaseBackupPath() { return DataDirectory() / L"Defender.dnt.bak"; }
fs::path DatabaseKeyPath() { return DataDirectory() / L"Defender.dnt.key"; }

fs::path ApplicationDirectory() {
    std::vector<wchar_t> buffer(32768);
    DWORD length = GetModuleFileNameW(nullptr, buffer.data(),
                                     static_cast<DWORD>(buffer.size()));
    if (!length || length >= buffer.size()) return fs::current_path();
    return fs::path(std::wstring(buffer.data(), length)).parent_path();
}
fs::path LogPath() { return LogDirectory() / L"Defender.log"; }

std::wstring Timestamp() {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    wchar_t text[64]{};
    swprintf_s(text, L"%04u-%02u-%02u %02u:%02u:%02u",
        st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    return text;
}

class Logger {
public:
    Logger() {
        std::error_code ec;
        fs::create_directories(LogDirectory(), ec);
    }

    void Write(const std::wstring& message) {
        std::lock_guard<std::mutex> lock(mutex_);
        std::wofstream stream(LogPath(), std::ios::app);
        if (stream) stream << L"[" << Timestamp() << L"] " << message << L"\n";
    }

private:
    std::mutex mutex_;
};

Logger gLogger;

bool ApplyRestrictedAcl(const fs::path& path, bool directory) {
    PSECURITY_DESCRIPTOR raw = nullptr;
    const wchar_t* sddl =
        L"D:P"
        L"(A;OICI;FA;;;SY)"
        L"(A;OICI;FA;;;BA)";

    if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(
            sddl, SDDL_REVISION_1, &raw, nullptr)) {
        return false;
    }
    UniqueLocal descriptor(raw);

    BOOL present = FALSE;
    BOOL defaulted = FALSE;
    PACL dacl = nullptr;
    if (!GetSecurityDescriptorDacl(raw, &present, &dacl, &defaulted) || !present)
        return false;

    DWORD result = SetNamedSecurityInfoW(
        const_cast<LPWSTR>(path.c_str()),
        directory ? SE_FILE_OBJECT : SE_FILE_OBJECT,
        DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
        nullptr, nullptr, dacl, nullptr);

    return result == ERROR_SUCCESS;
}

void EnsureProtectedDirectories() {
    std::error_code ec;
    for (const auto& path : { ProgramDataRoot(), DataDirectory(),
                              LogDirectory(), QuarantineDirectory() }) {
        fs::create_directories(path, ec);
        ApplyRestrictedAcl(path, true);
    }
}

// -----------------------------------------------------------------------------
// Versao real do Windows
// -----------------------------------------------------------------------------

WindowsVersion DetectWindowsVersion() {
    using RtlGetVersionFn = LONG (WINAPI*)(PRTL_OSVERSIONINFOW);

    WindowsVersion result;
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    auto rtlGetVersion = reinterpret_cast<RtlGetVersionFn>(
        ntdll ? GetProcAddress(ntdll, "RtlGetVersion") : nullptr);

    RTL_OSVERSIONINFOEXW info{};
    info.dwOSVersionInfoSize = sizeof(info);

    LONG status = rtlGetVersion
        ? rtlGetVersion(reinterpret_cast<PRTL_OSVERSIONINFOW>(&info))
        : -1;

    if (status != 0) {
        OSVERSIONINFOEXW fallback{};
        fallback.dwOSVersionInfoSize = sizeof(fallback);
#pragma warning(push)
#pragma warning(disable:4996)
        if (!GetVersionExW(reinterpret_cast<OSVERSIONINFOW*>(&fallback)))
            return result;
#pragma warning(pop)
        info = fallback;
    }

    result.major = info.dwMajorVersion;
    result.minor = info.dwMinorVersion;
    result.build = info.dwBuildNumber;
    result.servicePackMajor = info.wServicePackMajor;
    result.isServer = info.wProductType != VER_NT_WORKSTATION;

    if (result.major == 6 && result.minor == 1) {
        result.family = WindowsFamily::Windows7;
        result.displayName = L"Windows 7";
    } else if (result.major == 6 && result.minor == 2) {
        result.family = WindowsFamily::Windows8;
        result.displayName = L"Windows 8";
    } else if (result.major == 6 && result.minor == 3) {
        result.family = WindowsFamily::Windows81;
        result.displayName = L"Windows 8.1";
    } else if (result.major == 10 && result.build >= 22000) {
        result.family = WindowsFamily::Windows11;
        result.displayName = L"Windows 11";
    } else if (result.major == 10) {
        result.family = WindowsFamily::Windows10;
        result.displayName = L"Windows 10";
    }

    if (result.isServer) result.displayName += L" / Server";
    result.displayName += L" (build " + std::to_wstring(result.build) + L")";
    return result;
}

// -----------------------------------------------------------------------------
// Hash, assinatura e identidade do arquivo
// -----------------------------------------------------------------------------

std::optional<std::wstring> Sha256FromHandle(HANDLE file) {
    LARGE_INTEGER zero{};
    if (!SetFilePointerEx(file, zero, nullptr, FILE_BEGIN)) return std::nullopt;

    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    DWORD objectLength = 0, resultLength = 0;
    DWORD hashLength = 0;
    std::vector<BYTE> object;
    std::vector<BYTE> digest;

    if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM,
                                    nullptr, 0) != 0)
        return std::nullopt;

    auto cleanup = [&]() {
        if (hash) BCryptDestroyHash(hash);
        if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0);
    };

    if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
            reinterpret_cast<PUCHAR>(&objectLength), sizeof(objectLength),
            &resultLength, 0) != 0 ||
        BCryptGetProperty(algorithm, BCRYPT_HASH_LENGTH,
            reinterpret_cast<PUCHAR>(&hashLength), sizeof(hashLength),
            &resultLength, 0) != 0) {
        cleanup();
        return std::nullopt;
    }

    object.resize(objectLength);
    digest.resize(hashLength);

    if (BCryptCreateHash(algorithm, &hash, object.data(),
                         static_cast<ULONG>(object.size()),
                         nullptr, 0, 0) != 0) {
        cleanup();
        return std::nullopt;
    }

    std::vector<BYTE> buffer(1024 * 1024);
    for (;;) {
        DWORD read = 0;
        if (!ReadFile(file, buffer.data(), static_cast<DWORD>(buffer.size()),
                      &read, nullptr)) {
            cleanup();
            return std::nullopt;
        }
        if (!read) break;
        if (BCryptHashData(hash, buffer.data(), read, 0) != 0) {
            cleanup();
            return std::nullopt;
        }
    }

    if (BCryptFinishHash(hash, digest.data(),
                         static_cast<ULONG>(digest.size()), 0) != 0) {
        cleanup();
        return std::nullopt;
    }

    cleanup();

    std::wostringstream text;
    for (BYTE b : digest)
        text << std::hex << std::setw(2) << std::setfill(L'0')
             << static_cast<unsigned>(b);
    return text.str();
}

bool VerifyAuthenticode(const std::wstring& path) {
    WINTRUST_FILE_INFO fileInfo{};
    fileInfo.cbStruct = sizeof(fileInfo);
    fileInfo.pcwszFilePath = path.c_str();

    GUID policy = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    WINTRUST_DATA data{};
    data.cbStruct = sizeof(data);
    data.dwUIChoice = WTD_UI_NONE;
    // A análise em tempo real não depende de rede ou revogação remota.
    data.fdwRevocationChecks = WTD_REVOKE_NONE;
    data.dwUnionChoice = WTD_CHOICE_FILE;
    data.pFile = &fileInfo;
    data.dwStateAction = WTD_STATEACTION_VERIFY;
    data.dwProvFlags = WTD_CACHE_ONLY_URL_RETRIEVAL;

    LONG status = WinVerifyTrust(nullptr, &policy, &data);
    data.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(nullptr, &policy, &data);
    return status == ERROR_SUCCESS;
}

std::wstring ReadPublisher(const std::wstring& path) {
    HCERTSTORE store = nullptr;
    HCRYPTMSG message = nullptr;
    DWORD encoding = 0, contentType = 0, formatType = 0;

    if (!CryptQueryObject(CERT_QUERY_OBJECT_FILE, path.c_str(),
            CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY, 0, &encoding, &contentType,
            &formatType, &store, &message, nullptr)) {
        return L"Não identificado";
    }

    DWORD signerSize = 0;
    if (!CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0,
                          nullptr, &signerSize)) {
        if (store) CertCloseStore(store, 0);
        if (message) CryptMsgClose(message);
        return L"Não identificado";
    }

    std::vector<BYTE> signerBuffer(signerSize);
    if (!CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0,
                          signerBuffer.data(), &signerSize)) {
        CertCloseStore(store, 0);
        CryptMsgClose(message);
        return L"Não identificado";
    }

    auto signer = reinterpret_cast<PCMSG_SIGNER_INFO>(signerBuffer.data());
    CERT_INFO certInfo{};
    certInfo.Issuer = signer->Issuer;
    certInfo.SerialNumber = signer->SerialNumber;

    PCCERT_CONTEXT cert = CertFindCertificateInStore(
        store, encoding, 0, CERT_FIND_SUBJECT_CERT, &certInfo, nullptr);

    std::wstring publisher = L"Não identificado";
    if (cert) {
        wchar_t name[512]{};
        DWORD len = CertGetNameStringW(cert, CERT_NAME_SIMPLE_DISPLAY_TYPE,
                                       0, nullptr, name, 512);
        if (len > 1) publisher = name;
        CertFreeCertificateContext(cert);
    }

    CertCloseStore(store, 0);
    CryptMsgClose(message);
    return publisher;
}

// Return the Organization (O=) attribute from the embedded signer certificate.
// The display name/CN is not a reliable publisher identifier (it may be "Microsoft Windows").
std::wstring ReadPublisherOrganization(const std::wstring& path) {
    HCERTSTORE store = nullptr;
    HCRYPTMSG message = nullptr;
    DWORD encoding = 0, contentType = 0, formatType = 0;
    if (!CryptQueryObject(CERT_QUERY_OBJECT_FILE, path.c_str(),
            CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY, 0, &encoding, &contentType,
            &formatType, &store, &message, nullptr)) {
        return L"";
    }
    std::wstring organization;
    DWORD signerSize = 0;
    if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, nullptr, &signerSize)) {
        std::vector<BYTE> buffer(signerSize);
        if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, buffer.data(), &signerSize)) {
            auto signer = reinterpret_cast<PCMSG_SIGNER_INFO>(buffer.data());
            CERT_INFO info{};
            info.Issuer = signer->Issuer;
            info.SerialNumber = signer->SerialNumber;
            PCCERT_CONTEXT cert = CertFindCertificateInStore(
                store, encoding, 0, CERT_FIND_SUBJECT_CERT, &info, nullptr);
            if (cert) {
                wchar_t name[512]{};
                const DWORD length = CertGetNameStringW(cert, CERT_NAME_ATTR_TYPE, 0,
                    const_cast<LPSTR>(szOID_ORGANIZATION_NAME), name, _countof(name));
                if (length > 1) organization.assign(name);
                CertFreeCertificateContext(cert);
            }
        }
    }
    if (store) CertCloseStore(store, 0);
    if (message) CryptMsgClose(message);
    return organization;
}

std::optional<FileIdentity> ReadIdentity(const std::wstring& path,
                                         DWORD shareMode =
                                             FILE_SHARE_READ |
                                             FILE_SHARE_DELETE) {
    UniqueHandle file(CreateFileW(path.c_str(), GENERIC_READ, shareMode,
        nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, nullptr));

    if (!file) return std::nullopt;

    BY_HANDLE_FILE_INFORMATION info{};
    if (!GetFileInformationByHandle(file.get(), &info)) return std::nullopt;

    auto hash = Sha256FromHandle(file.get());
    if (!hash) return std::nullopt;

    FileIdentity identity;
    identity.path = path;
    identity.normalizedPath = NormalizePath(path);
    identity.sha256 = *hash;
    identity.size =
        (static_cast<ULONGLONG>(info.nFileSizeHigh) << 32) |
         info.nFileSizeLow;
    identity.writeTime = FileTimeToU64(info.ftLastWriteTime);
    identity.fileId.volumeSerial = info.dwVolumeSerialNumber;
    identity.fileId.indexHigh = info.nFileIndexHigh;
    identity.fileId.indexLow = info.nFileIndexLow;
    identity.signatureValid = VerifyAuthenticode(path);
    identity.publisher =
        identity.signatureValid ? ReadPublisher(path) : L"Não identificado";
    return identity;
}

bool SameFileIdentity(const FileIdentity& a, const FileIdentity& b) {
    return a.fileId == b.fileId &&
           a.sha256 == b.sha256 &&
           a.size == b.size &&
           a.writeTime == b.writeTime;
}

// -----------------------------------------------------------------------------
// Processos
// -----------------------------------------------------------------------------

std::wstring ProcessPath(DWORD pid) {
    UniqueHandle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,
                                     FALSE, pid));
    if (!process) {
        process.reset(OpenProcess(PROCESS_QUERY_INFORMATION |
                                  PROCESS_VM_READ, FALSE, pid));
    }
    if (!process) return {};

    std::vector<wchar_t> buffer(32768);
    DWORD size = static_cast<DWORD>(buffer.size());
    if (QueryFullProcessImageNameW(process.get(), 0, buffer.data(), &size))
        return std::wstring(buffer.data(), size);

    return {};
}

std::map<DWORD, ProcessInfo> SnapshotProcesses() {
    std::map<DWORD, ProcessInfo> result;
    UniqueHandle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));
    if (!snapshot || snapshot.get() == INVALID_HANDLE_VALUE) return result;

    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (!Process32FirstW(snapshot.get(), &entry)) return result;

    do {
        ProcessInfo info;
        info.pid = entry.th32ProcessID;
        info.parentPid = entry.th32ParentProcessID;
        info.path = ProcessPath(info.pid);
        result[info.pid] = std::move(info);
    } while (Process32NextW(snapshot.get(), &entry));

    for (auto& pair : result) {
        auto it = result.find(pair.second.parentPid);
        if (it != result.end()) pair.second.parentPath = it->second.path;
    }
    return result;
}

// A suspensão preventiva de processos foi removida para preservar a estabilidade.

bool TerminateProcessSafe(DWORD pid) {
    UniqueHandle process(OpenProcess(PROCESS_TERMINATE |
                                     SYNCHRONIZE, FALSE, pid));
    if (!process) return false;
    return TerminateProcess(process.get(), ERROR_ACCESS_DENIED) != FALSE;
}

// -----------------------------------------------------------------------------
// Microsoft Defender / Microsoft Security Essentials
// -----------------------------------------------------------------------------

bool ReadRegistryString(HKEY root, const std::wstring& subkey,
                        const std::wstring& valueName,
                        std::wstring& output) {
    DWORD type = 0;
    DWORD bytes = 0;
    if (RegGetValueW(root, subkey.c_str(), valueName.c_str(),
                     RRF_RT_REG_SZ, &type, nullptr, &bytes) != ERROR_SUCCESS)
        return false;

    std::vector<wchar_t> buffer(bytes / sizeof(wchar_t) + 2);
    if (RegGetValueW(root, subkey.c_str(), valueName.c_str(),
                     RRF_RT_REG_SZ, &type, buffer.data(), &bytes)
        != ERROR_SUCCESS)
        return false;

    output.assign(buffer.data());
    return true;
}

std::vector<fs::path> DefenderCandidates(const WindowsVersion& os) {
    (void)os;
    std::vector<fs::path> candidates;
    auto knownFolder = [](REFKNOWNFOLDERID id) -> fs::path {
        PWSTR raw = nullptr;
        if (FAILED(SHGetKnownFolderPath(id, KF_FLAG_DEFAULT, nullptr, &raw)) || !raw)
            return {};
        fs::path value(raw);
        CoTaskMemFree(raw);
        return value;
    };
    const fs::path programData = knownFolder(FOLDERID_ProgramData);
    const fs::path programFiles = knownFolder(FOLDERID_ProgramFiles);
    const fs::path programFilesX86 = knownFolder(FOLDERID_ProgramFilesX86);

    if (!programData.empty()) {
        const fs::path platform = programData / L"Microsoft" / L"Windows Defender" / L"Platform";
        std::error_code ec;
        std::vector<std::pair<std::vector<unsigned long long>, fs::path>> versions;
        if (fs::exists(platform, ec) && !ec) {
            for (fs::directory_iterator it(platform, ec), end; !ec && it != end; it.increment(ec)) {
                std::error_code itemError;
                if (!it->is_directory(itemError) || itemError) continue;
                const std::wstring versionName = it->path().filename().wstring();
                std::vector<unsigned long long> tuple;
                size_t pos = 0;
                bool valid = true;
                while (pos < versionName.size()) {
                    while (pos < versionName.size() && !iswdigit(versionName[pos])) ++pos;
                    if (pos == versionName.size()) break;
                    unsigned long long value = 0;
                    while (pos < versionName.size() && iswdigit(versionName[pos])) {
                        const unsigned digit = static_cast<unsigned>(versionName[pos++] - L'0');
                        if (value > (ULLONG_MAX - digit) / 10) { valid = false; break; }
                        value = value * 10 + digit;
                    }
                    if (!valid) break;
                    tuple.push_back(value);
                }
                if (valid && !tuple.empty())
                    versions.emplace_back(std::move(tuple), it->path() / L"MpCmdRun.exe");
            }
        }
        // Numeric version comparison (string reverse-sorting puts 10 before 9/11 incorrectly).
        std::sort(versions.begin(), versions.end(), [](const auto& a, const auto& b) {
            const size_t count = (std::max)(a.first.size(), b.first.size());
            for (size_t i = 0; i < count; ++i) {
                const auto av = i < a.first.size() ? a.first[i] : 0;
                const auto bv = i < b.first.size() ? b.first[i] : 0;
                if (av != bv) return av > bv;
            }
            return a.second.wstring() > b.second.wstring();
        });
        for (const auto& entry : versions) candidates.push_back(entry.second);
    }
    if (!programFiles.empty()) {
        candidates.push_back(programFiles / L"Windows Defender" / L"MpCmdRun.exe");
        candidates.push_back(programFiles / L"Microsoft Security Client" / L"Antimalware" / L"MpCmdRun.exe");
        candidates.push_back(programFiles / L"Microsoft Security Client" / L"MpCmdRun.exe");
    }
    if (!programFilesX86.empty()) {
        candidates.push_back(programFilesX86 / L"Microsoft Security Client" / L"Antimalware" / L"MpCmdRun.exe");
        candidates.push_back(programFilesX86 / L"Microsoft Security Client" / L"MpCmdRun.exe");
    }
    return candidates;
}

std::optional<fs::path> FindDefenderEngine(const WindowsVersion& os) {
    for (const auto& candidate : DefenderCandidates(os)) {
        std::error_code ec;
        if (!fs::is_regular_file(candidate, ec) || ec) continue;
        const std::wstring path = candidate.wstring();
        if (VerifyAuthenticode(path) &&
            _wcsicmp(ReadPublisherOrganization(path).c_str(), L"Microsoft Corporation") == 0)
            return candidate;
    }
    return std::nullopt;
}

bool PathMatchesExclusion(const std::wstring& filePath,
                          const std::wstring& exclusion) {
    std::wstring file = NormalizePath(filePath);
    std::wstring rule = NormalizePath(exclusion);
    if (rule.empty()) return false;
    if (file == rule) return true;
    if (rule.back() != L'\\') rule.push_back(L'\\');
    return file.rfind(rule, 0) == 0;
}

bool IsExcludedByRegistryKey(HKEY root, const std::wstring& keyPath,
                             const std::wstring& filePath) {
    HKEY key = nullptr;
    if (RegOpenKeyExW(root, keyPath.c_str(), 0, KEY_READ, &key)
        != ERROR_SUCCESS)
        return false;

    DWORD index = 0;
    wchar_t valueName[32768]{};
    for (;;) {
        DWORD chars = static_cast<DWORD>(std::size(valueName));
        LONG status = RegEnumValueW(key, index++, valueName, &chars,
                                    nullptr, nullptr, nullptr, nullptr);
        if (status == ERROR_NO_MORE_ITEMS) break;
        if (status == ERROR_SUCCESS &&
            PathMatchesExclusion(filePath, std::wstring(valueName, chars))) {
            RegCloseKey(key);
            return true;
        }
    }
    RegCloseKey(key);
    return false;
}

bool IsExcludedByNativeDefender(const WindowsVersion& os,
                                const std::wstring& path) {
    const std::vector<std::wstring> keys = {
        L"SOFTWARE\\Microsoft\\Windows Defender\\Exclusions\\Paths",
        L"SOFTWARE\\Microsoft\\Microsoft Antimalware\\Exclusions\\Paths",
        L"SOFTWARE\\Microsoft\\Microsoft Security Client\\Exclusions\\Paths"
    };

    for (const auto& key : keys) {
        if (IsExcludedByRegistryKey(HKEY_LOCAL_MACHINE, key, path))
            return true;
    }
    (void)os;
    return false;
}

struct ProcessExecutionResult {
    bool created = false;
    bool timeout = false;
    DWORD exitCode = ERROR_GEN_FAILURE;
    DWORD win32Error = ERROR_SUCCESS;
};

ProcessExecutionResult RunHiddenProcess(const std::wstring& executable,
                                        const std::wstring& arguments,
                                        DWORD timeoutMs) {
    ProcessExecutionResult result;
    std::wstring command = Quote(executable) + L" " + arguments;

    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    startup.dwFlags = STARTF_USESHOWWINDOW;
    startup.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION process{};
    BOOL created = CreateProcessW(
        executable.c_str(), command.data(), nullptr, nullptr, FALSE,
        CREATE_NO_WINDOW | CREATE_UNICODE_ENVIRONMENT,
        nullptr, fs::path(executable).parent_path().c_str(),
        &startup, &process);

    if (!created) {
        result.win32Error = GetLastError();
        return result;
    }

    result.created = true;
    UniqueHandle processHandle(process.hProcess);
    UniqueHandle threadHandle(process.hThread);

    DWORD wait = WaitForSingleObject(processHandle.get(), timeoutMs);
    if (wait == WAIT_TIMEOUT) {
        result.timeout = true;
        TerminateProcess(processHandle.get(), ERROR_TIMEOUT);
        WaitForSingleObject(processHandle.get(), 3000);
        result.exitCode = ERROR_TIMEOUT;
        return result;
    }

    if (wait != WAIT_OBJECT_0) {
        result.win32Error = GetLastError();
        return result;
    }

    if (!GetExitCodeProcess(processHandle.get(), &result.exitCode))
        result.win32Error = GetLastError();

    return result;
}

NativeDefenderScanResult ScanWithNativeDefender(
    const WindowsVersion& os, const std::wstring& path) {

    NativeDefenderScanResult scan;

    if (IsExcludedByNativeDefender(os, path)) {
        scan.result = NativeDefenderResult::Excluded;
        scan.exitCode = ERROR_SUCCESS;
        scan.details = L"O caminho consta nas exclusões do antivírus da Microsoft.";
        return scan;
    }

    auto engine = FindDefenderEngine(os);
    if (!engine) {
        scan.result = NativeDefenderResult::Unavailable;
        scan.exitCode = ERROR_FILE_NOT_FOUND;
        scan.details =
            os.family == WindowsFamily::Windows7
            ? L"Microsoft Security Essentials não foi localizado. "
              L"O Windows Defender original do Windows 7 não oferece a mesma "
              L"interface de antivírus das versões atuais."
            : L"MpCmdRun.exe não foi localizado.";
        return scan;
    }

    scan.enginePath = engine->wstring();

    // Esta sintaxe e comum ao Microsoft Security Essentials e ao Defender moderno.
    std::wstring arguments =
        L"-Scan -ScanType 3 -File " + Quote(path);
    scan.commandDescription =
        engine->filename().wstring() + L" -Scan -ScanType 3 -File <arquivo>";

    ProcessExecutionResult execution =
        RunHiddenProcess(engine->wstring(), arguments, kScanTimeoutMs);

    scan.exitCode = execution.exitCode;
    scan.win32Error = execution.win32Error;

    if (!execution.created) {
        scan.result = NativeDefenderResult::ScanFailed;
        scan.details = L"Não foi possível iniciar o mecanismo: " +
                       Hex32(execution.win32Error);
        return scan;
    }

    if (execution.timeout) {
        scan.result = NativeDefenderResult::Timeout;
        scan.details = L"O mecanismo não respondeu no tempo limite.";
        return scan;
    }

    // O código 2 é ambíguo na documentação da Microsoft: pode ser ameaça não
    // remediada, ação do usuário necessária OU erro de verificação. Não o rotulamos
    // como malware confirmado para evitar falsos positivos. Outros códigos = falha de análise.
    if (execution.exitCode == 0) {
        scan.result = NativeDefenderResult::ScanCompleted;
        scan.details = L"O comando de verificação terminou sem ação pendente reportada. Isso não prova ausência absoluta de ameaça; consulte o Histórico de proteção para saber se houve remediação.";
    } else if (execution.exitCode == 2) {
        scan.result = NativeDefenderResult::AttentionRequired;
        scan.details =
            L"Código 2 ambíguo: ameaça não remediada, ação do usuário necessária ou erro de verificação. Confira o Histórico de proteção.";
    } else {
        scan.result = NativeDefenderResult::ScanFailed;
        scan.details = L"A análise terminou com código " +
                       Hex32(execution.exitCode) + L".";
    }

    return scan;
}

std::wstring ScanResultText(NativeDefenderResult result) {
    switch (result) {
    case NativeDefenderResult::ScanCompleted:
        return L"Verificação concluída; sem ação pendente reportada pelo comando";
    case NativeDefenderResult::Excluded:
        return L"Arquivo ou pasta em exclusão";
    case NativeDefenderResult::AttentionRequired:
        return L"Atenção necessária (ameaça, remediação ou erro)";
    case NativeDefenderResult::ScanFailed:
        return L"Falha na análise";
    case NativeDefenderResult::Timeout:
        return L"Tempo limite excedido";
    default:
        return L"Mecanismo indisponível";
    }
}

// -----------------------------------------------------------------------------
// HMAC e banco de confiança
// -----------------------------------------------------------------------------

bool RandomBytes(std::vector<BYTE>& bytes) {
    return BCryptGenRandom(nullptr, bytes.data(),
        static_cast<ULONG>(bytes.size()),
        BCRYPT_USE_SYSTEM_PREFERRED_RNG) == 0;
}

std::optional<std::vector<BYTE>> ProtectBytes(const std::vector<BYTE>& plain) {
    DATA_BLOB input{};
    input.pbData = const_cast<BYTE*>(plain.data());
    input.cbData = static_cast<DWORD>(plain.size());
    DATA_BLOB output{};

    if (!CryptProtectData(&input, L"Vistas Defender key", nullptr,
                          nullptr, nullptr,
                          CRYPTPROTECT_LOCAL_MACHINE, &output))
        return std::nullopt;

    std::vector<BYTE> result(output.pbData, output.pbData + output.cbData);
    LocalFree(output.pbData);
    return result;
}

std::optional<std::vector<BYTE>> UnprotectBytes(
    const std::vector<BYTE>& protectedBytes) {
    DATA_BLOB input{};
    input.pbData = const_cast<BYTE*>(protectedBytes.data());
    input.cbData = static_cast<DWORD>(protectedBytes.size());
    DATA_BLOB output{};

    if (!CryptUnprotectData(&input, nullptr, nullptr, nullptr, nullptr,
                            0, &output))
        return std::nullopt;

    std::vector<BYTE> result(output.pbData, output.pbData + output.cbData);
    LocalFree(output.pbData);
    return result;
}

std::optional<std::vector<BYTE>> HmacSha256(
    const std::vector<BYTE>& key, const std::vector<BYTE>& data) {

    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    DWORD objectLength = 0, hashLength = 0, returned = 0;

    if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM,
            nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG) != 0)
        return std::nullopt;

    if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
            reinterpret_cast<PUCHAR>(&objectLength), sizeof(objectLength),
            &returned, 0) != 0 ||
        BCryptGetProperty(algorithm, BCRYPT_HASH_LENGTH,
            reinterpret_cast<PUCHAR>(&hashLength), sizeof(hashLength),
            &returned, 0) != 0) {
        BCryptCloseAlgorithmProvider(algorithm, 0);
        return std::nullopt;
    }

    std::vector<BYTE> object(objectLength), digest(hashLength);
    if (BCryptCreateHash(algorithm, &hash, object.data(), objectLength,
            const_cast<PUCHAR>(key.data()),
            static_cast<ULONG>(key.size()), 0) != 0) {
        BCryptCloseAlgorithmProvider(algorithm, 0);
        return std::nullopt;
    }

    NTSTATUS status = BCryptHashData(hash,
        const_cast<PUCHAR>(data.data()), static_cast<ULONG>(data.size()), 0);
    if (status == 0)
        status = BCryptFinishHash(hash, digest.data(), hashLength, 0);

    BCryptDestroyHash(hash);
    BCryptCloseAlgorithmProvider(algorithm, 0);
    if (status != 0) return std::nullopt;
    return digest;
}

template<typename T>
void AppendPod(std::vector<BYTE>& out, const T& value) {
    const BYTE* p = reinterpret_cast<const BYTE*>(&value);
    out.insert(out.end(), p, p + sizeof(T));
}

void AppendString(std::vector<BYTE>& out, const std::wstring& value) {
    uint32_t length = static_cast<uint32_t>(value.size());
    AppendPod(out, length);
    const BYTE* p = reinterpret_cast<const BYTE*>(value.data());
    out.insert(out.end(), p, p + length * sizeof(wchar_t));
}

template<typename T>
bool ReadPod(const std::vector<BYTE>& in, size_t& offset, T& value) {
    if (offset + sizeof(T) > in.size()) return false;
    memcpy(&value, in.data() + offset, sizeof(T));
    offset += sizeof(T);
    return true;
}

bool ReadString(const std::vector<BYTE>& in, size_t& offset,
                std::wstring& value) {
    uint32_t length = 0;
    if (!ReadPod(in, offset, length)) return false;
    size_t bytes = static_cast<size_t>(length) * sizeof(wchar_t);
    if (offset + bytes > in.size()) return false;
    value.assign(reinterpret_cast<const wchar_t*>(in.data() + offset), length);
    offset += bytes;
    return true;
}

bool ConstantTimeEquals(const std::vector<BYTE>& a,
                        const std::vector<BYTE>& b) {
    if (a.size() != b.size()) return false;
    BYTE diff = 0;
    for (size_t i = 0; i < a.size(); ++i) diff |= a[i] ^ b[i];
    return diff == 0;
}

class TrustDatabase {
public:
    TrustDatabase() {
        EnsureProtectedDirectories();
        LoadOrCreateKey();
        Load();
    }

    std::optional<TrustRecord> Find(const FileIdentity& identity) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = records_.find(identity.normalizedPath);
        if (it == records_.end()) return std::nullopt;
        const TrustRecord& record = it->second;
        if (record.sha256 != identity.sha256 ||
            record.size != identity.size ||
            record.writeTime != identity.writeTime)
            return std::nullopt;
        return record;
    }

    void Save(const FileIdentity& identity,
              DescendantPolicy policy,
              TrustRecordKind kind = TrustRecordKind::PermanentAllow) {
        std::lock_guard<std::mutex> lock(mutex_);
        TrustRecord record;
        record.normalizedPath = identity.normalizedPath;
        record.sha256 = identity.sha256;
        record.size = identity.size;
        record.writeTime = identity.writeTime;
        record.descendantPolicy = policy;
        record.kind = kind;
        record.createdAt = NowFileTime();
        records_[record.normalizedPath] = record;
        SaveLocked();
    }

    void SaveInternal(const FileIdentity& identity) {
        Save(identity, DescendantPolicy::None,
             TrustRecordKind::InternalIgnore);
    }

    void Remove(const std::wstring& normalizedPath) {
        std::lock_guard<std::mutex> lock(mutex_);
        records_.erase(normalizedPath);
        SaveLocked();
    }

private:
    void LoadOrCreateKey() {
        std::ifstream stream(DatabaseKeyPath(), std::ios::binary);
        if (stream) {
            // Evita o “most vexing parse” do C++: com parênteses simples,
            // o compilador pode interpretar a declaração como uma função.
            const std::vector<char> protectedKeyChars(
                (std::istreambuf_iterator<char>(stream)),
                std::istreambuf_iterator<char>());
            const std::vector<BYTE> protectedKey(
                protectedKeyChars.begin(), protectedKeyChars.end());
            auto key = UnprotectBytes(protectedKey);
            if (key && key->size() == 32) {
                key_ = *key;
                return;
            }
        }

        key_.resize(32);
        if (!RandomBytes(key_))
            throw std::runtime_error("Falha ao gerar chave do banco.");

        auto protectedKey = ProtectBytes(key_);
        if (!protectedKey)
            throw std::runtime_error("Falha ao proteger chave do banco.");

        std::ofstream output(DatabaseKeyPath(), std::ios::binary |
                                               std::ios::trunc);
        output.write(reinterpret_cast<const char*>(protectedKey->data()),
                     static_cast<std::streamsize>(protectedKey->size()));
        output.close();
        ApplyRestrictedAcl(DatabaseKeyPath(), false);
    }

    std::vector<BYTE> SerializeRecords() const {
        std::vector<BYTE> data;
        AppendPod(data, kDatabaseVersion);
        uint32_t count = static_cast<uint32_t>(records_.size());
        AppendPod(data, count);
        for (const auto& item : records_) {
            const TrustRecord& record = item.second;
            AppendString(data, record.normalizedPath);
            AppendString(data, record.sha256);
            AppendPod(data, record.size);
            AppendPod(data, record.writeTime);
            uint32_t policy = static_cast<uint32_t>(record.descendantPolicy);
            uint32_t kind = static_cast<uint32_t>(record.kind);
            AppendPod(data, policy);
            AppendPod(data, kind);
            AppendPod(data, record.createdAt);
        }
        return data;
    }

    bool DeserializeRecords(const std::vector<BYTE>& data) {
        size_t offset = 0;
        uint32_t version = 0, count = 0;
        if (!ReadPod(data, offset, version) ||
            !ReadPod(data, offset, count) ||
            version != kDatabaseVersion ||
            count > 100000)
            return false;

        std::map<std::wstring, TrustRecord> loaded;
        for (uint32_t i = 0; i < count; ++i) {
            TrustRecord record;
            uint32_t policy = 0;
            uint32_t kind = 0;
            if (!ReadString(data, offset, record.normalizedPath) ||
                !ReadString(data, offset, record.sha256) ||
                !ReadPod(data, offset, record.size) ||
                !ReadPod(data, offset, record.writeTime) ||
                !ReadPod(data, offset, policy) ||
                !ReadPod(data, offset, kind) ||
                !ReadPod(data, offset, record.createdAt))
                return false;
            if (policy > static_cast<uint32_t>(
                    DescendantPolicy::AllDescendants) ||
                kind > static_cast<uint32_t>(
                    TrustRecordKind::InternalIgnore))
                return false;
            record.descendantPolicy =
                static_cast<DescendantPolicy>(policy);
            record.kind = static_cast<TrustRecordKind>(kind);
            loaded[record.normalizedPath] = std::move(record);
        }
        if (offset != data.size()) return false;
        records_ = std::move(loaded);
        return true;
    }

    bool LoadFile(const fs::path& path) {
        std::ifstream stream(path, std::ios::binary);
        if (!stream) return false;
        // Primeiro lê como char e depois converte para BYTE. Além de ser
        // explícito, isto elimina a ambiguidade sintática do construtor.
        const std::vector<char> fileChars(
            (std::istreambuf_iterator<char>(stream)),
            std::istreambuf_iterator<char>());
        std::vector<BYTE> all(fileChars.begin(), fileChars.end());

        if (all.size() < 32) return false;
        std::vector<BYTE> storedHmac(all.end() - 32, all.end());
        all.resize(all.size() - 32);
        auto expected = HmacSha256(key_, all);
        if (!expected || !ConstantTimeEquals(*expected, storedHmac))
            return false;
        return DeserializeRecords(all);
    }

    void Load() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (LoadFile(DatabasePath())) return;
        if (LoadFile(DatabaseBackupPath())) {
            gLogger.Write(L"Banco principal corrompido; backup carregado.");
            SaveLocked();
            return;
        }
        records_.clear();
        gLogger.Write(L"Banco de confiança novo ou inválido.");
    }

    bool SaveLocked() {
        std::vector<BYTE> data = SerializeRecords();
        auto digest = HmacSha256(key_, data);
        if (!digest) return false;
        data.insert(data.end(), digest->begin(), digest->end());

        fs::path temp = DatabasePath();
        temp += L".tmp";

        {
            std::ofstream stream(temp, std::ios::binary | std::ios::trunc);
            if (!stream) return false;
            stream.write(reinterpret_cast<const char*>(data.data()),
                         static_cast<std::streamsize>(data.size()));
            stream.flush();
            if (!stream) return false;
        }
        ApplyRestrictedAcl(temp, false);

        std::error_code ec;
        if (fs::exists(DatabasePath(), ec))
            CopyFileW(DatabasePath().c_str(),
                      DatabaseBackupPath().c_str(), FALSE);

        if (!MoveFileExW(temp.c_str(), DatabasePath().c_str(),
                MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
            DeleteFileW(temp.c_str());
            return false;
        }
        ApplyRestrictedAcl(DatabasePath(), false);
        ApplyRestrictedAcl(DatabaseBackupPath(), false);
        return true;
    }

    std::mutex mutex_;
    std::vector<BYTE> key_;
    std::map<std::wstring, TrustRecord> records_;
};

// -----------------------------------------------------------------------------
// Quarentena
// -----------------------------------------------------------------------------

struct QuarantineContext {
    DWORD pid = 0;
    DWORD parentPid = 0;
    std::wstring reason;
    std::wstring decision;
    NativeDefenderScanResult scan;
};

class QuarantineManager {
public:
    bool Put(const FileIdentity& expected,
             const QuarantineContext& context) {
        // Reabre sem permitir escrita; confirma o arquivo real imediatamente.
        auto current = ReadIdentity(expected.path, FILE_SHARE_READ);
        if (!current || !SameFileIdentity(expected, *current)) {
            gLogger.Write(L"Quarentena cancelada: arquivo foi trocado: " +
                          expected.path);
            return false;
        }

        UniqueHandle file(CreateFileW(expected.path.c_str(), GENERIC_READ,
            FILE_SHARE_READ, nullptr, OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, nullptr));
        if (!file) return false;

        LARGE_INTEGER zero{};
        SetFilePointerEx(file.get(), zero, nullptr, FILE_BEGIN);

        std::vector<BYTE> bytes;
        std::vector<BYTE> chunk(1024 * 1024);
        for (;;) {
            DWORD read = 0;
            if (!ReadFile(file.get(), chunk.data(),
                          static_cast<DWORD>(chunk.size()), &read, nullptr))
                return false;
            if (!read) break;
            bytes.insert(bytes.end(), chunk.begin(), chunk.begin() + read);
        }

        DATA_BLOB input{};
        input.pbData = bytes.empty() ? nullptr : bytes.data();
        input.cbData = static_cast<DWORD>(bytes.size());

        const std::wstring entropyText =
            L"Macrobyte.VistasDefender.Quarantine.v4";
        DATA_BLOB entropy{};
        entropy.pbData = reinterpret_cast<BYTE*>(
            const_cast<wchar_t*>(entropyText.c_str()));
        entropy.cbData = static_cast<DWORD>(
            entropyText.size() * sizeof(wchar_t));

        DATA_BLOB output{};
        if (!CryptProtectData(&input, L"Vistas Defender Quarantine",
                &entropy, nullptr, nullptr,
                CRYPTPROTECT_LOCAL_MACHINE, &output))
            return false;

        std::wstring id = expected.sha256.substr(0, 20) + L"-" +
                          std::to_wstring(GetTickCount64());
        fs::path directory = QuarantineDirectory() / id;
        std::error_code ec;
        fs::create_directories(directory, ec);
        ApplyRestrictedAcl(directory, true);

        fs::path payload = directory / L"payload.vdq";
        {
            std::ofstream stream(payload, std::ios::binary |
                                           std::ios::trunc);
            if (!stream) {
                LocalFree(output.pbData);
                return false;
            }
            stream.write(reinterpret_cast<const char*>(output.pbData),
                         output.cbData);
        }
        LocalFree(output.pbData);
        ApplyRestrictedAcl(payload, false);

        fs::path metadata = directory / L"metadata.txt";
        {
            std::wofstream stream(metadata, std::ios::trunc);
            if (!stream) return false;
            stream
                << L"OriginalPath=" << expected.path << L"\n"
                << L"SHA256=" << expected.sha256 << L"\n"
                << L"Size=" << expected.size << L"\n"
                << L"WriteTime=" << expected.writeTime << L"\n"
                << L"VolumeSerial=" << expected.fileId.volumeSerial << L"\n"
                << L"FileIndexHigh=" << expected.fileId.indexHigh << L"\n"
                << L"FileIndexLow=" << expected.fileId.indexLow << L"\n"
                << L"PID=" << context.pid << L"\n"
                << L"ParentPID=" << context.parentPid << L"\n"
                << L"Reason=" << context.reason << L"\n"
                << L"Decision=" << context.decision << L"\n"
                << L"NativeResult=" << ScanResultText(context.scan.result)
                << L"\n"
                << L"NativeExitCode=" << Hex32(context.scan.exitCode) << L"\n"
                << L"NativeDetails=" << context.scan.details << L"\n"
                << L"QuarantineTime=" << Timestamp() << L"\n";
        }
        ApplyRestrictedAcl(metadata, false);

        file.reset();
        // A quarentena desta versao e nao destrutiva: o original permanece no lugar.
        // O artefato criptografado serve como evidencia/backup e pode ser removido
        // ou restaurado por uma rotina de administracao posterior.
        gLogger.Write(L"Quarentena concluida sem apagar o original: " + expected.path);
        return true;
    }
};

// -----------------------------------------------------------------------------
// Janela de decisao
// -----------------------------------------------------------------------------

constexpr int IDC_INFO = 1001;
constexpr int IDC_ALLOW_ONCE = 1002;
constexpr int IDC_ALLOW_ALWAYS = 1003;
constexpr int IDC_QUARANTINE = 1004;
constexpr int IDC_TERMINATE = 1005;
constexpr int IDC_DESCENDANTS = 1006;
constexpr int IDC_POLICY = 1007;
constexpr int IDC_SEARCH_WEB = 1008;

struct DialogState {
    DecisionRequest* request = nullptr;
    HWND info = nullptr;
    HWND descendants = nullptr;
    HWND policy = nullptr;
};

LRESULT CALLBACK DecisionWindowProc(HWND window, UINT message,
                                    WPARAM wParam, LPARAM lParam) {
    auto state = reinterpret_cast<DialogState*>(
        GetWindowLongPtrW(window, GWLP_USERDATA));

    if (message == WM_CREATE) {
        auto create = reinterpret_cast<CREATESTRUCTW*>(lParam);
        state = reinterpret_cast<DialogState*>(create->lpCreateParams);
        SetWindowLongPtrW(window, GWLP_USERDATA,
                          reinterpret_cast<LONG_PTR>(state));

        HFONT font = static_cast<HFONT>(
            GetStockObject(DEFAULT_GUI_FONT));

        state->info = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE |
            ES_READONLY | ES_AUTOVSCROLL,
            16, 16, 668, 310, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_INFO)), nullptr, nullptr);

        state->descendants = CreateWindowW(L"BUTTON",
            L"Confiar também nos processos auxiliares",
            WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
            16, 338, 330, 24, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_DESCENDANTS)), nullptr, nullptr);

        state->policy = CreateWindowW(WC_COMBOBOXW, L"",
            WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
            360, 336, 324, 120, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_POLICY)), nullptr, nullptr);

        SendMessageW(state->policy, CB_ADDSTRING, 0,
                     reinterpret_cast<LPARAM>(L"Somente processos da mesma pasta"));
        SendMessageW(state->policy, CB_ADDSTRING, 0,
                     reinterpret_cast<LPARAM>(L"Todos os descendentes"));
        SendMessageW(state->policy, CB_SETCURSEL, 0, 0);
        EnableWindow(state->policy, FALSE);

        CreateWindowW(L"BUTTON", L"Permitir uma vez",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            16, 382, 155, 38, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_ALLOW_ONCE)), nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"Permitir sempre",
            WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
            181, 382, 155, 38, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_ALLOW_ALWAYS)), nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"Quarentena",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            346, 382, 155, 38, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_QUARANTINE)), nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"Encerrar",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            511, 382, 173, 38, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_TERMINATE)), nullptr, nullptr);
        CreateWindowW(L"BUTTON", L"PESQUISAR NA INTERNET",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            16, 424, 250, 38, window,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(IDC_SEARCH_WEB)), nullptr, nullptr);

        for (HWND child = GetWindow(window, GW_CHILD); child;
             child = GetWindow(child, GW_HWNDNEXT))
            SendMessageW(child, WM_SETFONT,
                         reinterpret_cast<WPARAM>(font), TRUE);

        const auto& r = *state->request;
        std::wostringstream text;
        text << L"PROGRAMA EM ANÁLISE\r\n\r\n"
             << L"Nome: " << fs::path(r.identity.path).filename().wstring()
             << L"\r\n"
             << L"Editor: " << r.identity.publisher << L"\r\n"
             << L"Local: " << r.identity.path << L"\r\n"
             << L"PID: " << r.process.pid
             << L"    Processo pai: " << r.process.parentPid << L"\r\n"
             << L"Origem: "
             << (r.process.parentPath.empty()
                    ? L"Não identificada" : r.process.parentPath)
             << L"\r\n"
             << L"Assinatura: "
             << (r.identity.signatureValid ? L"Válida" : L"Ausente ou inválida")
             << L"\r\n"
             << L"Microsoft Defender/MSE: "
             << ScanResultText(r.scan.result) << L"\r\n"
             << L"Código: " << Hex32(r.scan.exitCode) << L"\r\n"
             << L"Detalhes: " << r.scan.details << L"\r\n\r\n"
             << L"SHA-256:\r\n" << r.identity.sha256 << L"\r\n\r\n"
             << L"O processo está em CATIVEIRO ENDURECIDO: breakaway não autorizado, "
             << L"descendentes mantidos na cadeia e acesso por handles externos restrito."
             << L"\r\n\r\n"
             << L"Observação: Permitir não desanexa um processo de um Job Object já atribuído; "
             << L"o processo continuará sob as proteções do cativeiro até terminar."
             << L"\r\n\r\nPesquise o arquivo na Internet antes de decidir.";

        SetWindowTextW(state->info, text.str().c_str());
        return 0;
    }

    if (!state) return DefWindowProcW(window, message, wParam, lParam);

    if (message == WM_COMMAND) {
        int id = LOWORD(wParam);
        if (id == IDC_DESCENDANTS) {
            BOOL checked = Button_GetCheck(state->descendants) == BST_CHECKED;
            EnableWindow(state->policy, checked);
            return 0;
        }

        if (id == IDC_SEARCH_WEB) {
            if (!OpenInternetResearch(state->request->identity)) {
                MessageBoxW(window,
                    L"Não foi possível abrir o navegador.",
                    L"Vistas Defender", MB_OK | MB_ICONWARNING);
            }
            return 0;
        }


        if (id == IDC_ALLOW_ONCE || id == IDC_ALLOW_ALWAYS ||
            id == IDC_QUARANTINE || id == IDC_TERMINATE) {
            if (id == IDC_ALLOW_ONCE)
                state->request->decision = UserDecision::AllowOnce;
            else if (id == IDC_ALLOW_ALWAYS)
                state->request->decision = UserDecision::AllowAlways;
            else if (id == IDC_QUARANTINE)
                state->request->decision = UserDecision::Quarantine;
            else
                state->request->decision = UserDecision::Terminate;

            state->request->descendantPolicy = DescendantPolicy::None;
            if (id == IDC_ALLOW_ALWAYS &&
                Button_GetCheck(state->descendants) == BST_CHECKED) {
                LRESULT selected = SendMessageW(state->policy,
                                                CB_GETCURSEL, 0, 0);
                state->request->descendantPolicy =
                    selected == 1
                    ? DescendantPolicy::AllDescendants
                    : DescendantPolicy::SameExecutableDirectory;
            }

            DestroyWindow(window);
            return 0;
        }
    }

    if (message == WM_CLOSE) {
        state->request->decision = UserDecision::Terminate;
        DestroyWindow(window);
        return 0;
    }

    if (message == WM_DESTROY) {
        if (state->request->completed)
            SetEvent(state->request->completed);
        return 0;
    }

    return DefWindowProcW(window, message, wParam, lParam);
}

UserDecision ShowDecisionDialog(DecisionRequest& request,
                                DescendantPolicy& policy) {
    INITCOMMONCONTROLSEX controls{};
    controls.dwSize = sizeof(controls);
    controls.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&controls);

    static std::once_flag registered;
    std::call_once(registered, [] {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = DecisionWindowProc;
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hIcon = LoadIconW(nullptr, IDI_WARNING);
        wc.hbrBackground =
            reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
        wc.lpszClassName = L"Macrobyte.VistasDefender.Decision.v7";
        RegisterClassExW(&wc);
    });

    DialogState state;
    state.request = &request;

    HWND window = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_DLGMODALFRAME,
        L"Macrobyte.VistasDefender.Decision.v7",
        L"Vistas Defender — Processo em cativeiro",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
        CW_USEDEFAULT, CW_USEDEFAULT, 720, 500,
        nullptr, nullptr, GetModuleHandleW(nullptr), &state);

    if (!window) return UserDecision::Terminate;

    RECT rect{};
    GetWindowRect(window, &rect);
    int x = (GetSystemMetrics(SM_CXSCREEN) - (rect.right - rect.left)) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - (rect.bottom - rect.top)) / 2;
    SetWindowPos(window, HWND_TOPMOST, x, y, 0, 0,
                 SWP_NOSIZE | SWP_SHOWWINDOW);
    SetForegroundWindow(window);

    MSG message{};
    while (IsWindow(window) && GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }

    policy = request.descendantPolicy;
    return request.decision;
}

// -----------------------------------------------------------------------------
// Fila de eventos de processos
// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------
// Contencao adaptativa
// -----------------------------------------------------------------------------

std::string WideToUtf8(const std::wstring& value) {
    if (value.empty()) return {};
    int needed = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS,
                                     value.c_str(), static_cast<int>(value.size()),
                                     nullptr, 0, nullptr, nullptr);
    if (needed <= 0) return {};
    std::string result(static_cast<size_t>(needed), '\0');
    WideCharToMultiByte(CP_UTF8, 0, value.c_str(), static_cast<int>(value.size()),
                        result.data(), needed, nullptr, nullptr);
    return result;
}

std::wstring UrlEncodeUtf8(const std::wstring& value) {
    const std::string utf8 = WideToUtf8(value);
    std::wostringstream out;
    static const wchar_t hex[] = L"0123456789ABCDEF";
    for (unsigned char c : utf8) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' ||
            c == '.' || c == '~') {
            out << static_cast<wchar_t>(c);
        } else {
            out << L'%' << hex[(c >> 4) & 0x0F] << hex[c & 0x0F];
        }
    }
    return out.str();
}

bool OpenInternetResearch(const FileIdentity& identity) {
    const std::wstring fileName =
        fs::path(identity.path).filename().wstring();
    const std::wstring query =
        fileName + L" " + identity.publisher + L" SHA256 " + identity.sha256;
    const std::wstring url =
        L"https://www.google.com/search?q=" + UrlEncodeUtf8(query);
    const HINSTANCE result = ShellExecuteW(
        nullptr, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    return reinterpret_cast<INT_PTR>(result) > 32;
}

class FirewallBlocker {
public:
    bool BlockApplication(const std::wstring& path,
                          DWORD pid,
                          std::vector<std::wstring>& ruleNames) {
        ruleNames.clear();
        if (!EnsurePolicy()) return false;

        const std::wstring prefix =
            L"OArthurMamaco.VistasDefender.Captive." + std::to_wstring(pid) + L".";
        bool ok = true;
        ok = AddRule(path, prefix + L"IN", NET_FW_RULE_DIR_IN) && ok;
        ok = AddRule(path, prefix + L"OUT", NET_FW_RULE_DIR_OUT) && ok;
        if (ok) {
            ruleNames.push_back(prefix + L"IN");
            ruleNames.push_back(prefix + L"OUT");
        } else {
            RemoveRules({prefix + L"IN", prefix + L"OUT"});
        }
        return ok;
    }

    void RemoveRules(const std::vector<std::wstring>& ruleNames) {
        if (!EnsurePolicy()) return;
        INetFwRules* rules = nullptr;
        if (FAILED(policy_->get_Rules(&rules)) || !rules) return;
        for (const auto& name : ruleNames) {
            BSTR b = SysAllocString(name.c_str());
            if (b) {
                rules->Remove(b);
                SysFreeString(b);
            }
        }
        rules->Release();
    }

    void RemoveStaleRules() {
        if (!EnsurePolicy()) return;
        INetFwRules* rules = nullptr;
        if (FAILED(policy_->get_Rules(&rules)) || !rules) return;
        IUnknown* unknown = nullptr;
        IEnumVARIANT* enumerator = nullptr;
        if (SUCCEEDED(rules->get__NewEnum(&unknown)) && unknown) {
            unknown->QueryInterface(IID_PPV_ARGS(&enumerator));
            unknown->Release();
        }
        if (!enumerator) { rules->Release(); return; }

        std::vector<std::wstring> stale;
        VARIANT item;
        VariantInit(&item);
        ULONG fetched = 0;
        while (enumerator->Next(1, &item, &fetched) == S_OK) {
            if (item.pdispVal) {
                INetFwRule* rule = nullptr;
                if (SUCCEEDED(item.pdispVal->QueryInterface(IID_PPV_ARGS(&rule))) && rule) {
                    BSTR name = nullptr;
                    if (SUCCEEDED(rule->get_Name(&name)) && name) {
                        const std::wstring ruleName(name, SysStringLen(name));
                        if (ruleName.rfind(L"OArthurMamaco.VistasDefender.Captive.", 0) == 0)
                            stale.push_back(ruleName);
                        SysFreeString(name);
                    }
                    rule->Release();
                }
            }
            VariantClear(&item);
        }
        enumerator->Release();
        rules->Release();
        RemoveRules(stale);
    }

private:
    bool EnsurePolicy() {
        if (policy_) return true;
        HRESULT hr = CoCreateInstance(__uuidof(NetFwPolicy2), nullptr,
                                      CLSCTX_INPROC_SERVER,
                                      IID_PPV_ARGS(&policy_));
        return SUCCEEDED(hr) && policy_ != nullptr;
    }

    bool AddRule(const std::wstring& path,
                 const std::wstring& name,
                 NET_FW_RULE_DIRECTION direction) {
        if (!EnsurePolicy()) return false;
        INetFwRules* rules = nullptr;
        if (FAILED(policy_->get_Rules(&rules)) || !rules) return false;
        INetFwRule* rule = nullptr;
        HRESULT hr = CoCreateInstance(__uuidof(NetFwRule), nullptr,
                                      CLSCTX_INPROC_SERVER,
                                      IID_PPV_ARGS(&rule));
        if (FAILED(hr) || !rule) {
            rules->Release();
            return false;
        }

        auto setBstr = [](BSTR* target, const std::wstring& value) -> bool {
            if (!target) return false;
            *target = SysAllocString(value.c_str());
            return *target != nullptr;
        };

        BSTR bName = nullptr, bDescription = nullptr, bApplication = nullptr;
        const std::wstring description = L"Vistas Defender adaptive captive containment";
        bool ok = setBstr(&bName, name) &&
                  setBstr(&bDescription, description) &&
                  setBstr(&bApplication, path);
        if (ok) {
            ok = SUCCEEDED(rule->put_Name(bName)) &&
                 SUCCEEDED(rule->put_Description(bDescription)) &&
                 SUCCEEDED(rule->put_ApplicationName(bApplication)) &&
                 SUCCEEDED(rule->put_Protocol(NET_FW_IP_PROTOCOL_ANY)) &&
                 SUCCEEDED(rule->put_Direction(direction)) &&
                 SUCCEEDED(rule->put_Action(NET_FW_ACTION_BLOCK)) &&
                 SUCCEEDED(rule->put_Enabled(VARIANT_TRUE)) &&
                 SUCCEEDED(rule->put_Profiles(NET_FW_PROFILE2_ALL)) &&
                 SUCCEEDED(rules->Add(rule));
        }
        if (bName) SysFreeString(bName);
        if (bDescription) SysFreeString(bDescription);
        if (bApplication) SysFreeString(bApplication);
        rule->Release();
        rules->Release();
        return ok;
    }

    INetFwPolicy2* policy_ = nullptr;
};

struct CaptiveContext {
    DWORD pid = 0;
    fs::path path;
    UniqueHandle job;
    std::vector<std::wstring> firewallRules;
    bool jobAssigned = false;
    bool jobHandleRestriction = false;
    bool killOnClose = false;
    bool networkBlocked = false;
};

class ProcessEventQueue {
public:
    void Push(DWORD pid) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!queued_.insert(pid).second) return;
        if (queue_.size() >= 2048) {
            queued_.erase(pid);
            return;
        }
        queue_.push(pid);
        SetEvent(event_.get());
    }

    std::optional<DWORD> Pop(DWORD timeout) {
        DWORD wait = WaitForSingleObject(event_.get(), timeout);
        if (wait != WAIT_OBJECT_0) return std::nullopt;

        std::lock_guard<std::mutex> lock(mutex_);
        if (queue_.empty()) {
            ResetEvent(event_.get());
            return std::nullopt;
        }
        DWORD pid = queue_.front();
        queue_.pop();
        queued_.erase(pid);
        if (queue_.empty()) ResetEvent(event_.get());
        return pid;
    }

private:
    UniqueHandle event_{CreateEventW(nullptr, TRUE, FALSE, nullptr)};
    std::mutex mutex_;
    std::queue<DWORD> queue_;
    std::set<DWORD> queued_;
};

class WmiProcessWatcher {
public:
    WmiProcessWatcher(ProcessEventQueue& queue,
                      std::atomic<bool>& running)
        : queue_(queue), running_(running) {}

    bool Run() {
        HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        bool uninitialize = SUCCEEDED(hr);
        if (FAILED(hr) && hr != RPC_E_CHANGED_MODE) return false;

        hr = CoInitializeSecurity(nullptr, -1, nullptr, nullptr,
            RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE,
            nullptr, EOAC_NONE, nullptr);
        if (FAILED(hr) && hr != RPC_E_TOO_LATE) {
            if (uninitialize) CoUninitialize();
            return false;
        }

        IWbemLocator* rawLocator = nullptr;
        hr = CoCreateInstance(CLSID_WbemLocator, nullptr,
            CLSCTX_INPROC_SERVER, IID_IWbemLocator,
            reinterpret_cast<void**>(&rawLocator));
        if (FAILED(hr)) {
            if (uninitialize) CoUninitialize();
            return false;
        }
        _com_ptr_t<_com_IIID<IWbemLocator, &IID_IWbemLocator>>
            locator(rawLocator, false);

        IWbemServices* rawServices = nullptr;
        hr = locator->ConnectServer(
            _bstr_t(L"ROOT\\CIMV2"), nullptr, nullptr, nullptr,
            0, nullptr, nullptr, &rawServices);
        if (FAILED(hr)) {
            if (uninitialize) CoUninitialize();
            return false;
        }
        _com_ptr_t<_com_IIID<IWbemServices, &IID_IWbemServices>>
            services(rawServices, false);

        hr = CoSetProxyBlanket(services, RPC_C_AUTHN_WINNT,
            RPC_C_AUTHZ_NONE, nullptr, RPC_C_AUTHN_LEVEL_CALL,
            RPC_C_IMP_LEVEL_IMPERSONATE, nullptr, EOAC_NONE);
        if (FAILED(hr)) {
            if (uninitialize) CoUninitialize();
            return false;
        }

        IEnumWbemClassObject* rawEnumerator = nullptr;
        hr = services->ExecNotificationQuery(
            _bstr_t(L"WQL"),
            _bstr_t(L"SELECT ProcessID FROM Win32_ProcessStartTrace"),
            WBEM_FLAG_RETURN_IMMEDIATELY | WBEM_FLAG_FORWARD_ONLY,
            nullptr, &rawEnumerator);
        if (FAILED(hr)) {
            if (uninitialize) CoUninitialize();
            return false;
        }
        _com_ptr_t<_com_IIID<IEnumWbemClassObject,
                             &IID_IEnumWbemClassObject>>
            enumerator(rawEnumerator, false);

        while (running_) {
            IWbemClassObject* object = nullptr;
            ULONG returned = 0;
            hr = enumerator->Next(500, 1, &object, &returned);
            if (hr == WBEM_S_TIMEDOUT) continue;
            if (FAILED(hr)) break;
            if (!returned || !object) continue;

            VARIANT value;
            VariantInit(&value);
            if (SUCCEEDED(object->Get(L"ProcessID", 0, &value,
                                      nullptr, nullptr))) {
                DWORD pid = 0;
                if (value.vt == VT_I4 || value.vt == VT_UI4)
                    pid = value.ulVal;
                else if (value.vt == VT_I8 || value.vt == VT_UI8)
                    pid = static_cast<DWORD>(value.ullVal);
                if (pid) queue_.Push(pid);
            }
            VariantClear(&value);
            object->Release();
        }

        if (uninitialize) CoUninitialize();
        return true;
    }

private:
    ProcessEventQueue& queue_;
    std::atomic<bool>& running_;
};

// -----------------------------------------------------------------------------
// Motor
// -----------------------------------------------------------------------------

class DefenderEngine {
public:
    DefenderEngine() : os_(DetectWindowsVersion()) {
        RegisterInternalComponents();
    }

    ~DefenderEngine() {
        running_ = false;
        ReleaseAllCaptives();
    }

    int Run() {
        const HRESULT comStatus = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool uninitializeCom = SUCCEEDED(comStatus);
        firewall_.RemoveStaleRules();

        if (os_.family == WindowsFamily::Unsupported) {
            MessageBoxW(nullptr,
                L"Esta versão exige Windows 7 SP1 ou superior.",
                kProductName, MB_OK | MB_ICONERROR);
            if (uninitializeCom) CoUninitialize();
            return ERROR_OLD_WIN_VERSION;
        }

        EnsureProtectedDirectories();
        gLogger.Write(L"Iniciado em " + os_.displayName);

        knownProcesses_ = SnapshotProcesses();

        std::thread watcher([this] {
            WmiProcessWatcher wmi(events_, running_);
            bool worked = wmi.Run();
            if (!worked && running_) {
                gLogger.Write(L"WMI indisponível; ativando fallback de 1000 ms.");
                PollingFallback();
            }
        });

        while (running_) {
            auto pid = events_.Pop(500);
            CleanupTemporaryPermissions();
            if (!pid) continue;
            HandleNewProcess(*pid);
        }

        if (watcher.joinable()) watcher.join();
        if (uninitializeCom) CoUninitialize();
        return 0;
    }

private:
    void RegisterInternalComponents() {
        // Registra no Defender.dnt os componentes oficiais encontrados
        // na mesma pasta do Defender.exe. A confiança usa caminho + hash +
        // tamanho + data; o nome sozinho nunca é suficiente.
        const std::vector<std::wstring> internalNames = {
            L"Defender.exe",
            L"VistasUI.exe",
            L"VistasDefenderService.exe",
            L"VistasDefenderAlert.exe"
        };

        for (const auto& name : internalNames) {
            fs::path candidate = ApplicationDirectory() / name;
            std::error_code ec;
            if (!fs::exists(candidate, ec) ||
                !fs::is_regular_file(candidate, ec))
                continue;

            auto identity = ReadIdentity(candidate.wstring());
            if (!identity) {
                gLogger.Write(L"Não foi possível registrar componente interno: " +
                              candidate.wstring());
                continue;
            }

            auto existing = database_.Find(*identity);
            if (!existing ||
                existing->kind != TrustRecordKind::InternalIgnore) {
                database_.SaveInternal(*identity);
                gLogger.Write(L"Componente interno registrado no Defender.dnt: " +
                              candidate.wstring());
            }
        }
    }

    void PollingFallback() {
        std::map<DWORD, ProcessInfo> known = SnapshotProcesses();
        while (running_) {
            auto current = SnapshotProcesses();
            for (const auto& item : current) {
                if (!known.count(item.first)) events_.Push(item.first);
            }
            known = std::move(current);
            Sleep(kFallbackPollingMs);
        }
    }

    bool IsProtectedWindowsBinary(const std::wstring& path) const {
        if (path.empty()) return false;
        wchar_t windowsBuffer[MAX_PATH]{};
        const UINT windowsLength = GetWindowsDirectoryW(windowsBuffer, MAX_PATH);
        if (!windowsLength || windowsLength >= MAX_PATH) return false;
        const fs::path root(windowsBuffer);
        const std::wstring normalizedParent = NormalizePath(fs::path(path).parent_path().wstring());
        const std::wstring system32 = NormalizePath((root / L"System32").wstring());
        const std::wstring syswow64 = NormalizePath((root / L"SysWOW64").wstring());
        const std::wstring servicing = NormalizePath((root / L"servicing").wstring());
        const std::wstring windowsRoot = NormalizePath(root.wstring());
        const std::wstring winsxsPrefix = NormalizePath((root / L"WinSxS").wstring()) + L"\\";
        static const std::set<std::wstring> systemNames = {
            L"smss.exe", L"csrss.exe", L"wininit.exe", L"services.exe",
            L"lsass.exe", L"winlogon.exe", L"dwm.exe", L"fontdrvhost.exe",
            L"svchost.exe", L"conhost.exe", L"dllhost.exe", L"taskhostw.exe",
            L"runtimebroker.exe", L"applicationframehost.exe", L"backgroundtaskhost.exe",
            L"sihost.exe", L"ctfmon.exe", L"spoolsv.exe", L"usoclient.exe",
            L"trustedinstaller.exe", L"tiworker.exe"
        };
        static const std::set<std::wstring> windowsRootNames = { L"explorer.exe" };
        const std::wstring name = ToLower(fs::path(path).filename().wstring());
        if (!systemNames.count(name) && !windowsRootNames.count(name)) return false;

        bool inExpectedLocation = false;
        if (name == L"trustedinstaller.exe" || name == L"tiworker.exe") {
            const std::wstring normalizedFull = NormalizePath(path);
            inExpectedLocation = normalizedParent == servicing ||
                normalizedFull.rfind(winsxsPrefix, 0) == 0;
        } else if (windowsRootNames.count(name))
            inExpectedLocation = normalizedParent == windowsRoot;
        else
            inExpectedLocation = (normalizedParent == system32 || normalizedParent == syswow64);
        if (!inExpectedLocation) return false;

        // A basename alone is never enough: require a canonical Windows location,
        // valid Authenticode, and a Microsoft signer to avoid spoofed-name bypasses.
        if (!VerifyAuthenticode(path)) return false;
        return _wcsicmp(ReadPublisherOrganization(path).c_str(), L"Microsoft Corporation") == 0;
    }

    bool IsNativeAntimalwareBinary(const std::wstring& path) const {
        if (path.empty()) return false;
        const std::wstring name = ToLower(fs::path(path).filename().wstring());
        static const std::set<std::wstring> names = {
            L"mpcmdrun.exe", L"msmpeng.exe", L"mpdefendercoreservice.exe",
            L"nissrv.exe", L"nisserv.exe", L"msseces.exe"
        };
        if (!names.count(name)) return false;

        auto knownFolder = [](REFKNOWNFOLDERID id) -> std::wstring {
            PWSTR raw = nullptr;
            if (FAILED(SHGetKnownFolderPath(id, KF_FLAG_DEFAULT, nullptr, &raw)) || !raw)
                return L"";
            std::wstring value(raw);
            CoTaskMemFree(raw);
            return value;
        };
        const std::wstring normalized = NormalizePath(path);
        const std::wstring programData = knownFolder(FOLDERID_ProgramData);
        const std::wstring programFiles = knownFolder(FOLDERID_ProgramFiles);
        const std::wstring programFilesX86 = knownFolder(FOLDERID_ProgramFilesX86);
        bool canonical = false;

        // Defender's current platform binaries live in a version-named direct child
        // of ProgramData\Microsoft\Windows Defender\Platform.
        if (!programData.empty()) {
            const std::wstring platform = NormalizePath((fs::path(programData) / L"Microsoft" / L"Windows Defender" / L"Platform").wstring());
            const std::wstring prefix = platform + L"\\";
            if (normalized.rfind(prefix, 0) == 0) {
                const std::wstring relative = normalized.substr(prefix.size());
                const size_t separator = relative.find(L'\\');
                if (separator != std::wstring::npos && relative.find(L'\\', separator + 1) == std::wstring::npos) {
                    const std::wstring versionFolder = relative.substr(0, separator);
                    bool hasDigit = false, validVersion = !versionFolder.empty();
                    for (wchar_t c : versionFolder) {
                        if (c >= L'0' && c <= L'9') hasDigit = true;
                        else if (c != L'.' && c != L'-' && c != L'_') validVersion = false;
                    }
                    canonical = validVersion && hasDigit && ToLower(relative.substr(separator + 1)) == name;
                }
            }
        }

        auto inExactFolder = [&](const std::wstring& base, const std::wstring& relative) {
            return !base.empty() && normalized == NormalizePath((fs::path(base) / relative / name).wstring());
        };
        canonical = canonical || inExactFolder(programFiles, L"Windows Defender") ||
            inExactFolder(programFiles, L"Microsoft Security Client\\Antimalware") ||
            inExactFolder(programFiles, L"Microsoft Security Client") ||
            inExactFolder(programFilesX86, L"Microsoft Security Client\\Antimalware") ||
            inExactFolder(programFilesX86, L"Microsoft Security Client");
        if (!canonical || !VerifyAuthenticode(path)) return false;
        return _wcsicmp(ReadPublisherOrganization(path).c_str(), L"Microsoft Corporation") == 0;
    }

    bool IsInternalOrIgnored(DWORD pid, const std::wstring& path) const {
        if (pid <= 4 || pid == GetCurrentProcessId() || path.empty()) return true;
        const std::wstring enginePath = NormalizePath((ApplicationDirectory() / L"Defender.exe").wstring());
        if (NormalizePath(path) == enginePath) return true;

        // Windows and antimalware components are exempt only by canonical path plus
        // a valid Microsoft signature; names found in writable folders are not trusted.
        if (IsProtectedWindowsBinary(path) || IsNativeAntimalwareBinary(path)) return true;
        return false;
    }

    DWORD GetProtectionMode() const {
        DWORD mode = 1; // balanced default
        DWORD type = 0, bytes = sizeof(mode);
        if (RegGetValueW(HKEY_LOCAL_MACHINE, kSettingsRegistryKey, L"ProtectionMode",
                         RRF_RT_REG_DWORD, &type, &mode, &bytes) != ERROR_SUCCESS || mode > 2)
            return 1;
        return mode;
    }

    std::optional<ProcessInfo> ResolveProcess(DWORD pid) {
        for (int attempt = 0; attempt < 10; ++attempt) {
            auto snapshot = SnapshotProcesses();
            auto it = snapshot.find(pid);
            if (it != snapshot.end() && !it->second.path.empty())
                return it->second;
            Sleep(10);
        }
        return std::nullopt;
    }

    bool DescendantInheritedTrust(const ProcessInfo& process,
                                  const FileIdentity& identity) {
        std::lock_guard<std::mutex> lock(stateMutex_);
        auto it = trustedRunning_.find(process.parentPid);
        if (it == trustedRunning_.end()) return false;

        DescendantPolicy policy = it->second.policy;
        if (policy == DescendantPolicy::None) return false;

        if (policy == DescendantPolicy::SameExecutableDirectory) {
            fs::path parentDirectory =
                fs::path(it->second.path).parent_path();
            fs::path childDirectory =
                fs::path(identity.normalizedPath).parent_path();
            if (NormalizePath(parentDirectory.wstring()) !=
                NormalizePath(childDirectory.wstring()))
                return false;
        }

        trustedRunning_[process.pid] =
            { identity.normalizedPath, policy };
        return true;
    }

    void MarkRunningTrusted(DWORD pid, const FileIdentity& identity,
                            DescendantPolicy policy) {
        std::lock_guard<std::mutex> lock(stateMutex_);
        trustedRunning_[pid] = { identity.normalizedPath, policy };
    }

    bool ShouldEnterCaptive(const FileIdentity& identity,
                            const NativeDefenderScanResult& scan) const {
        // The signed canonical Windows-service exemption is checked before scanning,
        // but keep this guard here too in case callers change in a future release.
        if (IsProtectedWindowsBinary(identity.path)) return false;
        if (scan.result == NativeDefenderResult::Excluded) {
            // An exclusion means no scan result exists for this path. Balanced and
            // Strict therefore require an explicit user decision regardless of signature.
            return GetProtectionMode() != 0;
        }
        const DWORD mode = GetProtectionMode();
        if (mode == 0) {
            // Observation mode never blocks on ambiguous evidence.
            return false;
        }
        if (mode == 2) {
            // Strict mode asks for a decision on every non-protected process.
            return true;
        }
        // Balanced mode: allow signed programs after a completed scan; unknown,
        // unsigned, failed, timed-out or ambiguous scans require a user decision.
        if (scan.result == NativeDefenderResult::ScanCompleted && identity.signatureValid)
            return false;
        return true;
    }

    bool ConfigureCaptiveJob(CaptiveContext& context) {
        context.job.reset(CreateJobObjectW(nullptr, nullptr));
        if (!context.job) {
            gLogger.Write(L"Falha ao criar Job Object para o cativeiro: " +
                          std::to_wstring(GetLastError()));
            return false;
        }

        // Não habilitamos BREAKAWAY_OK nem SILENT_BREAKAWAY_OK.
        // Filhos criados pelo processo cativo herdam o Job; uma tentativa de
        // breakaway não autorizado deve falhar no próprio Windows.
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
        limits.BasicLimitInformation.LimitFlags =
            JOB_OBJECT_LIMIT_ACTIVE_PROCESS |
            JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE |
            JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION;
        limits.BasicLimitInformation.ActiveProcessLimit = 32;

        if (!SetInformationJobObject(context.job.get(),
                                      JobObjectExtendedLimitInformation,
                                      &limits, sizeof(limits))) {
            gLogger.Write(L"Falha ao configurar limites do cativeiro: " +
                          std::to_wstring(GetLastError()));
            context.job.reset();
            return false;
        }

        // Endurece a fronteira de UI/objetos USER do Job e isola global atoms.
        // Isso reduz IPC via USER handles, mensagens/hooks e tabelas de
        // global atoms. Não bloqueia named pipes, COM/RPC ou memória
        // compartilhada de forma genérica.
        JOBOBJECT_BASIC_UI_RESTRICTIONS ui{};
        ui.UIRestrictionsClass =
            JOB_OBJECT_UILIMIT_HANDLES | JOB_OBJECT_UILIMIT_GLOBALATOMS;
        if (!SetInformationJobObject(context.job.get(),
                                      JobObjectBasicUIRestrictions,
                                      &ui, sizeof(ui))) {
            gLogger.Write(L"Falha ao aplicar restrição de handles do cativeiro: " +
                          std::to_wstring(GetLastError()));
            context.job.reset();
            return false;
        }

        context.jobHandleRestriction = true;
        context.killOnClose = true;
        return true;
    }

    bool EnterCaptive(const ProcessInfo& process, const FileIdentity& identity) {
        if (captive_.count(process.pid)) return true;

        auto context = std::make_unique<CaptiveContext>();
        context->pid = process.pid;
        context->path = identity.path;

        if (!ConfigureCaptiveJob(*context))
            return false;

        UniqueHandle target(OpenProcess(
            PROCESS_SET_QUOTA | PROCESS_TERMINATE | SYNCHRONIZE |
            PROCESS_QUERY_LIMITED_INFORMATION,
            FALSE, process.pid));

        if (!target ||
            !AssignProcessToJobObject(context->job.get(), target.get())) {
            const DWORD error = GetLastError();
            gLogger.Write(L"Falha ao anexar processo ao cativeiro: PID " +
                          std::to_wstring(process.pid) + L", erro " +
                          std::to_wstring(error));
            // KILL_ON_JOB_CLOSE garante que qualquer descendente já criado
            // dentro deste Job não ficará vivo quando o contexto for fechado.
            context->job.reset();
            return false;
        }
        context->jobAssigned = true;

        BOOL inJob = FALSE;
        if (!IsProcessInJob(target.get(), context->job.get(), &inJob) || !inJob) {
            gLogger.Write(L"Verificação pós-anexo falhou; encerrando PID " +
                          std::to_wstring(process.pid));
            context->job.reset();
            return false;
        }

        // O firewall continua sendo uma camada de defesa complementar. O
        // cativeiro principal não depende dele para existir.
        context->networkBlocked =
            firewall_.BlockApplication(identity.path, process.pid,
                                       context->firewallRules);

        captive_[process.pid] = std::move(context);
        gLogger.Write(L"Processo colocado em cativeiro endurecido: " + identity.path);
        if (!captive_[process.pid]->networkBlocked)
            gLogger.Write(L"Aviso: bloqueio de rede não aplicado; Job Object segue ativo.");
        return true;
    }

    bool DisarmKillOnClose(CaptiveContext& context) {
        if (!context.job || !context.killOnClose) return true;

        JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
        if (!QueryInformationJobObject(context.job.get(),
                                       JobObjectExtendedLimitInformation,
                                       &limits, sizeof(limits), nullptr)) {
            gLogger.Write(L"Falha ao preparar liberação do cativeiro: " +
                          std::to_wstring(GetLastError()));
            return false;
        }

        limits.BasicLimitInformation.LimitFlags &=
            ~JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;

        if (!SetInformationJobObject(context.job.get(),
                                      JobObjectExtendedLimitInformation,
                                      &limits, sizeof(limits))) {
            gLogger.Write(L"Falha ao remover KILL_ON_JOB_CLOSE antes da liberação: " +
                          std::to_wstring(GetLastError()));
            return false;
        }

        context.killOnClose = false;
        return true;
    }

    void ReleaseCaptive(DWORD pid) {
        auto it = captive_.find(pid);
        if (it == captive_.end()) return;

        // Um processo não pode ser simplesmente "desanexado" de um Job Object.
        // Para decisões de permissão, desarmamos apenas o kill-on-close e então
        // liberamos a referência ao Job; para decisões de bloqueio, o processo
        // deve ser encerrado antes desta função.
        const bool safeToRelease = DisarmKillOnClose(*it->second);
        if (!safeToRelease) {
            TerminateProcessSafe(pid);
        }

        firewall_.RemoveRules(it->second->firewallRules);
        captive_.erase(it);
        gLogger.Write(L"Cativeiro encerrado: PID " +
                      std::to_wstring(pid));
    }

    void ReleaseAllCaptives() {
        for (auto& item : captive_)
            firewall_.RemoveRules(item.second->firewallRules);
        captive_.clear();
    }

    void HandleNewProcess(DWORD pid) {
        auto process = ResolveProcess(pid);
        if (!process || IsInternalOrIgnored(pid, process->path)) return;

        // Filhos e netos criados por um processo cativo normalmente já entram
        // no Job Object por herança. Eles não precisam de um segundo Job.
        // Apenas registramos a herança e deixamos a barreira existente fazer
        // a contenção; a reconciliação periódica verificará eventual escape.
        if (IsAlreadyContained(pid)) {
            gLogger.Write(L"Processo já contido por herança do cativeiro: PID " +
                          std::to_wstring(pid));
            return;
        }

        {
            std::lock_guard<std::mutex> lock(stateMutex_);
            if (temporaryAllowedPids_.count(pid)) return;
        }

        auto identity = ReadIdentity(process->path);
        if (!identity) {
            gLogger.Write(L"Identidade indisponível: " + process->path);
            return;
        }

        if (IsProtectedWindowsBinary(identity->path) && identity->signatureValid &&
            ToLower(identity->publisher).find(L"microsoft") != std::wstring::npos) {
            MarkRunningTrusted(pid, *identity, DescendantPolicy::None);
            gLogger.Write(L"Binário Windows assinado, no caminho canônico; ignorado para evitar falso positivo: " + process->path);
            return;
        }

        if (DescendantInheritedTrust(*process, *identity)) {
            gLogger.Write(L"Descendente autorizado pela política: " +
                          process->path);
            return;
        }

        if (auto record = database_.Find(*identity)) {
            MarkRunningTrusted(pid, *identity, record->descendantPolicy);
            if (record->kind == TrustRecordKind::InternalIgnore)
                gLogger.Write(L"Componente interno ignorado pelo Defender.dnt: " +
                              process->path);
            else
                gLogger.Write(L"Arquivo permitido permanentemente pelo Defender.dnt: " +
                              process->path);
            return;
        }

        NativeDefenderScanResult scan =
            ScanWithNativeDefender(os_, identity->path);

        if (!ShouldEnterCaptive(*identity, scan)) {
            MarkRunningTrusted(pid, *identity, DescendantPolicy::None);
            gLogger.Write(L"Liberado automaticamente por identidade confiável: " +
                          process->path);
            return;
        }

        if (!EnterCaptive(*process, *identity)) {
            // FAIL-CLOSED: não seguimos com a decisão nem liberamos o processo
            // quando a fronteira de cativeiro não pôde ser estabelecida.
            TerminateProcessSafe(process->pid);
            gLogger.Write(L"Falha na contenção; processo encerrado por fail-closed: " +
                          process->path);
            return;
        }

        DecisionRequest request;
        request.process = *process;
        request.identity = *identity;
        request.scan = scan;

        DescendantPolicy policy = DescendantPolicy::None;
        UserDecision decision = ShowDecisionDialog(request, policy);

        ApplyDecision(*process, *identity, scan, decision, policy);
    }

    void ApplyDecision(const ProcessInfo& process,
                       const FileIdentity& identity,
                       const NativeDefenderScanResult& scan,
                       UserDecision decision,
                       DescendantPolicy policy) {
        switch (decision) {
        case UserDecision::AllowOnce:
            {
                std::lock_guard<std::mutex> lock(stateMutex_);
                temporaryAllowedPids_.insert(process.pid);
            }
            MarkRunningTrusted(process.pid, identity, DescendantPolicy::None);
            // Não existe desanexação segura de um processo já pertencente a um
            // Job Object. A decisão permite a execução, mas mantém a barreira
            // de cativeiro até o processo terminar.
            if (auto it = captive_.find(process.pid); it != captive_.end()) {
                it->second->networkBlocked = false;
                firewall_.RemoveRules(it->second->firewallRules);
                it->second->firewallRules.clear();
                DisarmKillOnClose(*it->second);
            }
            gLogger.Write(L"Permitido uma vez; cativeiro mantido até o encerramento: " +
                          identity.path);
            break;

        case UserDecision::AllowAlways:
            database_.Save(identity, policy,
                           TrustRecordKind::PermanentAllow);
            MarkRunningTrusted(process.pid, identity, policy);
            if (auto it = captive_.find(process.pid); it != captive_.end()) {
                it->second->networkBlocked = false;
                firewall_.RemoveRules(it->second->firewallRules);
                it->second->firewallRules.clear();
                DisarmKillOnClose(*it->second);
            }
            gLogger.Write(L"Permitido sempre; cativeiro mantido até o encerramento: " +
                          identity.path);
            break;

        case UserDecision::Quarantine:
            TerminateProcessSafe(process.pid);
            {
                QuarantineContext context;
                context.pid = process.pid;
                context.parentPid = process.parentPid;
                context.reason = L"Decisão do usuário";
                context.decision = L"Quarentena";
                context.scan = scan;
                const bool ok = quarantine_.Put(identity, context);
                gLogger.Write(ok
                    ? L"Quarentena concluída sem apagar o original: " + identity.path
                    : L"Falha ao registrar quarentena: " + identity.path);
            }
            ReleaseCaptive(process.pid);
            break;

        case UserDecision::Terminate:
        default:
            TerminateProcessSafe(process.pid);
            ReleaseCaptive(process.pid);
            gLogger.Write(L"Processo encerrado: " + identity.path);
            break;
        }
    }

    bool IsDescendantOf(DWORD pid, DWORD ancestorPid,
                        const std::map<DWORD, ProcessInfo>& processes) const {
        DWORD current = pid;
        for (int depth = 0; depth < 64; ++depth) {
            auto it = processes.find(current);
            if (it == processes.end()) return false;
            if (it->second.parentPid == ancestorPid) return true;
            if (it->second.parentPid == 0 || it->second.parentPid == current)
                return false;
            current = it->second.parentPid;
        }
        return false;
    }

    void ReconcileCaptives(const std::map<DWORD, ProcessInfo>& processes) {
        std::vector<DWORD> compromisedRoots;

        for (const auto& item : captive_) {
            const DWORD rootPid = item.first;
            const CaptiveContext& context = *item.second;

            auto root = processes.find(rootPid);
            if (root == processes.end()) continue;

            BOOL inJob = FALSE;
            if (!context.job ||
                !IsProcessInJobByPid(rootPid, context.job.get(), &inJob) ||
                !inJob) {
                gLogger.Write(L"Violação de fronteira de cativeiro detectada no PID " +
                              std::to_wstring(rootPid) +
                              L"; encerrando a árvore.");
                compromisedRoots.push_back(rootPid);
                continue;
            }

            // Verifica todos os descendentes atuais. Uma tentativa de
            // breakaway/escape não fica esperando o WMI detectar outro evento.
            for (const auto& proc : processes) {
                if (proc.first == rootPid) continue;
                if (!IsDescendantOf(proc.first, rootPid, processes)) continue;

                BOOL descendantInJob = FALSE;
                if (!IsProcessInJobByPid(proc.first, context.job.get(),
                                         &descendantInJob) ||
                    !descendantInJob) {
                    gLogger.Write(L"Descendente fora do cativeiro detectado: PID " +
                                  std::to_wstring(proc.first) +
                                  L"; root " + std::to_wstring(rootPid));
                    TerminateProcessSafe(proc.first);
                }
            }
        }

        for (DWORD pid : compromisedRoots) {
            TerminateProcessSafe(pid);
            ReleaseCaptive(pid);
        }
    }

    bool IsProcessInJobByPid(DWORD pid, HANDLE job, BOOL* inJob) const {
        if (!job || !inJob) return false;
        UniqueHandle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,
                                         FALSE, pid));
        if (!process) return false;
        return IsProcessInJob(process.get(), job, inJob) != FALSE;
    }

    bool IsAlreadyContained(DWORD pid) const {
        for (const auto& item : captive_) {
            BOOL inJob = FALSE;
            if (IsProcessInJobByPid(pid, item.second->job.get(), &inJob) &&
                inJob) {
                return true;
            }
        }
        return false;
    }

    void CleanupTemporaryPermissions() {
        static ULONGLONG last = 0;
        const ULONGLONG now = GetTickCount64();
        if (now - last < kCaptiveIntegrityCheckMs) return;
        last = now;

        auto processes = SnapshotProcesses();
        ReconcileCaptives(processes);
        std::lock_guard<std::mutex> lock(stateMutex_);

        for (auto it = temporaryAllowedPids_.begin();
             it != temporaryAllowedPids_.end();) {
            if (!processes.count(*it))
                it = temporaryAllowedPids_.erase(it);
            else
                ++it;
        }

        for (auto it = trustedRunning_.begin();
             it != trustedRunning_.end();) {
            if (!processes.count(it->first))
                it = trustedRunning_.erase(it);
            else
                ++it;
        }

        std::vector<DWORD> deadCaptives;
        for (const auto& item : captive_) {
            if (!processes.count(item.first))
                deadCaptives.push_back(item.first);
        }
        for (DWORD pid : deadCaptives)
            ReleaseCaptive(pid);
    }

    struct RunningTrust {
        std::wstring path;
        DescendantPolicy policy = DescendantPolicy::None;
    };

    WindowsVersion os_;
    TrustDatabase database_;
    QuarantineManager quarantine_;
    ProcessEventQueue events_;
    std::atomic<bool> running_{true};

    std::map<DWORD, ProcessInfo> knownProcesses_;
    std::mutex stateMutex_;
    std::set<DWORD> temporaryAllowedPids_;
    std::map<DWORD, RunningTrust> trustedRunning_;
    FirewallBlocker firewall_;
    std::map<DWORD, std::unique_ptr<CaptiveContext>> captive_;
};

} // namespace vd

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    using namespace vd;

    HANDLE mutex = CreateMutexW(nullptr, TRUE, kEngineMutex);
    if (!mutex) return static_cast<int>(GetLastError());
    UniqueHandle instanceMutex(mutex);

    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        MessageBoxW(nullptr, L"A proteção já está ativa.",
                    kProductName, MB_OK | MB_ICONINFORMATION);
        return 0;
    }

    try {
        DefenderEngine engine;
        return engine.Run();
    } catch (const std::exception& e) {
        std::wstring message = L"Falha fatal ao iniciar o motor.\n\n";
        std::string narrow = e.what();
        message.append(narrow.begin(), narrow.end());
        gLogger.Write(message);
        MessageBoxW(nullptr, message.c_str(), kProductName,
                    MB_OK | MB_ICONERROR | MB_SYSTEMMODAL);
        return ERROR_GEN_FAILURE;
    } catch (...) {
        gLogger.Write(L"Falha fatal desconhecida.");
        MessageBoxW(nullptr, L"Falha fatal desconhecida.",
                    kProductName, MB_OK | MB_ICONERROR | MB_SYSTEMMODAL);
        return ERROR_GEN_FAILURE;
    }
}