﻿// Feito por Arthur Carvalho Rodrigues da Silva
// Feito por Arthur Carvalho Rodrigues da Silva
#define WIN32_LEAN_AND_MEAN
// Feito por Arthur Carvalho Rodrigues da Silva

#include <windows.h>
#include <shellapi.h>
#include <wininet.h>
#include <wincrypt.h>
#include <wintrust.h>
#include <softpub.h>
#include <bcrypt.h>

#include <algorithm>
#include <cwctype>
#include <filesystem>
#include <fstream>
#include <string>
#include <utility>
#include <vector>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "bcrypt.lib")

#ifndef INTERNET_OPTION_SECURITY_PROTOCOLS
#define INTERNET_OPTION_SECURITY_PROTOCOLS 98
#endif

#ifndef SECURITY_PROTOCOL_TLS1_2
#define SECURITY_PROTOCOL_TLS1_2 0x00000800
#endif

namespace fs = std::filesystem;

// ============================================================
// CÓDIGOS DE RETORNO DA UPDATE.DLL
// ============================================================

constexpr HRESULT UPDATE_NENHUMA_DISPONIVEL = S_FALSE;
constexpr HRESULT UPDATE_DISPONIVEL         = S_OK;

// Erros próprios da DLL.
constexpr HRESULT UPDATE_ERRO_MANIFESTO_VAZIO =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x201);

constexpr HRESULT UPDATE_ERRO_MANIFESTO_INVALIDO =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x202);

constexpr HRESULT UPDATE_ERRO_HTTP =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x203);

constexpr HRESULT UPDATE_ERRO_GRAVACAO =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x204);

// Conteúdo baixado não corresponde ao digest declarado no manifesto.
constexpr HRESULT UPDATE_ERRO_HASH_DIVERGENTE =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x205);

// Assinatura Authenticode ausente, inválida ou de outro publicador.
constexpr HRESULT UPDATE_ERRO_ASSINATURA =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x206);

// Confiança não configurada nesta build (ver PUBLICADOR_THUMBPRINT abaixo).
constexpr HRESULT UPDATE_ERRO_CONFIANCA_NAO_CONFIGURADA =
    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x207);


// ============================================================
// CONFIGURAÇÃO DO REPOSITÓRIO
// ============================================================

// Esta URL precisa terminar com "/".
static const std::wstring URL_BASE =
    L"https://raw.githubusercontent.com/"
    L"OArthurMamaco/"
    L"Vistas-Defender/"
    L"main/";

// Pagina oficial do projeto, aberta no navegador padrão do Windows.
static const std::wstring URL_REPOSITORIO =
    L"https://github.com/OArthurMamaco/Vistas-Defender";

static const std::wstring NOME_MANIFESTO = L"info_vacina.txt";

/*
    Thumbprint SHA-1 do certificado de assinatura do publicador de teste.

    Precisa ser preenchida com o thumbprint do certificado REEMITIDO.

    O certificado anterior (CN=Macrobyte Security,
    SHA-256 6D:92:A6:00:71:C0:C9:63:61:51:C4:54:AD:AF:EB:AA:
            02:EF:57:75:8C:85:2A:27:F6:3D:BC:F5:F0:20:04:C7)
    teve a chave privada distribuída sem senha dentro do pacote e deve ser
    tratado como comprometido. Não o reutilize aqui.

    Enquanto estiver vazia, nenhuma atualização é aceita: é preferível não
    atualizar a aceitar binário de origem não verificada.
*/
static const std::wstring PUBLICADOR_THUMBPRINT = L"2824387A93B2D22DDB59B89ECACB24BBE89E888E";



// ============================================================
// ESTRUTURAS
// ============================================================

struct ArquivoAtualizacao
{
    std::wstring caminhoRemoto;
    std::wstring nomeDestino;
    std::wstring digestEsperado;
};


// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================

static std::wstring ObterPastaDaDll()
{
    HMODULE modulo = nullptr;

    if (!GetModuleHandleExW(
            GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            reinterpret_cast<LPCWSTR>(&ObterPastaDaDll),
            &modulo))
    {
        return L"";
    }

    std::vector<wchar_t> buffer(32768);

    const DWORD tamanho = GetModuleFileNameW(
        modulo,
        buffer.data(),
        static_cast<DWORD>(buffer.size())
    );

    if (tamanho == 0 || tamanho >= buffer.size())
        return L"";

    return fs::path(buffer.data()).parent_path().wstring();
}


static std::string RemoverEspacos(const std::string& texto)
{
    const auto inicio = texto.find_first_not_of(" \t\r\n");

    if (inicio == std::string::npos)
        return "";

    const auto fim = texto.find_last_not_of(" \t\r\n");

    return texto.substr(inicio, fim - inicio + 1);
}


static std::wstring Utf8ParaWide(const std::string& texto)
{
    if (texto.empty())
        return L"";

    const int tamanho = MultiByteToWideChar(
        CP_UTF8,
        MB_ERR_INVALID_CHARS,
        texto.data(),
        static_cast<int>(texto.size()),
        nullptr,
        0
    );

    if (tamanho <= 0)
    {
        // Fallback para manifestos ANSI simples.
        return std::wstring(texto.begin(), texto.end());
    }

    std::wstring convertido(
        static_cast<size_t>(tamanho),
        L'\0'
    );

    MultiByteToWideChar(
        CP_UTF8,
        MB_ERR_INVALID_CHARS,
        texto.data(),
        static_cast<int>(texto.size()),
        convertido.data(),
        tamanho
    );

    return convertido;
}


static bool TerminaComSemDiferenciarMaiusculas(
    const std::wstring& texto,
    const std::wstring& final)
{
    if (final.size() > texto.size())
        return false;

    return _wcsicmp(
        texto.c_str() + texto.size() - final.size(),
        final.c_str()
    ) == 0;
}


static std::wstring DeterminarNomeDestino(
    const std::wstring& caminhoRemoto)
{
    const std::wstring nomeArquivo =
        fs::path(caminhoRemoto).filename().wstring();

    if (_wcsicmp(nomeArquivo.c_str(), L"VistasUI.exe") == 0)
        return L"VistasUI.exe";

    if (_wcsicmp(nomeArquivo.c_str(), L"VistasEngine.exe") == 0)
        return L"VistasEngine.exe";

    if (_wcsicmp(nomeArquivo.c_str(), L"Defender.exe") == 0)
        return L"Defender.exe";

    if (_wcsicmp(nomeArquivo.c_str(), L"Update.dll") == 0)
        return L"Update.dll";

    if (_wcsicmp(nomeArquivo.c_str(), L"Visne.dll") == 0)
        return L"Visne.dll";

    if (_wcsicmp(nomeArquivo.c_str(), L"htlk.dll") == 0)
        return L"htlk.dll";

    return L"";
}


// ============================================================
// DOWNLOAD WININET
// ============================================================

static HRESULT BaixarArquivoWinINet(
    const std::wstring& url,
    const fs::path& destinoTemporario)
{
    DeleteUrlCacheEntryW(url.c_str());

    HINTERNET internet = InternetOpenW(
        L"VistasDefender-Updater/2.0",
        INTERNET_OPEN_TYPE_PRECONFIG,
        nullptr,
        nullptr,
        0
    );

    if (!internet)
        return HRESULT_FROM_WIN32(GetLastError());

    DWORD protocolos = SECURITY_PROTOCOL_TLS1_2;

    InternetSetOptionW(
        internet,
        INTERNET_OPTION_SECURITY_PROTOCOLS,
        &protocolos,
        sizeof(protocolos)
    );

    constexpr DWORD flags =
        INTERNET_FLAG_RELOAD |
        INTERNET_FLAG_NO_CACHE_WRITE |
        INTERNET_FLAG_PRAGMA_NOCACHE |
        INTERNET_FLAG_SECURE |
        INTERNET_FLAG_NO_UI;

    HINTERNET requisicao = InternetOpenUrlW(
        internet,
        url.c_str(),
        nullptr,
        0,
        flags,
        0
    );

    if (!requisicao)
    {
        const DWORD erro = GetLastError();
        InternetCloseHandle(internet);
        return HRESULT_FROM_WIN32(erro);
    }

    DWORD statusHttp = 0;
    DWORD tamanhoStatus = sizeof(statusHttp);

    const BOOL obteveStatus = HttpQueryInfoW(
        requisicao,
        HTTP_QUERY_STATUS_CODE |
        HTTP_QUERY_FLAG_NUMBER,
        &statusHttp,
        &tamanhoStatus,
        nullptr
    );

    if (!obteveStatus || statusHttp < 200 || statusHttp >= 300)
    {
        InternetCloseHandle(requisicao);
        InternetCloseHandle(internet);

        return UPDATE_ERRO_HTTP;
    }

    std::ofstream saida(
        destinoTemporario,
        std::ios::binary |
        std::ios::trunc
    );

    if (!saida.is_open())
    {
        InternetCloseHandle(requisicao);
        InternetCloseHandle(internet);

        return UPDATE_ERRO_GRAVACAO;
    }

    char buffer[64 * 1024];

    while (true)
    {
        DWORD bytesLidos = 0;

        const BOOL leituraOk = InternetReadFile(
            requisicao,
            buffer,
            sizeof(buffer),
            &bytesLidos
        );

        if (!leituraOk)
        {
            const DWORD erro = GetLastError();

            saida.close();
            InternetCloseHandle(requisicao);
            InternetCloseHandle(internet);

            std::error_code erroFs;
            fs::remove(destinoTemporario, erroFs);

            return HRESULT_FROM_WIN32(erro);
        }

        if (bytesLidos == 0)
            break;

        saida.write(
            buffer,
            static_cast<std::streamsize>(bytesLidos)
        );

        if (!saida.good())
        {
            saida.close();
            InternetCloseHandle(requisicao);
            InternetCloseHandle(internet);

            std::error_code erroFs;
            fs::remove(destinoTemporario, erroFs);

            return UPDATE_ERRO_GRAVACAO;
        }
    }

    saida.close();

    InternetCloseHandle(requisicao);
    InternetCloseHandle(internet);

    std::error_code erroFs;

    if (!fs::exists(destinoTemporario, erroFs) ||
        fs::file_size(destinoTemporario, erroFs) == 0)
    {
        fs::remove(destinoTemporario, erroFs);
        return UPDATE_ERRO_GRAVACAO;
    }

    return S_OK;
}


// ============================================================
// VERIFICAÇÃO DE INTEGRIDADE E AUTENTICIDADE
// ============================================================

static std::wstring ParaMinusculas(std::wstring texto)
{
    std::transform(
        texto.begin(),
        texto.end(),
        texto.begin(),
        [](wchar_t c) {
            return static_cast<wchar_t>(towlower(c));
        }
    );

    return texto;
}


static std::wstring BytesParaHex(
    const std::vector<BYTE>& bytes)
{
    static const wchar_t digitos[] = L"0123456789abcdef";

    std::wstring hex;
    hex.reserve(bytes.size() * 2);

    for (BYTE b : bytes)
    {
        hex.push_back(digitos[(b >> 4) & 0x0F]);
        hex.push_back(digitos[b & 0x0F]);
    }

    return hex;
}


// Comparação sem short-circuit: o tempo não revela o prefixo coincidente.
static bool ComparacaoConstante(
    const std::wstring& a,
    const std::wstring& b)
{
    if (a.size() != b.size())
        return false;

    wchar_t diferenca = 0;

    for (size_t i = 0; i < a.size(); ++i)
        diferenca |= static_cast<wchar_t>(a[i] ^ b[i]);

    return diferenca == 0;
}


static bool CalcularSha256Arquivo(
    const fs::path& caminho,
    std::wstring& digestHex)
{
    digestHex.clear();

    BCRYPT_ALG_HANDLE algoritmo = nullptr;

    if (BCryptOpenAlgorithmProvider(
            &algoritmo,
            BCRYPT_SHA256_ALGORITHM,
            nullptr,
            0) != 0)
    {
        return false;
    }

    BCRYPT_HASH_HANDLE hash = nullptr;
    std::vector<BYTE> digest(32);
    bool sucesso = false;

    if (BCryptCreateHash(
            algoritmo,
            &hash,
            nullptr,
            0,
            nullptr,
            0,
            0) == 0)
    {
        std::ifstream entrada(
            caminho,
            std::ios::binary
        );

        if (entrada.is_open())
        {
            std::vector<char> buffer(64 * 1024);
            sucesso = true;

            while (entrada)
            {
                entrada.read(
                    buffer.data(),
                    static_cast<std::streamsize>(buffer.size())
                );

                const std::streamsize lidos = entrada.gcount();

                if (lidos <= 0)
                    break;

                if (BCryptHashData(
                        hash,
                        reinterpret_cast<PUCHAR>(buffer.data()),
                        static_cast<ULONG>(lidos),
                        0) != 0)
                {
                    sucesso = false;
                    break;
                }
            }

            if (sucesso &&
                BCryptFinishHash(
                    hash,
                    digest.data(),
                    static_cast<ULONG>(digest.size()),
                    0) != 0)
            {
                sucesso = false;
            }
        }

        BCryptDestroyHash(hash);
    }

    BCryptCloseAlgorithmProvider(algoritmo, 0);

    if (sucesso)
        digestHex = BytesParaHex(digest);

    return sucesso;
}


static bool ObterThumbprintDoAssinante(
    const fs::path& caminho,
    std::wstring& thumbprintHex)
{
    thumbprintHex.clear();

    HCERTSTORE armazem = nullptr;
    HCRYPTMSG mensagem = nullptr;

    if (!CryptQueryObject(
            CERT_QUERY_OBJECT_FILE,
            caminho.c_str(),
            CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY,
            0,
            nullptr,
            nullptr,
            nullptr,
            &armazem,
            &mensagem,
            nullptr))
    {
        return false;
    }

    bool sucesso = false;
    DWORD tamanhoInfo = 0;

    if (CryptMsgGetParam(
            mensagem,
            CMSG_SIGNER_INFO_PARAM,
            0,
            nullptr,
            &tamanhoInfo) &&
        tamanhoInfo > 0)
    {
        std::vector<BYTE> bufferInfo(tamanhoInfo);

        if (CryptMsgGetParam(
                mensagem,
                CMSG_SIGNER_INFO_PARAM,
                0,
                bufferInfo.data(),
                &tamanhoInfo))
        {
            auto* info =
                reinterpret_cast<CMSG_SIGNER_INFO*>(
                    bufferInfo.data()
                );

            CERT_INFO procurado{};
            procurado.Issuer = info->Issuer;
            procurado.SerialNumber = info->SerialNumber;

            PCCERT_CONTEXT contexto =
                CertFindCertificateInStore(
                    armazem,
                    X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
                    0,
                    CERT_FIND_SUBJECT_CERT,
                    &procurado,
                    nullptr
                );

            if (contexto)
            {
                DWORD tamanhoHash = 20;
                std::vector<BYTE> hash(tamanhoHash);

                if (CertGetCertificateContextProperty(
                        contexto,
                        CERT_SHA1_HASH_PROP_ID,
                        hash.data(),
                        &tamanhoHash))
                {
                    hash.resize(tamanhoHash);
                    thumbprintHex = BytesParaHex(hash);
                    sucesso = true;
                }

                CertFreeCertificateContext(contexto);
            }
        }
    }

    if (mensagem)
        CryptMsgClose(mensagem);

    if (armazem)
        CertCloseStore(armazem, 0);

    return sucesso;
}


static HRESULT VerificarAssinatura(const fs::path& caminho)
{
    if (PUBLICADOR_THUMBPRINT.empty())
        return UPDATE_ERRO_CONFIANCA_NAO_CONFIGURADA;

    const std::wstring arquivo = caminho.wstring();

    WINTRUST_FILE_INFO infoArquivo{};
    infoArquivo.cbStruct = sizeof(infoArquivo);
    infoArquivo.pcwszFilePath = arquivo.c_str();

    GUID politica = WINTRUST_ACTION_GENERIC_VERIFY_V2;

    WINTRUST_DATA dados{};
    dados.cbStruct = sizeof(dados);
    dados.dwUIChoice = WTD_UI_NONE;
    dados.fdwRevocationChecks = WTD_REVOKE_WHOLECHAIN;
    dados.dwUnionChoice = WTD_CHOICE_FILE;
    dados.pFile = &infoArquivo;
    dados.dwStateAction = WTD_STATEACTION_VERIFY;
    dados.dwProvFlags = WTD_REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT;

    const LONG resultado =
        WinVerifyTrust(nullptr, &politica, &dados);

    dados.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(nullptr, &politica, &dados);

    if (resultado != ERROR_SUCCESS)
        return UPDATE_ERRO_ASSINATURA;

    // Cadeia válida não basta: qualquer certificado confiável do sistema
    // passaria. O publicador precisa ser exatamente o esperado.

    std::wstring thumbprint;

    if (!ObterThumbprintDoAssinante(caminho, thumbprint))
        return UPDATE_ERRO_ASSINATURA;

    if (!ComparacaoConstante(
            ParaMinusculas(thumbprint),
            ParaMinusculas(PUBLICADOR_THUMBPRINT)))
    {
        return UPDATE_ERRO_ASSINATURA;
    }

    return S_OK;
}


// ============================================================
// COMPARAÇÃO DE ARQUIVOS
// ============================================================

static bool ArquivosSaoIguais(
    const fs::path& arquivo1,
    const fs::path& arquivo2)
{
    std::error_code erro;

    if (!fs::exists(arquivo1, erro) ||
        !fs::exists(arquivo2, erro))
    {
        return false;
    }

    const uintmax_t tamanho1 =
        fs::file_size(arquivo1, erro);

    if (erro)
        return false;

    const uintmax_t tamanho2 =
        fs::file_size(arquivo2, erro);

    if (erro || tamanho1 != tamanho2)
        return false;

    std::ifstream a(arquivo1, std::ios::binary);
    std::ifstream b(arquivo2, std::ios::binary);

    if (!a.is_open() || !b.is_open())
        return false;

    constexpr size_t TAMANHO_BUFFER = 64 * 1024;

    std::vector<char> bufferA(TAMANHO_BUFFER);
    std::vector<char> bufferB(TAMANHO_BUFFER);

    while (a && b)
    {
        a.read(
            bufferA.data(),
            static_cast<std::streamsize>(bufferA.size())
        );

        b.read(
            bufferB.data(),
            static_cast<std::streamsize>(bufferB.size())
        );

        const std::streamsize lidosA = a.gcount();
        const std::streamsize lidosB = b.gcount();

        if (lidosA != lidosB)
            return false;

        if (!std::equal(
                bufferA.begin(),
                bufferA.begin() + lidosA,
                bufferB.begin()))
        {
            return false;
        }
    }

    return true;
}


// ============================================================
// LEITURA DO MANIFESTO
// ============================================================

/*
    Formato de cada entrada do manifesto:

        AtualizarBinario: <caminho/remoto.exe> <sha256-em-hex>

    O digest é obrigatório. Entradas sem digest são rejeitadas em vez de
    baixadas sem verificação.
*/
static HRESULT LerManifesto(
    const fs::path& caminhoManifesto,
    std::vector<ArquivoAtualizacao>& arquivos)
{
    std::ifstream manifesto(
        caminhoManifesto,
        std::ios::binary
    );

    if (!manifesto.is_open())
        return HRESULT_FROM_WIN32(ERROR_OPEN_FAILED);

    const std::string prefixo = "AtualizarBinario:";

    std::string linha;

    while (std::getline(manifesto, linha))
    {
        linha = RemoverEspacos(linha);

        if (linha.empty() || linha[0] == '#')
            continue;

        if (linha.rfind(prefixo, 0) != 0)
            continue;

        const std::string corpo =
            RemoverEspacos(linha.substr(prefixo.size()));

        if (corpo.empty())
            continue;

        const auto separador =
            corpo.find_last_of(" \t");

        if (separador == std::string::npos)
            return UPDATE_ERRO_MANIFESTO_INVALIDO;

        const std::string caminhoUtf8 =
            RemoverEspacos(corpo.substr(0, separador));

        const std::string digestUtf8 =
            RemoverEspacos(corpo.substr(separador + 1));

        if (caminhoUtf8.empty())
            return UPDATE_ERRO_MANIFESTO_INVALIDO;

        if (digestUtf8.size() != 64 ||
            digestUtf8.find_first_not_of(
                "0123456789abcdefABCDEF") != std::string::npos)
        {
            return UPDATE_ERRO_MANIFESTO_INVALIDO;
        }

        std::wstring caminhoRemoto =
            Utf8ParaWide(caminhoUtf8);

        // O manifesto só pode apontar para caminhos relativos simples
        // dentro do repositório.
        if (caminhoRemoto.empty() ||
            caminhoRemoto.front() == L'/' ||
            caminhoRemoto.front() == L'\\' ||
            caminhoRemoto.find(L"..") != std::wstring::npos ||
            caminhoRemoto.find(L'\\') != std::wstring::npos ||
            caminhoRemoto.find(L':') != std::wstring::npos)
        {
            return UPDATE_ERRO_MANIFESTO_INVALIDO;
        }

        for (wchar_t ch : caminhoRemoto)
        {
            if (ch < 0x20)
                return UPDATE_ERRO_MANIFESTO_INVALIDO;
        }

        ArquivoAtualizacao item;

        item.caminhoRemoto = caminhoRemoto;
        item.nomeDestino =
            DeterminarNomeDestino(caminhoRemoto);

        if (item.nomeDestino.empty())
            return UPDATE_ERRO_MANIFESTO_INVALIDO;

        item.digestEsperado =
            ParaMinusculas(Utf8ParaWide(digestUtf8));

        arquivos.push_back(std::move(item));
    }

    if (arquivos.empty())
        return UPDATE_ERRO_MANIFESTO_VAZIO;

    return S_OK;
}


// ============================================================
// FUNÇÃO EXPORTADA
// ============================================================

extern "C"
__declspec(dllexport)
HRESULT __cdecl AbrirPaginaGitHub()
{
    const HINSTANCE resultado = ShellExecuteW(
        nullptr,
        L"open",
        URL_REPOSITORIO.c_str(),
        nullptr,
        nullptr,
        SW_SHOWNORMAL
    );

    // ShellExecute retorna um valor maior que 32 em caso de sucesso.
    if (reinterpret_cast<INT_PTR>(resultado) > 32)
        return S_OK;

    return E_FAIL;
}

extern "C"
__declspec(dllexport)
HRESULT __cdecl ChecarAtualizacoes()
{
    // Ao iniciar a verificação, abre a página oficial no navegador padrão.
    // A atualização continua normalmente mesmo se o navegador não puder ser aberto.
    (void)AbrirPaginaGitHub();

    try
    {
        const std::wstring pastaDll =
            ObterPastaDaDll();

        if (pastaDll.empty())
            return HRESULT_FROM_WIN32(GetLastError());

        const fs::path pastaRaiz = pastaDll;
        const fs::path pastaUpdates =
            pastaRaiz / L"Updates";

        std::error_code erroFs;

        fs::create_directories(
            pastaUpdates,
            erroFs
        );

        if (erroFs)
            return HRESULT_FROM_WIN32(erroFs.value());

        const fs::path manifestoTemporario =
            pastaUpdates / L"info_vacina.download";

        const fs::path manifestoFinal =
            pastaUpdates / NOME_MANIFESTO;

        const std::wstring urlManifesto =
            URL_BASE + NOME_MANIFESTO;

        HRESULT hr = BaixarArquivoWinINet(
            urlManifesto,
            manifestoTemporario
        );

        if (FAILED(hr))
            return hr;

        fs::remove(manifestoFinal, erroFs);
        erroFs.clear();

        fs::rename(
            manifestoTemporario,
            manifestoFinal,
            erroFs
        );

        if (erroFs)
            return HRESULT_FROM_WIN32(erroFs.value());

        std::vector<ArquivoAtualizacao> arquivos;

        hr = LerManifesto(
            manifestoFinal,
            arquivos
        );

        if (FAILED(hr))
            return hr;

        bool existeAtualizacao = false;

        for (const auto& item : arquivos)
        {
            const std::wstring urlArquivo =
                URL_BASE + item.caminhoRemoto;

            /*
                Arquivos atuais instalados ficam ao lado da DLL.

                Exemplo:
                C:\VistasDefender\VistasUI.exe
                C:\VistasDefender\Defender.exe
                C:\VistasDefender\Update.dll
            */
            const fs::path arquivoInstalado =
                pastaRaiz / item.nomeDestino;

            /*
                Arquivos novos são baixados para Updates.
                Eles não substituem imediatamente executáveis em uso.
            */
            const fs::path arquivoBaixado =
                pastaUpdates /
                (item.nomeDestino + L".new");

            hr = BaixarArquivoWinINet(
                urlArquivo,
                arquivoBaixado
            );

            if (FAILED(hr))
                return hr;

            /*
                Só a partir daqui o arquivo baixado pode ser considerado
                candidato a atualização. TLS garante o transporte, mas não
                diz nada sobre quem colocou o conteúdo no repositório.
            */

            std::wstring digestObtido;

            if (!CalcularSha256Arquivo(
                    arquivoBaixado,
                    digestObtido))
            {
                fs::remove(arquivoBaixado, erroFs);
                erroFs.clear();
                return UPDATE_ERRO_GRAVACAO;
            }

            if (!ComparacaoConstante(
                    ParaMinusculas(digestObtido),
                    item.digestEsperado))
            {
                fs::remove(arquivoBaixado, erroFs);
                erroFs.clear();
                return UPDATE_ERRO_HASH_DIVERGENTE;
            }

            const HRESULT assinatura =
                VerificarAssinatura(arquivoBaixado);

            if (FAILED(assinatura))
            {
                fs::remove(arquivoBaixado, erroFs);
                erroFs.clear();
                return assinatura;
            }

            if (ArquivosSaoIguais(
                    arquivoInstalado,
                    arquivoBaixado))
            {
                fs::remove(arquivoBaixado, erroFs);
                erroFs.clear();
                continue;
            }

            existeAtualizacao = true;
        }

        return existeAtualizacao
            ? UPDATE_DISPONIVEL
            : UPDATE_NENHUMA_DISPONIVEL;
    }
    catch (const fs::filesystem_error& erro)
    {
        const int codigo = erro.code().value();

        return HRESULT_FROM_WIN32(
            codigo != 0 ? codigo : ERROR_GEN_FAILURE
        );
    }
    catch (...)
    {
        return E_UNEXPECTED;
    }
}


// ============================================================
// DLLMAIN
// ============================================================

BOOL APIENTRY DllMain(
    HMODULE,
    DWORD,
    LPVOID)
{
    return TRUE;
}