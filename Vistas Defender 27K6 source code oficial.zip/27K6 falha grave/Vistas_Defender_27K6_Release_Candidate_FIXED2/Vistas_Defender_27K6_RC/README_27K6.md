# Vistas Defender 27K6 — release candidate de código-fonte

Esta pasta contém uma revisão de código para testes, não uma versão binária final certificada. Ela parte do código 27K2 fornecido e aplica mudanças incrementais na UI, motor e HTLK.

## Arquitetura

- `VistasUI.cpp` — interface Win32, integridade local, idioma e preferências.
- `Defender.cpp` — monitorização de processos, política de contenção e integração com o antimalware do Windows.
- `Visne.cpp` — regras de bloqueio carregadas de `Updates\info_vacina.txt`, com leitura transacional e correspondência exata/coringas explícitos.
- `htlk.cpp` / `htlk_api.h` — API C exportada para versão, informações de build, capacidades, localização confiável do `MpCmdRun.exe`, varredura customizada e cancelamento.
- `Update.cpp` — módulo de atualização existente; conferir o thumbprint de publicador antes de qualquer distribuição.
- `BUILD_27K6.bat` — compila os cinco binários dentro de `bin\` (MSVC, C++17, UTF-8 e Windows SDK).
- A reconciliação/remoção das tarefas usa a API COM do Agendador de Tarefas para distinguir “não existe” de “falha ao remover”.
- `TEST_27K6.md` — plano de testes de regressão e segurança.

## Compilação

1. Abra o **Developer Command Prompt** do Visual Studio com MSVC e Windows SDK instalados.
2. Extraia esta pasta num caminho local e execute `BUILD_27K6.bat`.
3. Os artefatos ficam em `bin\` e precisam estar juntos: `VistasUI.exe`, `Defender.exe`, `Visne.dll`, `htlk.dll` e `Update.dll`.
4. A UI exige elevação de administrador. Antes de executar, assine os binários com o certificado de publicação válido configurado para `OArthurMamaco Security`. Não inclua arquivos `.pfx`/chaves privadas no ZIP.
5. Confirme que o publicador é exatamente o esperado e que `PUBLICADOR_THUMBPRINT` em `Update.cpp` corresponde ao certificado atual. O pacote não substitui a revisão do procedimento de assinatura.

A validação estática do pacote não substitui uma compilação e execução no Windows. Esta revisão **não foi compilada nem executada neste ambiente**, então trate como candidata para teste e não como release pronta.

## Varredura de disco

A HTLK não afirma que implementa um motor antimalware proprietário. Ela localiza e autentica o `MpCmdRun.exe` instalado pelo Microsoft Defender e solicita uma análise customizada do caminho selecionado. A varredura necessita permissões/elegibilidade compatíveis com o mecanismo nativo e pode levar bastante tempo.

- A API aceita caminhos locais existentes; recusa UNC, device paths e `GLOBALROOT`.
- Para a raiz de um volume, solicita também verificação do setor de arranque.
- `Htlk_GetProductVersionW`, `Htlk_GetBuildInfoW` e `Htlk_GetCapabilitiesW` expõem versão, build e capacidades.
- `Htlk_CancelScan` é cancelamento best-effort; o cancelamento não deve ser confundido com resultado limpo.
- Retorno 0 do MpCmdRun significa que o comando terminou e pode significar ausência de malware **ou** deteção já remediada. O motor não chama isso de “nenhuma ameaça detectada”; descreve apenas que não houve ação pendente reportada pelo código de saída. Código 2 é ambíguo (ameaça sem remediação, ação do usuário necessária ou erro). A UI não chama código 2 de malware confirmado nem código 0 de garantia absoluta de disco limpo.
- Os agendamentos são tarefas do Agendador de Tarefas do Windows executadas como SYSTEM/highest: verifique as permissões, o histórico de tarefas e o caminho da plataforma do Defender depois de atualizações do Windows.

## Política para executáveis do Windows

Os processos protegidos são excluídos por combinação de nome conhecido, caminho canônico do Windows/Defender e assinatura Authenticode válida do publicador Microsoft. Nomes de processo isolados não são suficientes. Não existe uma lista capaz de abranger toda configuração Windows possível; valide na máquina alvo, incluindo TrustedInstaller, svchost, explorer, MsMpEng e outros serviços reais.

## Modos de intervenção

- **Observação**: não bloqueia processos apenas com evidência ambígua; não equivale a proteção preventiva forte.
- **Equilibrado**: pede decisão para aplicativos desconhecidos ou quando a verificação é inconclusiva.
- **Rigoroso**: pode pedir decisão para muitos aplicativos não protegidos, aumentando interrupções e falsos positivos.

As configurações do modo são lidas pelo motor do Registro. Alterações de modo não substituem testes de regressão nem políticas corporativas do Microsoft Defender.

## Limitações conhecidas da RC

- O verificador de integridade da UI examina os componentes locais; **não consulta nem compara automaticamente a última versão remota**.
- A localização do `MpCmdRun.exe` pode mudar com atualizações da plataforma. Ao abrir a UI, as tarefas são reconciliadas com a localização atual, mas teste os agendamentos depois de atualizar o Defender.
- A seleção de idioma localiza a navegação, os controles e os principais textos desenhados; algumas mensagens herdadas do motor/registro de eventos ainda podem aparecer em português.
- O sistema de contenção e o subsistema de assinatura precisam ser testados em Windows suportado com os binários devidamente assinados.

### Nota de build

O script BUILD_27K6.bat vincula htlk.dll com `user32.lib`, necessária para a API `CharLowerBuffW`. Se você extraiu uma cópia anterior, substitua também o script de build pela versão deste pacote.
