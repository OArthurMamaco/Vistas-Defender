// ============================================================================
// VistasUI.cpp
// Feito por Arthur Carvalho Rodrigues da Silva
// OArthurMamaco Security - Vistas Defender
// Feito por Arthur Carvalho Rodrigues da Silva
// Feito por Arthur Carvalho Rodrigues da Silva
// Painel completo: Início, Proteção, Integridade, Atualizações, Eventos e Configurações
// ============================================================================

#ifndef _WIN32_DCOM
#define _WIN32_DCOM
#endif

#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <taskschd.h>
#include <oleauto.h>
#include <atomic>
#include <thread>
#include <memory>
#include <new>
#include "htlk_api.h"
#include <wintrust.h>
#include <softpub.h>
#include <wincrypt.h>

#include <algorithm>
#include <cwctype>
#include <filesystem>
#include <sstream>
#include <string>
#include <vector>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "taskschd.lib")

namespace fs = std::filesystem;

namespace
{
    // ========================================================================
    // Configuração geral
    // ========================================================================

    constexpr wchar_t WINDOW_CLASS[] =
        L"Macrobyte.VistasDefender.MainWindow";

    constexpr wchar_t ENGINE_MUTEX[] =
        L"Global\\Macrobyte.VistasDefender.Engine.v8";

    constexpr wchar_t EXPECTED_PUBLISHER[] =
        L"OArthurMamaco Security";

    constexpr wchar_t PRODUCT_VERSION[] =
        L"27K6";

    constexpr wchar_t SETTINGS_REGISTRY_KEY[] =
        L"SOFTWARE\\OArthurMamaco\\Vistas Defender";

    constexpr wchar_t UPDATE_CHANNEL[] =
        L"Canal estável • Contenção adaptativa";

    constexpr wchar_t UPDATE_REPOSITORY_URL[] =
        L"https://github.com/OArthurMamaco/Vistas-Defender";

    constexpr int WINDOW_CLIENT_WIDTH = 904;
    constexpr int WINDOW_CLIENT_HEIGHT = 613;
    constexpr int SIDEBAR_WIDTH = 220;

    // ========================================================================
    // IDs dos controles
    // ========================================================================

    constexpr int ID_HOME = 1001;
    constexpr int ID_PROTECTION = 1002;
    constexpr int ID_INTEGRITY = 1003;
    constexpr int ID_UPDATES = 1004;
    constexpr int ID_EVENTS = 1005;
    constexpr int ID_SETTINGS = 1006;

    constexpr int ID_HOME_ACTION = 1101;
    constexpr int ID_PROTECTION_ENABLE = 1102;
    constexpr int ID_PROTECTION_DISABLE = 1103;
    constexpr int ID_INTEGRITY_CHECK = 1104;
    constexpr int ID_UPDATES_CHECK = 1105;
    constexpr int ID_EVENTS_REFRESH = 1106;
    constexpr int ID_EVENTS_CLEAR = 1107;
    constexpr int ID_SCAN_DISK = 1108;
    constexpr int ID_SETTINGS_LANGUAGE = 1110;
    constexpr int ID_SETTINGS_STARTUP = 1111;
    constexpr int ID_SETTINGS_MODE = 1112;
    constexpr int ID_SETTINGS_DAY_BASE = 1120;
    constexpr UINT WM_SCAN_COMPLETE = WM_APP + 124;
    constexpr UINT_PTR TIMER_STATUS = 1;


    // ========================================================================
    // Páginas
    // ========================================================================

    enum class Page
    {
        Home,
        Protection,
        Integrity,
        Updates,
        Events,
        Settings
    };

    // ========================================================================
    // Estruturas
    // ========================================================================

    struct SignatureResult
    {
        bool fileExists = false;
        bool signaturePresent = false;
        bool digestSha256 = false;
        bool publisherMatches = false;
        bool cryptographicIntegrity = false;

        std::wstring publisher;
        std::wstring message;

        bool IsValid() const
        {
            return
                fileExists &&
                signaturePresent &&
                digestSha256 &&
                publisherMatches &&
                cryptographicIntegrity;
        }
    };

    struct ComponentResult
    {
        std::wstring fileName;
        SignatureResult signature;
    };

    struct UpdateResult
    {
        bool checked = false;
        bool packageValid = false;

        int totalComponents = 0;
        int validComponents = 0;

        std::wstring title;
        std::wstring description;
        std::wstring checkedAt;
    };

    struct EventRecord
    {
        std::wstring time;
        std::wstring category;
        std::wstring message;
    };

    struct UserSettings
    {
        DWORD language = 0;       // 0=pt-BR, 1=en-US, 2=es-ES
        DWORD scanAtStartup = 0;  // opt-in: schedule Microsoft Defender full scan on boot
        DWORD scanDays = 0;       // bit 0=Mon ... bit 6=Sun
        DWORD protectionMode = 1; // 0=observe, 1=balanced, 2=strict
    };

    struct ScanWorkItem
    {
        HWND window = nullptr;
        std::wstring target;
        HTLK_SCAN_RESULT result{};
        BOOL callReturned = FALSE;
    };

    using HtlkInitializeFn = BOOL (WINAPI*)(void);
    using HtlkScanPathFn = BOOL (WINAPI*)(const wchar_t*, HTLK_SCAN_RESULT*);
    using HtlkGetScannerPathFn = BOOL (WINAPI*)(wchar_t*, DWORD);
    using HtlkGetVersionFn = DWORD (WINAPI*)(void);
    using HtlkGetTextFn = BOOL (WINAPI*)(wchar_t*, DWORD);
    using HtlkCancelFn = BOOL (WINAPI*)(void);

    // ========================================================================
    // Estado global
    // ========================================================================

    HINSTANCE gInstance = nullptr;
    HWND gMainWindow = nullptr;

    HWND gHomeButton = nullptr;
    HWND gProtectionButton = nullptr;
    HWND gIntegrityButton = nullptr;
    HWND gUpdatesButton = nullptr;
    HWND gEventsButton = nullptr;
    HWND gSettingsButton = nullptr;
    HWND gScanDiskButton = nullptr;
    HWND gSettingsLanguageButton = nullptr;
    HWND gSettingsStartupButton = nullptr;
    HWND gSettingsModeButton = nullptr;
    HWND gSettingsDayButtons[7]{};

    HWND gHomeActionButton = nullptr;

    HWND gProtectionEnableButton = nullptr;
    HWND gProtectionDisableButton = nullptr;

    HWND gIntegrityCheckButton = nullptr;

    HWND gUpdatesCheckButton = nullptr;

    HWND gEventsRefreshButton = nullptr;
    HWND gEventsClearButton = nullptr;

    HFONT gBrandFont = nullptr;
    HFONT gSubtitleFont = nullptr;
    HFONT gMenuFont = nullptr;
    HFONT gTitleFont = nullptr;
    HFONT gHeadlineFont = nullptr;
    HFONT gBodyFont = nullptr;
    HFONT gButtonFont = nullptr;
    HFONT gSmallFont = nullptr;
    HFONT gTinyFont = nullptr;

    HBRUSH gWhiteBrush = nullptr;
    HBRUSH gSidebarBrush = nullptr;

    Page gCurrentPage = Page::Home;

    std::vector<ComponentResult> gIntegrityResults;
    bool gIntegrityChecked = false;

    UpdateResult gUpdateResult;

    std::vector<EventRecord> gEvents;

    UserSettings gSettings;
    std::wstring gScanStatus = L"Não executada";
    std::wstring gScanTarget;
    std::wstring gScheduleStatus = L"Não configurado";
    bool gScanInProgress = false;
    HMODULE gHtlkModule = nullptr; // Kept loaded until process exit to avoid races with scan thread.
    HtlkInitializeFn gHtlkInitialize = nullptr;
    HtlkScanPathFn gHtlkScanPath = nullptr;
    HtlkGetScannerPathFn gHtlkGetScannerPath = nullptr;
    HtlkGetVersionFn gHtlkGetAbiVersion = nullptr;
    HtlkGetTextFn gHtlkGetProductVersion = nullptr;
    HtlkGetTextFn gHtlkGetBuildInfo = nullptr;
    HtlkGetTextFn gHtlkGetCapabilities = nullptr;
    HtlkCancelFn gHtlkCancel = nullptr;
    std::wstring gHtlkBuildInfo = L"HTLK: não carregada";
    std::wstring gHtlkCapabilities;
    HANDLE gScanThread = nullptr;
    std::atomic_bool gWindowAlive{ false };

    // ========================================================================
    // Cores
    // ========================================================================

    constexpr COLORREF COLOR_WHITE =
        RGB(255, 255, 255);

    constexpr COLORREF COLOR_SIDEBAR =
        RGB(232, 242, 252);

    constexpr COLORREF COLOR_ACTIVE =
        RGB(210, 229, 247);

    constexpr COLORREF COLOR_BLUE =
        RGB(31, 105, 173);

    constexpr COLORREF COLOR_BLUE_PRESSED =
        RGB(21, 81, 138);

    constexpr COLORREF COLOR_DARK_BLUE =
        RGB(17, 75, 129);

    constexpr COLORREF COLOR_TEXT =
        RGB(35, 45, 55);

    constexpr COLORREF COLOR_MUTED =
        RGB(79, 99, 116);

    constexpr COLORREF COLOR_RED =
        RGB(205, 45, 45);

    constexpr COLORREF COLOR_GREEN =
        RGB(20, 145, 66);

    constexpr COLORREF COLOR_ORANGE =
        RGB(206, 120, 20);

    constexpr COLORREF COLOR_BORDER =
        RGB(207, 219, 229);

    constexpr COLORREF COLOR_DISABLED =
        RGB(175, 187, 200);

    constexpr COLORREF COLOR_DISABLED_BORDER =
        RGB(120, 140, 158);

    constexpr COLORREF COLOR_LIGHT_GREEN =
        RGB(247, 253, 249);

    constexpr COLORREF COLOR_LIGHT_RED =
        RGB(255, 247, 247);

    constexpr COLORREF COLOR_LIGHT_BLUE =
        RGB(246, 250, 254);

    // ========================================================================
    // Fontes
    // ========================================================================

    HFONT CreateSegoeFont(
        int height,
        int weight = FW_NORMAL
    )
    {
        return CreateFontW(
            height,
            0,
            0,
            0,
            weight,
            FALSE,
            FALSE,
            FALSE,
            DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS,
            CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY,
            DEFAULT_PITCH,
            L"Segoe UI"
        );
    }

    void CreateFonts()
    {
        gBrandFont = CreateSegoeFont(-21, FW_SEMIBOLD);
        gSubtitleFont = CreateSegoeFont(-14);
        gMenuFont = CreateSegoeFont(-17);
        gTitleFont = CreateSegoeFont(-31);
        gHeadlineFont = CreateSegoeFont(-22, FW_SEMIBOLD);
        gBodyFont = CreateSegoeFont(-16);
        gButtonFont = CreateSegoeFont(-16);
        gSmallFont = CreateSegoeFont(-14);
        gTinyFont = CreateSegoeFont(-13);
    }

    void DestroyFonts()
    {
        if (gBrandFont)
            DeleteObject(gBrandFont);

        if (gSubtitleFont)
            DeleteObject(gSubtitleFont);

        if (gMenuFont)
            DeleteObject(gMenuFont);

        if (gTitleFont)
            DeleteObject(gTitleFont);

        if (gHeadlineFont)
            DeleteObject(gHeadlineFont);

        if (gBodyFont)
            DeleteObject(gBodyFont);

        if (gButtonFont)
            DeleteObject(gButtonFont);

        if (gSmallFont)
            DeleteObject(gSmallFont);

        if (gTinyFont)
            DeleteObject(gTinyFont);
    }

    // ========================================================================
    // Caminhos
    // ========================================================================

    fs::path ApplicationPath()
    {
        wchar_t buffer[32768]{};

        const DWORD length = GetModuleFileNameW(
            nullptr,
            buffer,
            static_cast<DWORD>(_countof(buffer))
        );

        if (length == 0)
            return {};

        return fs::path(
            std::wstring(buffer, length)
        );
    }

    fs::path ApplicationDirectory()
    {
        return ApplicationPath().parent_path();
    }

    fs::path DefenderPath()
    {
        return ApplicationDirectory() /
            L"Defender.exe";
    }

    fs::path ProgramDataDirectory()
    {
        PWSTR knownPath = nullptr;
        fs::path baseDirectory;
        if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_ProgramData, KF_FLAG_DEFAULT, nullptr, &knownPath)) && knownPath)
        {
            baseDirectory = knownPath;
            CoTaskMemFree(knownPath);
        }
        else
        {
            wchar_t windows[MAX_PATH]{};
            if (GetWindowsDirectoryW(windows, MAX_PATH) > 0)
                baseDirectory = fs::path(windows).root_path() / L"ProgramData";
            else
                baseDirectory = L"C:\\ProgramData";
        }
        return baseDirectory / L"Macrobyte" / L"VistasDefender";
    }

    fs::path LogDirectory()
    {
        return ProgramDataDirectory() /
            L"Logs";
    }

    fs::path UiLogPath()
    {
        return LogDirectory() /
            L"VistasUI.log";
    }

    // ========================================================================
    // Conversão de strings
    // ========================================================================

    std::string WideToUtf8(
        const std::wstring& text
    )
    {
        if (text.empty())
            return {};

        const int requiredSize =
            WideCharToMultiByte(
                CP_UTF8,
                0,
                text.c_str(),
                static_cast<int>(text.size()),
                nullptr,
                0,
                nullptr,
                nullptr
            );

        if (requiredSize <= 0)
            return {};

        std::string converted(
            static_cast<size_t>(requiredSize),
            '\0'
        );

        WideCharToMultiByte(
            CP_UTF8,
            0,
            text.c_str(),
            static_cast<int>(text.size()),
            converted.data(),
            requiredSize,
            nullptr,
            nullptr
        );

        return converted;
    }

    std::wstring Utf8ToWide(
        const std::string& text
    )
    {
        if (text.empty())
            return {};

        const int requiredSize =
            MultiByteToWideChar(
                CP_UTF8,
                0,
                text.c_str(),
                static_cast<int>(text.size()),
                nullptr,
                0
            );

        if (requiredSize <= 0)
            return {};

        std::wstring converted(
            static_cast<size_t>(requiredSize),
            L'\0'
        );

        MultiByteToWideChar(
            CP_UTF8,
            0,
            text.c_str(),
            static_cast<int>(text.size()),
            converted.data(),
            requiredSize
        );

        return converted;
    }

    std::wstring ToLower(
        std::wstring text
    )
    {
        std::transform(
            text.begin(),
            text.end(),
            text.begin(),
            [](wchar_t character)
            {
                return static_cast<wchar_t>(
                    std::towlower(character)
                );
            }
        );

        return text;
    }

    bool ContainsCaseInsensitive(
        const std::wstring& text,
        const std::wstring& value
    )
    {
        return
            ToLower(text).find(ToLower(value)) !=
            std::wstring::npos;
    }

    bool IsSha256Oid(
        const char* oid
    )
    {
        if (!oid)
            return false;

        return
            strcmp(oid, szOID_NIST_sha256) == 0 ||
            strcmp(oid, szOID_RSA_SHA256RSA) == 0 ||
            strcmp(oid, "1.2.840.10045.4.3.2") == 0;
    }

    // ========================================================================
    // Data e hora
    // ========================================================================

    std::wstring CurrentDateTime()
    {
        SYSTEMTIME time{};
        GetLocalTime(&time);

        wchar_t buffer[64]{};

        swprintf_s(
            buffer,
            L"%02u/%02u/%04u %02u:%02u:%02u",
            time.wDay,
            time.wMonth,
            time.wYear,
            time.wHour,
            time.wMinute,
            time.wSecond
        );

        return buffer;
    }

    // ========================================================================
    // Log de eventos
    // ========================================================================

    void EnsureLogDirectory()
    {
        std::error_code error;
        fs::create_directories(
            LogDirectory(),
            error
        );
    }

    void SaveEventToFile(
        const EventRecord& event
    )
    {
        EnsureLogDirectory();

        auto sanitize = [](std::wstring value) {
            for (wchar_t& c : value) {
                if (c == L'\t' || c == L'\r' || c == L'\n') c = L' ';
            }
            return value;
        };
        std::wstring line = sanitize(event.time) + L"\t" + sanitize(event.category) +
            L"\t" + sanitize(event.message) + L"\r\n";

        const std::string utf8 =
            WideToUtf8(line);

        if (utf8.empty())
            return;

        HANDLE file = CreateFileW(
            UiLogPath().c_str(),
            FILE_APPEND_DATA,
            FILE_SHARE_READ |
            FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr
        );

        if (file == INVALID_HANDLE_VALUE)
            return;

        DWORD written = 0;

        const BOOL writeOk = WriteFile(
            file, utf8.data(), static_cast<DWORD>(utf8.size()), &written, nullptr);
        const DWORD writeError = writeOk ? ERROR_SUCCESS : GetLastError();
        CloseHandle(file);
        if (!writeOk || written != utf8.size()) {
            // Do not recurse into AddEvent; emit debugger diagnostics only.
            OutputDebugStringW((L"VistasUI: event log write failed, error=" +
                std::to_wstring(writeError)).c_str());
        }
    }

    void AddEvent(
        const std::wstring& category,
        const std::wstring& message
    )
    {
        EventRecord event;
        event.time = CurrentDateTime();
        event.category = category;
        event.message = message;

        gEvents.push_back(event);

        if (gEvents.size() > 200)
        {
            gEvents.erase(
                gEvents.begin(),
                gEvents.begin() + 50
            );
        }

        SaveEventToFile(event);
    }

    void LoadEvents()
    {
        gEvents.clear();

        HANDLE file = CreateFileW(
            UiLogPath().c_str(),
            GENERIC_READ,
            FILE_SHARE_READ |
            FILE_SHARE_WRITE,
            nullptr,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            nullptr
        );

        if (file == INVALID_HANDLE_VALUE)
            return;

        LARGE_INTEGER size{};

        if (!GetFileSizeEx(file, &size) ||
            size.QuadPart <= 0 ||
            size.QuadPart > 8 * 1024 * 1024)
        {
            CloseHandle(file);
            return;
        }

        std::string data(
            static_cast<size_t>(size.QuadPart),
            '\0'
        );

        DWORD bytesRead = 0;

        const BOOL readOk = ReadFile(
            file,
            data.data(),
            static_cast<DWORD>(data.size()),
            &bytesRead,
            nullptr
        );

        CloseHandle(file);

        if (!readOk || bytesRead == 0)
            return;

        data.resize(bytesRead);

        size_t position = 0;

        while (position < data.size())
        {
            const size_t lineEnd =
                data.find('\n', position);

            const size_t length =
                lineEnd == std::string::npos
                    ? data.size() - position
                    : lineEnd - position;

            std::string line =
                data.substr(position, length);

            if (!line.empty() &&
                line.back() == '\r')
            {
                line.pop_back();
            }

            const size_t firstTab =
                line.find('\t');

            const size_t secondTab =
                firstTab == std::string::npos
                    ? std::string::npos
                    : line.find(
                        '\t',
                        firstTab + 1
                    );

            if (firstTab != std::string::npos &&
                secondTab != std::string::npos)
            {
                EventRecord event;

                event.time = Utf8ToWide(
                    line.substr(0, firstTab)
                );

                event.category = Utf8ToWide(
                    line.substr(
                        firstTab + 1,
                        secondTab - firstTab - 1
                    )
                );

                event.message = Utf8ToWide(
                    line.substr(secondTab + 1)
                );

                gEvents.push_back(event);
            }

            if (lineEnd == std::string::npos)
                break;

            position = lineEnd + 1;
        }

        if (gEvents.size() > 200)
        {
            gEvents.erase(
                gEvents.begin(),
                gEvents.end() - 200
            );
        }
    }

    void ClearEvents()
    {
        gEvents.clear();

        DeleteFileW(
            UiLogPath().c_str()
        );
    }

    // ========================================================================
    // Verificação Authenticode
    // ========================================================================

    LONG VerifyAuthenticodeTrust(
        const fs::path& filePath
    )
    {
        WINTRUST_FILE_INFO fileInfo{};
        fileInfo.cbStruct = sizeof(fileInfo);
        fileInfo.pcwszFilePath =
            filePath.c_str();

        WINTRUST_DATA trustData{};
        trustData.cbStruct =
            sizeof(trustData);

        trustData.dwUIChoice =
            WTD_UI_NONE;

        // Validação local para não bloquear a interface esperando rede.
        trustData.fdwRevocationChecks =
            WTD_REVOKE_NONE;

        trustData.dwUnionChoice =
            WTD_CHOICE_FILE;

        trustData.pFile =
            &fileInfo;

        trustData.dwStateAction =
            WTD_STATEACTION_VERIFY;

        trustData.dwProvFlags =
            WTD_CACHE_ONLY_URL_RETRIEVAL;

        GUID action =
            WINTRUST_ACTION_GENERIC_VERIFY_V2;

        const LONG result = WinVerifyTrust(
            nullptr,
            &action,
            &trustData
        );

        trustData.dwStateAction =
            WTD_STATEACTION_CLOSE;

        WinVerifyTrust(
            nullptr,
            &action,
            &trustData
        );

        return result;
    }

    bool TrustResultAllowsLocalCertificate(
        LONG trustResult
    )
    {
        // WinVerifyTrust defines exactly zero as success; warnings/errors fail closed.
        return trustResult == ERROR_SUCCESS;
    }

    SignatureResult InspectSignature(
        const fs::path& filePath
    )
    {
        SignatureResult result;

        std::error_code error;

        result.fileExists =
            fs::exists(filePath, error);

        if (!result.fileExists)
        {
            result.message =
                L"Arquivo obrigatório ausente";

            return result;
        }

        HCERTSTORE certificateStore = nullptr;
        HCRYPTMSG cryptMessage = nullptr;

        DWORD encoding = 0;
        DWORD contentType = 0;
        DWORD formatType = 0;

        const BOOL queried = CryptQueryObject(
            CERT_QUERY_OBJECT_FILE,
            filePath.c_str(),
            CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY,
            0,
            &encoding,
            &contentType,
            &formatType,
            &certificateStore,
            &cryptMessage,
            nullptr
        );

        if (!queried)
        {
            result.message =
                L"Assinatura OArthurMamaco Security ausente";

            return result;
        }

        result.signaturePresent = true;

        DWORD signerInfoSize = 0;

        if (!CryptMsgGetParam(
                cryptMessage,
                CMSG_SIGNER_INFO_PARAM,
                0,
                nullptr,
                &signerInfoSize
            ))
        {
            result.message =
                L"Não foi possível ler a assinatura";

            if (cryptMessage)
                CryptMsgClose(cryptMessage);

            if (certificateStore)
                CertCloseStore(certificateStore, 0);

            return result;
        }

        std::vector<BYTE> signerBuffer(
            signerInfoSize
        );

        if (!CryptMsgGetParam(
                cryptMessage,
                CMSG_SIGNER_INFO_PARAM,
                0,
                signerBuffer.data(),
                &signerInfoSize
            ))
        {
            result.message =
                L"Não foi possível ler o assinante";

            CryptMsgClose(cryptMessage);
            CertCloseStore(certificateStore, 0);

            return result;
        }

        const auto* signerInfo =
            reinterpret_cast<const CMSG_SIGNER_INFO*>(
                signerBuffer.data()
            );

        result.digestSha256 =
            IsSha256Oid(
                signerInfo->HashAlgorithm.pszObjId
            );

        CERT_INFO certificateInfo{};

        certificateInfo.Issuer =
            signerInfo->Issuer;

        certificateInfo.SerialNumber =
            signerInfo->SerialNumber;

        PCCERT_CONTEXT certificate =
            CertFindCertificateInStore(
                certificateStore,
                X509_ASN_ENCODING |
                PKCS_7_ASN_ENCODING,
                0,
                CERT_FIND_SUBJECT_CERT,
                &certificateInfo,
                nullptr
            );

        if (certificate)
        {
            wchar_t publisher[512]{};

            const DWORD publisherLength =
                CertGetNameStringW(
                    certificate,
                    CERT_NAME_SIMPLE_DISPLAY_TYPE,
                    0,
                    nullptr,
                    publisher,
                    static_cast<DWORD>(
                        _countof(publisher)
                    )
                );

            if (publisherLength > 1)
                result.publisher = publisher;

            // Publisher must match the complete display name; substring matches allow spoofed names.
            result.publisherMatches =
                _wcsicmp(result.publisher.c_str(), EXPECTED_PUBLISHER) == 0;

            CertFreeCertificateContext(
                certificate
            );
        }

        const LONG trustResult =
            VerifyAuthenticodeTrust(filePath);

        result.cryptographicIntegrity =
            TrustResultAllowsLocalCertificate(
                trustResult
            );

        if (!result.publisherMatches)
        {
            if (result.publisher.empty())
            {
                result.message =
                    L"Editor da assinatura não identificado";
            }
            else
            {
                result.message =
                    L"Assinado por outro editor: " +
                    result.publisher;
            }
        }
        else if (!result.digestSha256)
        {
            result.message =
                L"Assinatura não utiliza SHA-256";
        }
        else if (!result.cryptographicIntegrity)
        {
            if (trustResult == TRUST_E_BAD_DIGEST)
            {
                result.message =
                    L"Arquivo alterado após a assinatura";
            }
            else if (trustResult == TRUST_E_NOSIGNATURE)
            {
                result.message =
                    L"Arquivo não possui assinatura válida";
            }
            else
            {
                result.message =
                    L"Assinatura criptográfica inválida";
            }
        }
        else
        {
            result.message =
                L"OK | OArthurMamaco Security | SHA-256";
        }

        if (cryptMessage)
            CryptMsgClose(cryptMessage);

        if (certificateStore)
            CertCloseStore(certificateStore, 0);

        return result;
    }

    // ========================================================================
    // Integridade dos componentes
    // ========================================================================

    const std::vector<std::wstring>& ComponentNames()
    {
        static const std::vector<std::wstring> names
        {
            L"VistasUI.exe",
            L"Defender.exe",
            L"Visne.dll",
            L"htlk.dll",
            L"Update.dll"
        };

        return names;
    }

    void CheckAllComponents()
    {
        gIntegrityResults.clear();

        for (const auto& name : ComponentNames())
        {
            ComponentResult component;

            component.fileName = name;

            component.signature =
                InspectSignature(
                    ApplicationDirectory() /
                    name
                );

            gIntegrityResults.push_back(
                component
            );
        }

        gIntegrityChecked = true;
    }

    bool AllComponentsValid()
    {
        if (!gIntegrityChecked ||
            gIntegrityResults.empty())
        {
            return false;
        }

        for (const auto& component :
             gIntegrityResults)
        {
            if (!component.signature.IsValid())
                return false;
        }

        return true;
    }

    int CountValidComponents()
    {
        int validCount = 0;

        for (const auto& component :
             gIntegrityResults)
        {
            if (component.signature.IsValid())
                ++validCount;
        }

        return validCount;
    }

    std::wstring BuildIntegrityFailureMessage()
    {
        std::wostringstream message;

        message
            << L"A proteção não pode ser ativada.\n\n"
            << L"Os seguintes componentes falharam:\n\n";

        for (const auto& component :
             gIntegrityResults)
        {
            if (component.signature.IsValid())
                continue;

            message
                << L"• "
                << component.fileName
                << L": "
                << component.signature.message
                << L"\n";
        }

        message
            << L"\nTodos os componentes precisam estar assinados por "
            << EXPECTED_PUBLISHER
            << L" usando SHA-256.";

        return message.str();
    }

    // ========================================================================
    // Atualizações
    // ========================================================================

    void OpenRepositoryPage()
    {
        const HINSTANCE result = ShellExecuteW(
            nullptr,
            L"open",
            UPDATE_REPOSITORY_URL,
            nullptr,
            nullptr,
            SW_SHOWNORMAL
        );

        if (reinterpret_cast<INT_PTR>(result) <= 32)
        {
            AddEvent(
                L"Atualizações",
                L"Não foi possível abrir o repositório no navegador."
            );
        }
        else
        {
            AddEvent(
                L"Atualizações",
                L"Repositório aberto no navegador."
            );
        }
    }

    void CheckUpdates()
    {
        CheckAllComponents();

        gUpdateResult.checked = true;

        gUpdateResult.totalComponents =
            static_cast<int>(
                gIntegrityResults.size()
            );

        gUpdateResult.validComponents =
            CountValidComponents();

        gUpdateResult.packageValid =
            AllComponentsValid();

        gUpdateResult.checkedAt =
            CurrentDateTime();

        if (gUpdateResult.packageValid)
        {
            gUpdateResult.title =
                L"Componentes locais íntegros";

            gUpdateResult.description =
                L"A verificação examinou a integridade dos componentes locais. A versão remota não foi comparada automaticamente; o repositório foi aberto para consulta manual.";
        }
        else
        {
            gUpdateResult.title =
                L"O pacote precisa de manutenção";

            gUpdateResult.description =
                L"A verificação local encontrou componentes ausentes, sem assinatura válida ou modificados. A versão remota não foi comparada automaticamente.";
        }

        std::wostringstream logMessage;

        logMessage
            << L"Verificação concluída: "
            << gUpdateResult.validComponents
            << L" de "
            << gUpdateResult.totalComponents
            << L" componentes válidos.";

        AddEvent(
            L"Atualizações",
            logMessage.str()
        );
    }

    // ========================================================================
    // Administrador
    // ========================================================================

    bool IsAdministrator()
    {
        BOOL isMember = FALSE;

        PSID administratorsGroup = nullptr;

        SID_IDENTIFIER_AUTHORITY authority =
            SECURITY_NT_AUTHORITY;

        if (!AllocateAndInitializeSid(
                &authority,
                2,
                SECURITY_BUILTIN_DOMAIN_RID,
                DOMAIN_ALIAS_RID_ADMINS,
                0,
                0,
                0,
                0,
                0,
                0,
                &administratorsGroup
            ))
        {
            return false;
        }

        CheckTokenMembership(
            nullptr,
            administratorsGroup,
            &isMember
        );

        FreeSid(administratorsGroup);

        return isMember == TRUE;
    }

    bool RelaunchElevated()
    {
        const fs::path executable =
            ApplicationPath();

        const HINSTANCE result = ShellExecuteW(
            nullptr,
            L"runas",
            executable.c_str(),
            nullptr,
            executable.parent_path().c_str(),
            SW_SHOWNORMAL
        );

        return
            reinterpret_cast<INT_PTR>(result) >
            32;
    }

    // ========================================================================
    // Estado do Defender
    // ========================================================================

    bool IsDefenderRunning()
    {
        HANDLE mutex = OpenMutexW(
            SYNCHRONIZE,
            FALSE,
            ENGINE_MUTEX
        );

        if (!mutex)
            return false;

        CloseHandle(mutex);

        return true;
    }

    // ========================================================================
    // Execução autorizada do Defender
    // ========================================================================

    bool StartDefender()
    {
        CheckAllComponents();

        if (!AllComponentsValid())
        {
            AddEvent(
                L"Proteção",
                L"Ativação bloqueada por falha de integridade."
            );

            const std::wstring message =
                BuildIntegrityFailureMessage();

            MessageBoxW(
                gMainWindow,
                message.c_str(),
                L"Falha de integridade",
                MB_OK | MB_ICONERROR
            );

            gCurrentPage = Page::Integrity;
            return false;
        }

        if (IsDefenderRunning())
        {
            AddEvent(
                L"Proteção",
                L"Tentativa de ativação ignorada: o Defender já estava executando."
            );
            return true;
        }

        const fs::path defender = DefenderPath();
        STARTUPINFOW startupInfo{};
        startupInfo.cb = sizeof(startupInfo);
        PROCESS_INFORMATION processInformation{};

        std::wstring commandLine = L"\"" + defender.wstring() + L"\"";

        const BOOL created = CreateProcessW(
            defender.c_str(),
            commandLine.data(),
            nullptr,
            nullptr,
            FALSE,
            CREATE_UNICODE_ENVIRONMENT,
            nullptr,
            defender.parent_path().c_str(),
            &startupInfo,
            &processInformation
        );

        if (!created)
        {
            const DWORD errorCode = GetLastError();
            std::wostringstream errorMessage;
            errorMessage
                << L"Não foi possível iniciar o Defender.exe. Código: "
                << errorCode;

            AddEvent(L"Erro", errorMessage.str());
            MessageBoxW(
                gMainWindow,
                errorMessage.str().c_str(),
                L"Vistas Defender",
                MB_OK | MB_ICONERROR
            );
            return false;
        }

        CloseHandle(processInformation.hThread);
        CloseHandle(processInformation.hProcess);

        Sleep(300);

        const bool running = IsDefenderRunning();
        if (running)
        {
            AddEvent(
                L"Proteção",
                L"Proteção em tempo real ativada com sucesso."
            );
        }
        else
        {
            AddEvent(
                L"Erro",
                L"O processo foi iniciado, mas o mutex do motor não foi localizado."
            );
        }

        return running;
    }

    bool StopDefender()
    {
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
        {
            AddEvent(L"Erro", L"Não foi possível enumerar os processos do sistema.");
            return false;
        }

        const std::wstring expectedPath = ApplicationPath().empty()
            ? L"" : fs::absolute(DefenderPath()).lexically_normal().wstring();
        auto normalize = [](std::wstring value) {
            std::transform(value.begin(), value.end(), value.begin(),
                [](wchar_t c) { return static_cast<wchar_t>(std::towlower(c)); });
            while (value.size() > 3 && (value.back() == L'\\' || value.back() == L'/')) value.pop_back();
            return value;
        };
        const std::wstring expectedNormalized = normalize(expectedPath);
        PROCESSENTRY32W entry{};
        entry.dwSize = sizeof(entry);
        bool found = false;
        bool stopped = false;

        if (Process32FirstW(snapshot, &entry)) {
            do {
                if (_wcsicmp(entry.szExeFile, L"Defender.exe") != 0) continue;
                HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE | SYNCHRONIZE,
                                             FALSE, entry.th32ProcessID);
                if (!process) continue;
                std::vector<wchar_t> image(32768);
                DWORD imageChars = static_cast<DWORD>(image.size());
                const bool gotPath = QueryFullProcessImageNameW(process, 0, image.data(), &imageChars) != FALSE;
                const std::wstring actual = gotPath ? normalize(std::wstring(image.data(), imageChars)) : L"";
                if (!expectedNormalized.empty() && actual == expectedNormalized) {
                    found = true;
                    if (TerminateProcess(process, ERROR_CANCELLED)) {
                        WaitForSingleObject(process, 3000);
                        stopped = true;
                    }
                }
                CloseHandle(process);
            } while (Process32NextW(snapshot, &entry));
        }
        CloseHandle(snapshot);

        if (!found) {
            AddEvent(L"Proteção", L"Desativação solicitada, mas a instância deste diretório já estava parada.");
            return true;
        }
        if (stopped) {
            AddEvent(L"Proteção", L"Instância esperada do Defender.exe encerrada pelo caminho verificado.");
        } else {
            AddEvent(L"Erro", L"A instância esperada do Defender.exe não pôde ser finalizada.");
        }
        return stopped;
    }

    // ========================================================================
    // Preferências persistentes e textos localizados
    // ========================================================================

    const wchar_t* UiText(const wchar_t* pt, const wchar_t* en, const wchar_t* es)
    {
        switch (gSettings.language) {
        case 1: return en;
        case 2: return es;
        default: return pt;
        }
    }

    DWORD ReadSettingDword(const wchar_t* name, DWORD fallback)
    {
        DWORD value = fallback, type = 0, size = sizeof(value);
        if (RegGetValueW(HKEY_LOCAL_MACHINE, SETTINGS_REGISTRY_KEY, name,
                RRF_RT_REG_DWORD, &type, &value, &size) != ERROR_SUCCESS)
            return fallback;
        return value;
    }

    void LoadSettings()
    {
        gSettings.language = ReadSettingDword(L"Language", 0);
        if (gSettings.language > 2) gSettings.language = 0;
        gSettings.scanAtStartup = ReadSettingDword(L"ScanAtStartup", 0) ? 1 : 0;
        gSettings.scanDays = ReadSettingDword(L"ScanDays", 0) & 0x7F;
        gSettings.protectionMode = ReadSettingDword(L"ProtectionMode", 1);
        if (gSettings.protectionMode > 2) gSettings.protectionMode = 1;
    }

    bool WriteSettingDword(const wchar_t* name, DWORD value)
    {
        HKEY key = nullptr;
        if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, SETTINGS_REGISTRY_KEY, 0, nullptr, 0,
                KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS)
            return false;
        const LONG status = RegSetValueExW(key, name, 0, REG_DWORD,
            reinterpret_cast<const BYTE*>(&value), sizeof(value));
        RegCloseKey(key);
        return status == ERROR_SUCCESS;
    }

    bool SaveSettings()
    {
        return WriteSettingDword(L"Language", gSettings.language) &&
            WriteSettingDword(L"ScanAtStartup", gSettings.scanAtStartup) &&
            WriteSettingDword(L"ScanDays", gSettings.scanDays) &&
            WriteSettingDword(L"ProtectionMode", gSettings.protectionMode);
    }

    const wchar_t* LanguageName()
    {
        return UiText(L"Português (Brasil)", L"English", L"Español");
    }

    const wchar_t* ProtectionModeName()
    {
        if (gSettings.protectionMode == 0)
            return UiText(L"Observação", L"Monitor only", L"Solo supervisión");
        if (gSettings.protectionMode == 2)
            return UiText(L"Rigoroso", L"Strict", L"Estricta");
        return UiText(L"Equilibrado", L"Balanced", L"Equilibrada");
    }

    void UpdateSettingsButtonLabels()
    {
        if (gSettingsLanguageButton) {
            std::wstring label = std::wstring(UiText(L"Idioma: ", L"Language: ", L"Idioma: ")) + LanguageName();
            SetWindowTextW(gSettingsLanguageButton, label.c_str());
        }
        if (gSettingsStartupButton) {
            std::wstring label = std::wstring(UiText(L"Verificar ao iniciar: ", L"Scan at startup: ", L"Analizar al iniciar: ")) +
                (gSettings.scanAtStartup ? UiText(L"SIM", L"ON", L"SÍ") : UiText(L"NÃO", L"OFF", L"NO"));
            SetWindowTextW(gSettingsStartupButton, label.c_str());
        }
        if (gSettingsModeButton) {
            std::wstring label = std::wstring(UiText(L"Intervenção: ", L"Intervention: ", L"Intervención: ")) + ProtectionModeName();
            SetWindowTextW(gSettingsModeButton, label.c_str());
        }
        static const wchar_t* ptDays[] = { L"Seg", L"Ter", L"Qua", L"Qui", L"Sex", L"Sáb", L"Dom" };
        static const wchar_t* enDays[] = { L"Mon", L"Tue", L"Wed", L"Thu", L"Fri", L"Sat", L"Sun" };
        static const wchar_t* esDays[] = { L"Lun", L"Mar", L"Mié", L"Jue", L"Vie", L"Sáb", L"Dom" };
        const wchar_t** labels = gSettings.language == 1 ? enDays : (gSettings.language == 2 ? esDays : ptDays);
        for (int i = 0; i < 7; ++i) {
            if (!gSettingsDayButtons[i]) continue;
            std::wstring label = ((gSettings.scanDays & (1u << i)) ? L"✓ " : L"○ ") + std::wstring(labels[i]);
            SetWindowTextW(gSettingsDayButtons[i], label.c_str());
        }
    }

    void RefreshLocalizedControls()
    {
        if (gHomeButton) SetWindowTextW(gHomeButton, UiText(L"Início", L"Home", L"Inicio"));
        if (gProtectionButton) SetWindowTextW(gProtectionButton, UiText(L"Proteção", L"Protection", L"Protección"));
        if (gIntegrityButton) SetWindowTextW(gIntegrityButton, UiText(L"Integridade", L"Integrity", L"Integridad"));
        if (gUpdatesButton) SetWindowTextW(gUpdatesButton, UiText(L"Atualizações", L"Updates", L"Actualizaciones"));
        if (gEventsButton) SetWindowTextW(gEventsButton, UiText(L"Eventos", L"Events", L"Eventos"));
        if (gSettingsButton) SetWindowTextW(gSettingsButton, UiText(L"Configurações", L"Settings", L"Configuración"));
        if (gHomeActionButton) SetWindowTextW(gHomeActionButton, UiText(L"ATIVAR PROTEÇÃO", L"ENABLE PROTECTION", L"ACTIVAR PROTECCIÓN"));
        if (gProtectionEnableButton) SetWindowTextW(gProtectionEnableButton, UiText(L"ATIVAR PROTEÇÃO", L"ENABLE PROTECTION", L"ACTIVAR PROTECCIÓN"));
        if (gProtectionDisableButton) SetWindowTextW(gProtectionDisableButton, UiText(L"DESATIVAR PROTEÇÃO", L"DISABLE PROTECTION", L"DESACTIVAR PROTECCIÓN"));
        if (gScanDiskButton) SetWindowTextW(gScanDiskButton, UiText(L"VERIFICAR DISCO...", L"SCAN DISK...", L"ANALIZAR DISCO..."));
        if (gIntegrityCheckButton) SetWindowTextW(gIntegrityCheckButton, UiText(L"VERIFICAR NOVAMENTE", L"CHECK AGAIN", L"VERIFICAR DE NUEVO"));
        if (gUpdatesCheckButton) SetWindowTextW(gUpdatesCheckButton, UiText(L"VERIFICAR COMPONENTES", L"VERIFY COMPONENTS", L"VERIFICAR COMPONENTES"));
        if (gEventsRefreshButton) SetWindowTextW(gEventsRefreshButton, UiText(L"ATUALIZAR LISTA", L"REFRESH LIST", L"ACTUALIZAR LISTA"));
        if (gEventsClearButton) SetWindowTextW(gEventsClearButton, UiText(L"LIMPAR EVENTOS", L"CLEAR EVENTS", L"BORRAR EVENTOS"));
        UpdateSettingsButtonLabels();
    }

    // ========================================================================
    // Navegação
    // ========================================================================

    bool IsCurrentPage(
        int controlId
    )
    {
        switch (controlId)
        {
        case ID_HOME:
            return gCurrentPage == Page::Home;

        case ID_PROTECTION:
            return gCurrentPage == Page::Protection;

        case ID_INTEGRITY:
            return gCurrentPage == Page::Integrity;

        case ID_UPDATES:
            return gCurrentPage == Page::Updates;

        case ID_EVENTS:
            return gCurrentPage == Page::Events;

        case ID_SETTINGS:
            return gCurrentPage == Page::Settings;

        default:
            return false;
        }
    }

    const wchar_t* CurrentPageTitle()
    {
        switch (gCurrentPage) {
        case Page::Home: return UiText(L"Visão geral", L"Overview", L"Resumen");
        case Page::Protection: return UiText(L"Proteção em tempo real", L"Real-time protection", L"Protección en tiempo real");
        case Page::Integrity: return UiText(L"Integridade dos componentes", L"Component integrity", L"Integridad de componentes");
        case Page::Updates: return UiText(L"Atualizações", L"Updates", L"Actualizaciones");
        case Page::Events: return UiText(L"Eventos e erros", L"Events and errors", L"Eventos y errores");
        case Page::Settings: return UiText(L"Configurações", L"Settings", L"Configuración");
        default: return L"Vistas Defender";
        }
    }

    // ========================================================================
    // Controles
    // ========================================================================

    HWND CreateNavigationButton(
        HWND parent,
        int id,
        const wchar_t* text,
        int y
    )
    {
        HWND button = CreateWindowExW(
            0,
            L"BUTTON",
            text,
            WS_CHILD |
            WS_VISIBLE |
            BS_OWNERDRAW,
            0,
            y,
            SIDEBAR_WIDTH,
            42,
            parent,
            reinterpret_cast<HMENU>(
                static_cast<INT_PTR>(id)
            ),
            gInstance,
            nullptr
        );

        SendMessageW(
            button,
            WM_SETFONT,
            reinterpret_cast<WPARAM>(
                gMenuFont
            ),
            TRUE
        );

        return button;
    }

    HWND CreateActionButton(
        HWND parent,
        int id,
        const wchar_t* text,
        int x,
        int y,
        int width,
        int height
    )
    {
        HWND button = CreateWindowExW(
            0,
            L"BUTTON",
            text,
            WS_CHILD |
            BS_OWNERDRAW,
            x,
            y,
            width,
            height,
            parent,
            reinterpret_cast<HMENU>(
                static_cast<INT_PTR>(id)
            ),
            gInstance,
            nullptr
        );

        SendMessageW(
            button,
            WM_SETFONT,
            reinterpret_cast<WPARAM>(
                gButtonFont
            ),
            TRUE
        );

        return button;
    }

    void CreateControls(
        HWND window
    )
    {
        gHomeButton = CreateNavigationButton(
            window,
            ID_HOME,
            UiText(L"Início", L"Home", L"Inicio"),
            127
        );

        gProtectionButton = CreateNavigationButton(
            window,
            ID_PROTECTION,
            UiText(L"Proteção", L"Protection", L"Protección"),
            169
        );

        gIntegrityButton = CreateNavigationButton(
            window,
            ID_INTEGRITY,
            UiText(L"Integridade", L"Integrity", L"Integridad"),
            211
        );

        gUpdatesButton = CreateNavigationButton(
            window,
            ID_UPDATES,
            UiText(L"Atualizações", L"Updates", L"Actualizaciones"),
            253
        );

        gEventsButton = CreateNavigationButton(
            window,
            ID_EVENTS,
            UiText(L"Eventos", L"Events", L"Eventos"),
            295
        );

        gSettingsButton = CreateNavigationButton(
            window,
            ID_SETTINGS,
            UiText(L"Configurações", L"Settings", L"Configuración"),
            337
        );

        gHomeActionButton = CreateActionButton(
            window,
            ID_HOME_ACTION,
            L"ATIVAR PROTEÇÃO",
            589,
            274,
            220,
            38
        );

        gProtectionEnableButton =
            CreateActionButton(
                window,
                ID_PROTECTION_ENABLE,
                L"ATIVAR PROTEÇÃO",
                572,
                344,
                240,
                42
            );

        gProtectionDisableButton =
            CreateActionButton(
                window,
                ID_PROTECTION_DISABLE,
                L"DESATIVAR PROTEÇÃO",
                572,
                400,
                240,
                42
            );

        gScanDiskButton = CreateActionButton(
            window, ID_SCAN_DISK,
            UiText(L"VERIFICAR DISCO...", L"SCAN DISK...", L"ANALIZAR DISCO..."),
            572, 456, 240, 42);

        gSettingsLanguageButton = CreateActionButton(
            window, ID_SETTINGS_LANGUAGE, L"Idioma", 480, 196, 330, 40);
        gSettingsStartupButton = CreateActionButton(
            window, ID_SETTINGS_STARTUP, L"Verificar ao iniciar", 480, 252, 330, 40);
        gSettingsModeButton = CreateActionButton(
            window, ID_SETTINGS_MODE, L"Intervenção", 480, 308, 330, 40);
        static const int dayXs[7] = { 260, 338, 416, 494, 572, 650, 728 };
        for (int i = 0; i < 7; ++i) {
            gSettingsDayButtons[i] = CreateActionButton(
                window, ID_SETTINGS_DAY_BASE + i, L"Dia", dayXs[i], 430, 72, 38);
        }
        UpdateSettingsButtonLabels();

        gIntegrityCheckButton =
            CreateActionButton(
                window,
                ID_INTEGRITY_CHECK,
                L"VERIFICAR NOVAMENTE",
                572,
                420,
                240,
                42
            );

        gUpdatesCheckButton =
            CreateActionButton(
                window,
                ID_UPDATES_CHECK,
                L"VERIFICAR ATUALIZAÇÕES",
                552,
                430,
                260,
                42
            );

        gEventsRefreshButton =
            CreateActionButton(
                window,
                ID_EVENTS_REFRESH,
                L"ATUALIZAR LISTA",
                512,
                518,
                145,
                38
            );

        gEventsClearButton =
            CreateActionButton(
                window,
                ID_EVENTS_CLEAR,
                L"LIMPAR EVENTOS",
                667,
                518,
                145,
                38
            );
    }

    void UpdatePageControls()
    {
        const bool running =
            IsDefenderRunning();

        ShowWindow(
            gHomeActionButton,
            gCurrentPage == Page::Home
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(
            gProtectionEnableButton,
            gCurrentPage == Page::Protection
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(
            gProtectionDisableButton,
            gCurrentPage == Page::Protection
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(gScanDiskButton, gCurrentPage == Page::Protection ? SW_SHOW : SW_HIDE);
        ShowWindow(gSettingsLanguageButton, gCurrentPage == Page::Settings ? SW_SHOW : SW_HIDE);
        ShowWindow(gSettingsStartupButton, gCurrentPage == Page::Settings ? SW_SHOW : SW_HIDE);
        ShowWindow(gSettingsModeButton, gCurrentPage == Page::Settings ? SW_SHOW : SW_HIDE);
        for (int i = 0; i < 7; ++i)
            ShowWindow(gSettingsDayButtons[i], gCurrentPage == Page::Settings ? SW_SHOW : SW_HIDE);

        ShowWindow(
            gIntegrityCheckButton,
            gCurrentPage == Page::Integrity
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(
            gUpdatesCheckButton,
            gCurrentPage == Page::Updates
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(
            gEventsRefreshButton,
            gCurrentPage == Page::Events
                ? SW_SHOW
                : SW_HIDE
        );

        ShowWindow(
            gEventsClearButton,
            gCurrentPage == Page::Events
                ? SW_SHOW
                : SW_HIDE
        );

        SetWindowTextW(gHomeActionButton,
            running ? UiText(L"DESATIVAR PROTEÇÃO", L"DISABLE PROTECTION", L"DESACTIVAR PROTECCIÓN")
                    : UiText(L"ATIVAR PROTEÇÃO", L"ENABLE PROTECTION", L"ACTIVAR PROTECCIÓN"));
        SetWindowTextW(gProtectionEnableButton, UiText(L"ATIVAR PROTEÇÃO", L"ENABLE PROTECTION", L"ACTIVAR PROTECCIÓN"));
        SetWindowTextW(gProtectionDisableButton, UiText(L"DESATIVAR PROTEÇÃO", L"DISABLE PROTECTION", L"DESACTIVAR PROTECCIÓN"));
        SetWindowTextW(gIntegrityCheckButton, UiText(L"VERIFICAR NOVAMENTE", L"CHECK AGAIN", L"VERIFICAR DE NUEVO"));
        SetWindowTextW(gUpdatesCheckButton, UiText(L"VERIFICAR ATUALIZAÇÕES", L"CHECK LOCAL COMPONENTS", L"COMPROBAR COMPONENTES LOCALES"));
        SetWindowTextW(gEventsRefreshButton, UiText(L"ATUALIZAR LISTA", L"REFRESH LIST", L"ACTUALIZAR LISTA"));
        SetWindowTextW(gEventsClearButton, UiText(L"LIMPAR EVENTOS", L"CLEAR EVENTS", L"BORRAR EVENTOS"));

        EnableWindow(
            gProtectionEnableButton,
            running ? FALSE : TRUE
        );

        EnableWindow(
            gProtectionDisableButton,
            running ? TRUE : FALSE
        );

        InvalidateRect(
            gHomeActionButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gProtectionEnableButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gProtectionDisableButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gIntegrityCheckButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gUpdatesCheckButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gEventsRefreshButton,
            nullptr,
            TRUE
        );

        InvalidateRect(
            gEventsClearButton,
            nullptr,
            TRUE
        );
    }

    void RefreshInterface()
    {
        UpdateSettingsButtonLabels();
        if (gHomeButton) SetWindowTextW(gHomeButton, UiText(L"Início", L"Home", L"Inicio"));
        if (gProtectionButton) SetWindowTextW(gProtectionButton, UiText(L"Proteção", L"Protection", L"Protección"));
        if (gIntegrityButton) SetWindowTextW(gIntegrityButton, UiText(L"Integridade", L"Integrity", L"Integridad"));
        if (gUpdatesButton) SetWindowTextW(gUpdatesButton, UiText(L"Atualizações", L"Updates", L"Actualizaciones"));
        if (gEventsButton) SetWindowTextW(gEventsButton, UiText(L"Eventos", L"Events", L"Eventos"));
        if (gSettingsButton) SetWindowTextW(gSettingsButton, UiText(L"Configurações", L"Settings", L"Configuración"));
        if (gScanDiskButton) SetWindowTextW(gScanDiskButton, UiText(L"VERIFICAR DISCO...", L"SCAN DISK...", L"ANALIZAR DISCO..."));
        UpdatePageControls();

        InvalidateRect(
            gMainWindow,
            nullptr,
            TRUE
        );
    }

    void SetCurrentPage(
        Page page
    )
    {
        gCurrentPage = page;

        if (page == Page::Integrity &&
            !gIntegrityChecked)
        {
            CheckAllComponents();
        }

        if (page == Page::Events)
        {
            LoadEvents();
        }

        RefreshInterface();
    }

    // ========================================================================
    // Desenho auxiliar
    // ========================================================================

    void DrawOutlinedRectangle(
        HDC dc,
        const RECT& rectangle,
        COLORREF borderColor,
        COLORREF fillColor
    )
    {
        HBRUSH fillBrush =
            CreateSolidBrush(fillColor);

        FillRect(
            dc,
            &rectangle,
            fillBrush
        );

        DeleteObject(fillBrush);

        HPEN borderPen =
            CreatePen(
                PS_SOLID,
                1,
                borderColor
            );

        HGDIOBJ oldPen =
            SelectObject(
                dc,
                borderPen
            );

        HGDIOBJ oldBrush =
            SelectObject(
                dc,
                GetStockObject(NULL_BRUSH)
            );

        Rectangle(
            dc,
            rectangle.left,
            rectangle.top,
            rectangle.right,
            rectangle.bottom
        );

        SelectObject(dc, oldBrush);
        SelectObject(dc, oldPen);

        DeleteObject(borderPen);
    }

    void DrawTextBlock(
        HDC dc,
        const wchar_t* text,
        RECT rectangle,
        HFONT font,
        COLORREF color,
        UINT format
    )
    {
        HGDIOBJ oldFont =
            SelectObject(dc, font);

        SetBkMode(
            dc,
            TRANSPARENT
        );

        SetTextColor(
            dc,
            color
        );

        DrawTextW(
            dc,
            text,
            -1,
            &rectangle,
            format |
            DT_NOPREFIX
        );

        SelectObject(
            dc,
            oldFont
        );
    }

    void DrawStatusIcon(
        HDC dc,
        int x,
        int y,
        bool healthy
    )
    {
        HICON icon = LoadIconW(
            nullptr,
            healthy
                ? IDI_INFORMATION
                : IDI_WARNING
        );

        if (!icon)
            return;

        DrawIconEx(
            dc,
            x,
            y,
            icon,
            42,
            42,
            0,
            nullptr,
            DI_NORMAL
        );
    }

    // ========================================================================
    // Sidebar e cabeçalho
    // ========================================================================

    void DrawSidebar(
        HDC dc,
        const RECT& client
    )
    {
        RECT sidebar
        {
            0,
            0,
            SIDEBAR_WIDTH,
            client.bottom
        };

        FillRect(
            dc,
            &sidebar,
            gSidebarBrush
        );

        SetBkMode(dc, TRANSPARENT);

        SelectObject(
            dc,
            gBrandFont
        );

        SetTextColor(
            dc,
            COLOR_DARK_BLUE
        );

        TextOutW(
            dc,
            24,
            64,
            L"Vistas Defender",
            15
        );

        SelectObject(
            dc,
            gSubtitleFont
        );

        SetTextColor(
            dc,
            COLOR_MUTED
        );

        const wchar_t* subtitle = UiText(L"Central de segurança", L"Security center", L"Centro de seguridad");
        TextOutW(dc, 24, 94, subtitle, static_cast<int>(wcslen(subtitle)));

        HPEN dividerPen =
            CreatePen(
                PS_SOLID,
                1,
                RGB(190, 210, 228)
            );

        HGDIOBJ oldPen =
            SelectObject(
                dc,
                dividerPen
            );

        MoveToEx(
            dc,
            SIDEBAR_WIDTH - 1,
            0,
            nullptr
        );

        LineTo(
            dc,
            SIDEBAR_WIDTH - 1,
            client.bottom
        );

        SelectObject(dc, oldPen);

        DeleteObject(
            dividerPen
        );
    }

    void DrawHeader(
        HDC dc,
        const RECT& client
    )
    {
        SetBkMode(dc, TRANSPARENT);

        SelectObject(
            dc,
            gTitleFont
        );

        SetTextColor(
            dc,
            COLOR_DARK_BLUE
        );

        const wchar_t* title =
            CurrentPageTitle();

        TextOutW(
            dc,
            260,
            61,
            title,
            static_cast<int>(
                wcslen(title)
            )
        );

        HPEN separatorPen =
            CreatePen(
                PS_SOLID,
                1,
                COLOR_BORDER
            );

        HGDIOBJ oldPen =
            SelectObject(
                dc,
                separatorPen
            );

        MoveToEx(
            dc,
            SIDEBAR_WIDTH,
            114,
            nullptr
        );

        LineTo(
            dc,
            client.right,
            114
        );

        SelectObject(
            dc,
            oldPen
        );

        DeleteObject(
            separatorPen
        );
    }

    // ========================================================================
    // Página Início
    // ========================================================================

    void DrawHomePage(
        HDC dc
    )
    {
        const bool running =
            IsDefenderRunning();

        const bool integrityOk =
            AllComponentsValid();

        const bool healthy =
            running &&
            integrityOk;

        const COLORREF statusColor =
            healthy
                ? COLOR_GREEN
                : COLOR_RED;

        RECT card
        {
            259,
            158,
            810,
            291
        };

        DrawOutlinedRectangle(
            dc,
            card,
            COLOR_BORDER,
            COLOR_WHITE
        );

        RECT accent
        {
            card.left,
            card.top,
            card.left + 10,
            card.bottom
        };

        HBRUSH accentBrush =
            CreateSolidBrush(
                statusColor
            );

        FillRect(
            dc,
            &accent,
            accentBrush
        );

        DeleteObject(
            accentBrush
        );

        DrawStatusIcon(
            dc,
            291,
            195,
            healthy
        );

        RECT headline
        {
            354,
            188,
            790,
            222
        };

        DrawTextBlock(
            dc,
            healthy
                ? UiText(L"A proteção está ativa", L"Protection is active", L"La protección está activa")
                : UiText(L"A proteção precisa de atenção", L"Protection needs attention", L"La protección necesita atención"),
            headline,
            gHeadlineFont,
            statusColor,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT description
        {
            354,
            225,
            780,
            270
        };

        DrawTextBlock(
            dc,
            healthy
                ? UiText(L"O Vistas Defender está protegendo este computador.", L"Vistas Defender is protecting this computer.", L"Vistas Defender está protegiendo este equipo.")
                : UiText(L"Confira a proteção e a integridade dos componentes.", L"Check protection and component integrity.", L"Compruebe la protección y la integridad de los componentes."),
            description,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_TOP |
            DT_WORDBREAK
        );

        RECT defenderLabel
        {
            259,
            320,
            430,
            346
        };

        DrawTextBlock(
            dc,
            L"Defender.exe",
            defenderLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT defenderState
        {
            448,
            320,
            650,
            346
        };

        DrawTextBlock(
            dc,
            running
                ? UiText(L"Executando", L"Running", L"En ejecución")
                : UiText(L"Parado", L"Stopped", L"Detenido"),
            defenderState,
            gBodyFont,
            running
                ? COLOR_GREEN
                : COLOR_RED,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT integrityLabel
        {
            259,
            358,
            430,
            384
        };

        DrawTextBlock(
            dc,
            UiText(L"Integridade", L"Integrity", L"Integridad"),
            integrityLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT integrityState
        {
            448,
            358,
            750,
            384
        };

        const wchar_t* integrityText =
            !gIntegrityChecked
                ? UiText(L"Não verificada", L"Not checked", L"No verificada")
                : integrityOk
                    ? UiText(L"Componentes íntegros", L"Components intact", L"Componentes íntegros")
                    : UiText(L"Problemas encontrados", L"Problems found", L"Problemas encontrados");

        DrawTextBlock(
            dc,
            integrityText,
            integrityState,
            gBodyFont,
            integrityOk
                ? COLOR_GREEN
                : COLOR_RED,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT versionLabel
        {
            259,
            396,
            430,
            422
        };

        DrawTextBlock(
            dc,
            UiText(L"Versão", L"Version", L"Versión"),
            versionLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT versionState
        {
            448,
            396,
            750,
            422
        };

        DrawTextBlock(
            dc,
            PRODUCT_VERSION,
            versionState,
            gBodyFont,
            COLOR_BLUE,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );
    }

    // ========================================================================
    // Página Proteção
    // ========================================================================

    void DrawProtectionPage(
        HDC dc
    )
    {
        const bool running =
            IsDefenderRunning();

        const COLORREF statusColor =
            running
                ? COLOR_GREEN
                : COLOR_RED;

        RECT card
        {
            259,
            156,
            810,
            287
        };

        DrawOutlinedRectangle(
            dc,
            card,
            COLOR_BORDER,
            COLOR_WHITE
        );

        RECT accent
        {
            card.left,
            card.top,
            card.left + 10,
            card.bottom
        };

        HBRUSH accentBrush =
            CreateSolidBrush(
                statusColor
            );

        FillRect(
            dc,
            &accent,
            accentBrush
        );

        DeleteObject(
            accentBrush
        );

        DrawStatusIcon(
            dc,
            291,
            194,
            running
        );

        RECT headline
        {
            355,
            188,
            790,
            220
        };

        DrawTextBlock(
            dc,
            running
                ? UiText(L"Proteção em tempo real ativada", L"Real-time protection enabled", L"Protección en tiempo real activada")
                : UiText(L"Proteção em tempo real desativada", L"Real-time protection disabled", L"Protección en tiempo real desactivada"),
            headline,
            gHeadlineFont,
            statusColor,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT description
        {
            355,
            224,
            775,
            267
        };

        DrawTextBlock(
            dc,
            running
                ? UiText(L"O Defender.exe está monitorando novos programas e alterações.", L"Defender.exe is monitoring new programs and changes.", L"Defender.exe está supervisando programas y cambios nuevos.")
                : UiText(L"Ative a proteção para iniciar o motor de segurança.", L"Enable protection to start the security engine.", L"Active la protección para iniciar el motor de seguridad."),
            description,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_TOP |
            DT_WORDBREAK
        );

        RECT verification
        {
            259,
            306,
            530,
            332
        };

        DrawTextBlock(
            dc,
            UiText(L"Verificação antes da execução:", L"Pre-execution verification:", L"Verificación antes de ejecutar:"),
            verification,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT verificationState
        {
            510,
            306,
            810,
            332
        };

        DrawTextBlock(
            dc,
            AllComponentsValid()
                ? L"OArthurMamaco Security SHA-256"
                : UiText(L"Falha de integridade", L"Integrity failure", L"Error de integridad"),
            verificationState,
            gBodyFont,
            AllComponentsValid()
                ? COLOR_GREEN
                : COLOR_RED,
            DT_RIGHT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT scanStatusRect{ 260, 526, 810, 581 };
        std::wstring scanLine = std::wstring(UiText(L"Última verificação: ", L"Last scan: ", L"Último análisis: ")) +
            (gScanInProgress ? UiText(L"em andamento...", L"running...", L"en curso...") : gScanStatus);
        if (!gScanTarget.empty()) scanLine += L"\r\n" + gScanTarget;
        DrawTextBlock(dc, scanLine.c_str(), scanStatusRect, gTinyFont,
            gScanInProgress ? COLOR_BLUE : COLOR_MUTED, DT_LEFT | DT_TOP | DT_WORDBREAK | DT_END_ELLIPSIS);
    }

    // ========================================================================
    // Página Configurações
    // ========================================================================

    void DrawSettingsPage(HDC dc)
    {
        RECT intro{ 260, 142, 805, 180 };
        DrawTextBlock(dc,
            UiText(L"Configure idioma, verificações agendadas e nível de intervenção.",
                   L"Configure language, scheduled scans and the intervention level.",
                   L"Configure idioma, análisis programados y nivel de intervención."),
            intro, gBodyFont, COLOR_TEXT, DT_LEFT | DT_WORDBREAK);

        RECT languageLabel{ 260, 196, 465, 236 };
        DrawTextBlock(dc, UiText(L"Idioma da interface", L"Interface language", L"Idioma de interfaz"),
            languageLabel, gBodyFont, COLOR_TEXT, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        RECT startupLabel{ 260, 252, 465, 292 };
        DrawTextBlock(dc, UiText(L"Verificação completa ao iniciar", L"Full scan at startup", L"Análisis completo al iniciar"),
            startupLabel, gBodyFont, COLOR_TEXT, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        RECT modeLabel{ 260, 308, 465, 348 };
        DrawTextBlock(dc, UiText(L"Tratamento de apps desconhecidos", L"Unknown-app handling", L"Tratamiento de apps desconocidas"),
            modeLabel, gBodyFont, COLOR_TEXT, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        RECT daysLabel{ 260, 390, 805, 420 };
        DrawTextBlock(dc, UiText(L"Dias da verificação semanal (03:00)", L"Weekly scan days (03:00)", L"Días del análisis semanal (03:00)"),
            daysLabel, gBodyFont, COLOR_TEXT, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

        RECT modeHelp{ 260, 357, 810, 385 };
        DrawTextBlock(dc,
            UiText(L"Observação: não bloqueia apenas por evidência ambígua. Equilibrado: decisão para apps desconhecidos. Rigoroso: pode pedir decisão para quase todos os processos não protegidos.",
                   L"Monitor: does not block solely on ambiguous evidence. Balanced: prompts for unknown apps. Strict: may prompt for nearly every non-protected process.",
                   L"Supervisión: no bloquea solo por evidencia ambigua. Equilibrado: consulta para apps desconocidas. Estricto: puede preguntar por casi todos los procesos no protegidos."),
            modeHelp, gTinyFont, COLOR_MUTED, DT_LEFT | DT_WORDBREAK);

        RECT scheduleStatus{ 260, 480, 810, 506 };
        std::wstring scheduleLine = std::wstring(UiText(L"Agendamento: ", L"Schedule: ", L"Programación: ")) + gScheduleStatus;
        DrawTextBlock(dc, scheduleLine.c_str(), scheduleStatus, gSmallFont,
            (gScheduleStatus.find(L"falha") != std::wstring::npos || gScheduleStatus.find(L"failed") != std::wstring::npos || gScheduleStatus.find(L"falló") != std::wstring::npos)
                ? COLOR_RED : COLOR_MUTED,
            DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

        RECT warning{ 260, 515, 810, 583 };
        DrawTextBlock(dc,
            UiText(L"As análises do Microsoft Defender podem colocar ameaças em quarentena. Rigoroso pode pedir decisão para muitos aplicativos. A varredura semanal e ao iniciar só são registradas quando ativadas aqui.",
                   L"Microsoft Defender scans may quarantine detections. Strict mode may prompt for many applications. Weekly/startup scans are registered only when enabled here.",
                   L"Los análisis de Microsoft Defender pueden poner amenazas en cuarentena. El modo estricto puede preguntar por muchas aplicaciones. Los análisis semanales/al iniciar solo se registran cuando se activan aquí."),
            warning, gTinyFont, COLOR_MUTED, DT_LEFT | DT_WORDBREAK);

        RECT htlkInfo{ 260, 584, 810, 596 };
        DrawTextBlock(dc, gHtlkBuildInfo.c_str(), htlkInfo, gTinyFont, COLOR_MUTED,
            DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        RECT htlkCaps{ 260, 597, 810, 609 };
        DrawTextBlock(dc, gHtlkCapabilities.c_str(), htlkCaps, gTinyFont, COLOR_MUTED,
            DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }

    // ========================================================================
    // Página Integridade
    // ========================================================================

    void DrawIntegrityPage(
        HDC dc
    )
    {
        const bool allValid =
            AllComponentsValid();

        RECT headingRect
        {
            260,
            150,
            820,
            190
        };

        const wchar_t* heading =
            allValid
                ? UiText(L"Todos os componentes estão íntegros", L"All components are intact", L"Todos los componentes están íntegros")
                : UiText(L"Um ou mais componentes apresentaram problema", L"One or more components have a problem", L"Uno o más componentes presentan problemas");

        DrawTextBlock(
            dc,
            heading,
            headingRect,
            gHeadlineFont,
            allValid
                ? COLOR_GREEN
                : COLOR_RED,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE |
            DT_END_ELLIPSIS
        );

        int y = 200;

        for (const auto& component :
             gIntegrityResults)
        {
            const bool valid =
                component.signature.IsValid();

            RECT row
            {
                260,
                y,
                810,
                y + 38
            };

            DrawOutlinedRectangle(
                dc,
                row,
                valid
                    ? RGB(180, 220, 191)
                    : RGB(237, 183, 183),
                valid
                    ? COLOR_LIGHT_GREEN
                    : COLOR_LIGHT_RED
            );

            RECT nameRect
            {
                row.left + 14,
                row.top + 7,
                row.left + 170,
                row.bottom - 4
            };

            DrawTextBlock(
                dc,
                component.fileName.c_str(),
                nameRect,
                gBodyFont,
                COLOR_TEXT,
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE
            );

            RECT statusRect
            {
                row.left + 171,
                row.top + 7,
                row.right - 12,
                row.bottom - 4
            };

            DrawTextBlock(
                dc,
                component.signature.message.c_str(),
                statusRect,
                gSmallFont,
                valid
                    ? COLOR_GREEN
                    : COLOR_RED,
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE |
                DT_END_ELLIPSIS
            );

            y += 46;
        }
    }

    // ========================================================================
    // Página Atualizações
    // ========================================================================

    void DrawUpdatesPage(
        HDC dc
    )
    {
        const bool checked =
            gUpdateResult.checked;

        const bool valid =
            checked &&
            gUpdateResult.packageValid;

        RECT statusCard
        {
            260,
            155,
            810,
            284
        };

        DrawOutlinedRectangle(
            dc,
            statusCard,
            COLOR_BORDER,
            COLOR_WHITE
        );

        RECT accent
        {
            statusCard.left,
            statusCard.top,
            statusCard.left + 10,
            statusCard.bottom
        };

        const COLORREF statusColor =
            !checked
                ? COLOR_BLUE
                : valid
                    ? COLOR_GREEN
                    : COLOR_RED;

        HBRUSH accentBrush =
            CreateSolidBrush(
                statusColor
            );

        FillRect(
            dc,
            &accent,
            accentBrush
        );

        DeleteObject(
            accentBrush
        );

        DrawStatusIcon(
            dc,
            292,
            193,
            checked
                ? valid
                : true
        );

        RECT headline
        {
            355,
            181,
            790,
            217
        };

        const wchar_t* updateTitle =
            !checked
                ? UiText(L"Verifique os componentes locais do Vistas Defender", L"Check local Vistas Defender components", L"Compruebe los componentes locales de Vistas Defender")
                : valid
                    ? UiText(L"Componentes locais íntegros", L"Local components are intact", L"Los componentes locales están íntegros")
                    : UiText(L"O pacote precisa de manutenção", L"The package needs maintenance", L"El paquete necesita mantenimiento");

        DrawTextBlock(
            dc,
            updateTitle,
            headline,
            gHeadlineFont,
            statusColor,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE |
            DT_END_ELLIPSIS
        );

        RECT description
        {
            355,
            220,
            780,
            267
        };

        const wchar_t* updateDescription =
            !checked
                ? UiText(L"A verificação confere se os componentes locais estão presentes e assinados. Não consulta automaticamente a versão remota.", L"This check verifies local component presence and signatures. It does not automatically query the remote version.", L"Esta comprobación verifica la presencia y las firmas locales. No consulta automáticamente la versión remota.")
                : valid
                    ? UiText(L"Os componentes locais passaram na verificação. A versão remota não foi comparada automaticamente; consulte o repositório.", L"Local components passed integrity checks. The remote version was not compared automatically; check the repository.", L"Los componentes locales pasaron la comprobación de integridad. La versión remota no se comparó automáticamente; consulte el repositorio.")
                    : UiText(L"Há componentes locais ausentes, sem assinatura válida ou modificados. A versão remota não foi comparada automaticamente.", L"Some local components are missing, unsigned, or modified. The remote version was not compared automatically.", L"Faltan componentes locales, no tienen firma válida o fueron modificados. La versión remota no se comparó automáticamente.");

        DrawTextBlock(
            dc,
            updateDescription,
            description,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_TOP |
            DT_WORDBREAK
        );

        RECT detailsCard
        {
            260,
            306,
            810,
            405
        };

        DrawOutlinedRectangle(
            dc,
            detailsCard,
            COLOR_BORDER,
            COLOR_LIGHT_BLUE
        );

        RECT versionLabel
        {
            278,
            318,
            470,
            342
        };

        DrawTextBlock(
            dc,
            UiText(L"Versão instalada", L"Installed version", L"Versión instalada"),
            versionLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT versionValue
        {
            590,
            318,
            792,
            342
        };

        DrawTextBlock(
            dc,
            PRODUCT_VERSION,
            versionValue,
            gBodyFont,
            COLOR_BLUE,
            DT_RIGHT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT channelLabel
        {
            278,
            346,
            470,
            370
        };

        DrawTextBlock(
            dc,
            UiText(L"Canal de atualização", L"Update channel", L"Canal de actualización"),
            channelLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT channelValue
        {
            590,
            346,
            792,
            370
        };

        DrawTextBlock(
            dc,
            UiText(L"Canal estável • Contenção adaptativa", L"Stable channel • Adaptive containment", L"Canal estable • Contención adaptativa"),
            channelValue,
            gBodyFont,
            COLOR_BLUE,
            DT_RIGHT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT componentsLabel
        {
            278,
            374,
            470,
            398
        };

        DrawTextBlock(
            dc,
            UiText(L"Componentes válidos", L"Valid components", L"Componentes válidos"),
            componentsLabel,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        std::wstring componentValue =
            checked
                ? std::to_wstring(
                      gUpdateResult.validComponents
                  ) +
                  UiText(L" de ", L" of ", L" de ") +
                  std::to_wstring(
                      gUpdateResult.totalComponents
                  )
                : UiText(L"Não verificado", L"Not checked", L"No verificado");

        RECT componentsValue
        {
            540,
            374,
            792,
            398
        };

        DrawTextBlock(
            dc,
            componentValue.c_str(),
            componentsValue,
            gBodyFont,
            checked
                ? valid
                    ? COLOR_GREEN
                    : COLOR_RED
                : COLOR_MUTED,
            DT_RIGHT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        if (checked)
        {
            std::wstring lastCheck =
                std::wstring(UiText(L"Última verificação: ", L"Last check: ", L"Última comprobación: ")) +
                gUpdateResult.checkedAt;

            RECT lastCheckRect
            {
                260,
                410,
                810,
                432
            };

            DrawTextBlock(
                dc,
                lastCheck.c_str(),
                lastCheckRect,
                gSmallFont,
                COLOR_MUTED,
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE
            );
        }
    }

    // ========================================================================
    // Página Eventos
    // ========================================================================

    COLORREF EventCategoryColor(
        const std::wstring& category
    )
    {
        if (category == L"Erro")
            return COLOR_RED;

        if (category == L"Proteção")
            return COLOR_BLUE;

        if (category == L"Integridade")
            return COLOR_GREEN;

        if (category == L"Atualizações")
            return COLOR_ORANGE;

        return COLOR_MUTED;
    }

    void DrawEventsPage(
        HDC dc
    )
    {
        RECT description
        {
            260,
            145,
            810,
            175
        };

        DrawTextBlock(
            dc,
            UiText(L"Atividades recentes do painel e do motor de proteção.", L"Recent activity from the UI and protection engine.", L"Actividad reciente de la interfaz y el motor de protección."),
            description,
            gBodyFont,
            COLOR_TEXT,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT header
        {
            260,
            181,
            810,
            214
        };

        DrawOutlinedRectangle(
            dc,
            header,
            COLOR_BORDER,
            RGB(237, 245, 252)
        );

        RECT timeHeader
        {
            272,
            187,
            422,
            209
        };

        DrawTextBlock(
            dc,
            UiText(L"Data e hora", L"Date and time", L"Fecha y hora"),
            timeHeader,
            gSmallFont,
            COLOR_DARK_BLUE,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT categoryHeader
        {
            425,
            187,
            535,
            209
        };

        DrawTextBlock(
            dc,
            UiText(L"Categoria", L"Category", L"Categoría"),
            categoryHeader,
            gSmallFont,
            COLOR_DARK_BLUE,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        RECT messageHeader
        {
            540,
            187,
            798,
            209
        };

        DrawTextBlock(
            dc,
            UiText(L"Descrição", L"Description", L"Descripción"),
            messageHeader,
            gSmallFont,
            COLOR_DARK_BLUE,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE
        );

        if (gEvents.empty())
        {
            RECT emptyCard
            {
                260,
                222,
                810,
                285
            };

            DrawOutlinedRectangle(
                dc,
                emptyCard,
                COLOR_BORDER,
                COLOR_WHITE
            );

            RECT emptyText
            {
                278,
                236,
                792,
                270
            };

            DrawTextBlock(
                dc,
                UiText(L"Nenhum evento foi registrado.", L"No events have been recorded.", L"No se han registrado eventos."),
                emptyText,
                gBodyFont,
                COLOR_MUTED,
                DT_CENTER |
                DT_VCENTER |
                DT_SINGLELINE
            );

            return;
        }

        constexpr int maximumVisibleEvents = 7;

        const int totalEvents =
            static_cast<int>(
                gEvents.size()
            );

        const int firstEvent =
            totalEvents > maximumVisibleEvents
                ? totalEvents - maximumVisibleEvents
                : 0;

        int y = 220;

        for (int index = totalEvents - 1;
             index >= firstEvent;
             --index)
        {
            const EventRecord& event =
                gEvents[
                    static_cast<size_t>(index)
                ];

            RECT row
            {
                260,
                y,
                810,
                y + 39
            };

            DrawOutlinedRectangle(
                dc,
                row,
                COLOR_BORDER,
                index % 2 == 0
                    ? COLOR_WHITE
                    : COLOR_LIGHT_BLUE
            );

            RECT timeRect
            {
                272,
                row.top + 6,
                420,
                row.bottom - 5
            };

            DrawTextBlock(
                dc,
                event.time.c_str(),
                timeRect,
                gTinyFont,
                COLOR_MUTED,
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE |
                DT_END_ELLIPSIS
            );

            RECT categoryRect
            {
                425,
                row.top + 6,
                535,
                row.bottom - 5
            };

            DrawTextBlock(
                dc,
                event.category.c_str(),
                categoryRect,
                gTinyFont,
                EventCategoryColor(
                    event.category
                ),
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE |
                DT_END_ELLIPSIS
            );

            RECT messageRect
            {
                540,
                row.top + 6,
                798,
                row.bottom - 5
            };

            DrawTextBlock(
                dc,
                event.message.c_str(),
                messageRect,
                gTinyFont,
                COLOR_TEXT,
                DT_LEFT |
                DT_VCENTER |
                DT_SINGLELINE |
                DT_END_ELLIPSIS
            );

            y += 41;
        }
    }

    // ========================================================================
    // Owner draw
    // ========================================================================

    LRESULT DrawNavigationButton(
        const DRAWITEMSTRUCT* item
    )
    {
        const bool active =
            IsCurrentPage(
                static_cast<int>(
                    item->CtlID
                )
            );

        HBRUSH background =
            CreateSolidBrush(
                active
                    ? COLOR_ACTIVE
                    : COLOR_SIDEBAR
            );

        FillRect(
            item->hDC,
            &item->rcItem,
            background
        );

        DeleteObject(background);

        if (active)
        {
            RECT accent =
                item->rcItem;

            accent.right =
                accent.left + 5;

            HBRUSH accentBrush =
                CreateSolidBrush(
                    COLOR_BLUE
                );

            FillRect(
                item->hDC,
                &accent,
                accentBrush
            );

            DeleteObject(
                accentBrush
            );
        }

        wchar_t text[128]{};

        GetWindowTextW(
            item->hwndItem,
            text,
            static_cast<int>(
                _countof(text)
            )
        );

        SetBkMode(
            item->hDC,
            TRANSPARENT
        );

        SetTextColor(
            item->hDC,
            active
                ? COLOR_BLUE
                : COLOR_TEXT
        );

        SelectObject(
            item->hDC,
            gMenuFont
        );

        RECT textRect =
            item->rcItem;

        textRect.left += 30;

        DrawTextW(
            item->hDC,
            text,
            -1,
            &textRect,
            DT_LEFT |
            DT_VCENTER |
            DT_SINGLELINE |
            DT_NOPREFIX
        );

        return TRUE;
    }

    LRESULT DrawActionButton(
        const DRAWITEMSTRUCT* item
    )
    {
        const bool pressed =
            (item->itemState &
             ODS_SELECTED) != 0;

        const bool disabled =
            (item->itemState &
             ODS_DISABLED) != 0;

        COLORREF backgroundColor =
            COLOR_BLUE;

        COLORREF borderColor =
            COLOR_DARK_BLUE;

        if (pressed)
            backgroundColor =
                COLOR_BLUE_PRESSED;

        if (disabled)
        {
            backgroundColor =
                COLOR_DISABLED;

            borderColor =
                COLOR_DISABLED_BORDER;
        }

        HBRUSH background =
            CreateSolidBrush(
                backgroundColor
            );

        FillRect(
            item->hDC,
            &item->rcItem,
            background
        );

        DeleteObject(background);

        HPEN border =
            CreatePen(
                PS_SOLID,
                1,
                borderColor
            );

        HGDIOBJ oldPen =
            SelectObject(
                item->hDC,
                border
            );

        HGDIOBJ oldBrush =
            SelectObject(
                item->hDC,
                GetStockObject(NULL_BRUSH)
            );

        Rectangle(
            item->hDC,
            item->rcItem.left,
            item->rcItem.top,
            item->rcItem.right,
            item->rcItem.bottom
        );

        SelectObject(
            item->hDC,
            oldBrush
        );

        SelectObject(
            item->hDC,
            oldPen
        );

        DeleteObject(border);

        wchar_t text[128]{};

        GetWindowTextW(
            item->hwndItem,
            text,
            static_cast<int>(
                _countof(text)
            )
        );

        SetBkMode(
            item->hDC,
            TRANSPARENT
        );

        SetTextColor(
            item->hDC,
            COLOR_WHITE
        );

        SelectObject(
            item->hDC,
            gButtonFont
        );

        RECT textRect =
            item->rcItem;

        DrawTextW(
            item->hDC,
            text,
            -1,
            &textRect,
            DT_CENTER |
            DT_VCENTER |
            DT_SINGLELINE |
            DT_NOPREFIX
        );

        return TRUE;
    }

    LRESULT DrawOwnerButton(
        const DRAWITEMSTRUCT* item
    )
    {
        if (!item)
            return FALSE;

        if (item->CtlID >= ID_HOME &&
            item->CtlID <= ID_SETTINGS)
        {
            return DrawNavigationButton(
                item
            );
        }

        switch (item->CtlID)
        {
        case ID_HOME_ACTION:
        case ID_PROTECTION_ENABLE:
        case ID_PROTECTION_DISABLE:
        case ID_INTEGRITY_CHECK:
        case ID_UPDATES_CHECK:
        case ID_EVENTS_REFRESH:
        case ID_EVENTS_CLEAR:
        case ID_SCAN_DISK:
        case ID_SETTINGS_LANGUAGE:
        case ID_SETTINGS_STARTUP:
        case ID_SETTINGS_MODE:
            return DrawActionButton(item);

        default:
            if (item->CtlID >= ID_SETTINGS_DAY_BASE && item->CtlID < ID_SETTINGS_DAY_BASE + 7)
                return DrawActionButton(item);
            return FALSE;
        }
    }

    // ========================================================================
    // HTLK, varredura e tarefas agendadas
    // ========================================================================

    bool EnsureHtlkLoaded()
    {
        if (gHtlkModule && gHtlkInitialize && gHtlkScanPath && gHtlkGetScannerPath &&
            gHtlkGetAbiVersion && gHtlkGetProductVersion && gHtlkGetBuildInfo &&
            gHtlkGetCapabilities && gHtlkCancel)
            return true;
        const fs::path dllPath = ApplicationDirectory() / L"htlk.dll";
        const SignatureResult signature = InspectSignature(dllPath);
        if (!signature.IsValid()) {
            gScanStatus = UiText(L"HTLK recusada: assinatura/integridade inválida.",
                                 L"HTLK rejected: invalid signature/integrity.",
                                 L"HTLK rechazada: firma/integridad inválida.");
            return false;
        }
        gHtlkModule = LoadLibraryExW(dllPath.c_str(), nullptr,
            LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
        if (!gHtlkModule) {
            gScanStatus = UiText(L"Não foi possível carregar a HTLK.",
                                 L"Could not load HTLK.", L"No se pudo cargar HTLK.");
            return false;
        }
        gHtlkInitialize = reinterpret_cast<HtlkInitializeFn>(GetProcAddress(gHtlkModule, "Htlk_Initialize"));
        gHtlkScanPath = reinterpret_cast<HtlkScanPathFn>(GetProcAddress(gHtlkModule, "Htlk_ScanPathW"));
        gHtlkGetScannerPath = reinterpret_cast<HtlkGetScannerPathFn>(GetProcAddress(gHtlkModule, "Htlk_GetMpCmdRunPathW"));
        gHtlkGetAbiVersion = reinterpret_cast<HtlkGetVersionFn>(GetProcAddress(gHtlkModule, "Htlk_GetVersion"));
        gHtlkGetProductVersion = reinterpret_cast<HtlkGetTextFn>(GetProcAddress(gHtlkModule, "Htlk_GetProductVersionW"));
        gHtlkGetBuildInfo = reinterpret_cast<HtlkGetTextFn>(GetProcAddress(gHtlkModule, "Htlk_GetBuildInfoW"));
        gHtlkGetCapabilities = reinterpret_cast<HtlkGetTextFn>(GetProcAddress(gHtlkModule, "Htlk_GetCapabilitiesW"));
        gHtlkCancel = reinterpret_cast<HtlkCancelFn>(GetProcAddress(gHtlkModule, "Htlk_CancelScan"));
        wchar_t productVersion[32]{};
        wchar_t buildInfo[256]{};
        wchar_t capabilities[512]{};
        if (!gHtlkInitialize || !gHtlkScanPath || !gHtlkGetScannerPath ||
            !gHtlkGetAbiVersion || !gHtlkGetProductVersion || !gHtlkGetBuildInfo ||
            !gHtlkGetCapabilities || !gHtlkCancel || gHtlkGetAbiVersion() != 1 ||
            !gHtlkGetProductVersion(productVersion, _countof(productVersion)) ||
            _wcsicmp(productVersion, PRODUCT_VERSION) != 0) {
            gScanStatus = UiText(L"A HTLK não expõe a API esperada ou pertence a outra versão.",
                                 L"HTLK API mismatch or product version mismatch.",
                                 L"API HTLK incompatible o versión de producto distinta.");
            FreeLibrary(gHtlkModule);
            gHtlkModule = nullptr;
            gHtlkInitialize = nullptr; gHtlkScanPath = nullptr; gHtlkGetScannerPath = nullptr;
            gHtlkGetAbiVersion = nullptr; gHtlkGetProductVersion = nullptr;
            gHtlkGetBuildInfo = nullptr; gHtlkGetCapabilities = nullptr; gHtlkCancel = nullptr;
            return false;
        }
        if (gHtlkGetBuildInfo(buildInfo, _countof(buildInfo))) gHtlkBuildInfo = buildInfo;
        if (gHtlkGetCapabilities(capabilities, _countof(capabilities))) gHtlkCapabilities = capabilities;
        return true;
    }

    std::wstring QuoteWindowsArgument(const std::wstring& value)
    {
        std::wstring out = L"\"";
        size_t slashes = 0;
        for (wchar_t c : value) {
            if (c == L'\\') { ++slashes; continue; }
            if (c == L'\"') {
                out.append(slashes * 2 + 1, L'\\');
                out.push_back(c);
                slashes = 0;
                continue;
            }
            out.append(slashes, L'\\');
            slashes = 0;
            out.push_back(c);
        }
        out.append(slashes * 2, L'\\');
        out.push_back(L'\"');
        return out;
    }

    bool RunTaskScheduler(const std::wstring& arguments, DWORD& exitCode)
    {
        wchar_t systemDirectory[MAX_PATH]{};
        const UINT length = GetSystemDirectoryW(systemDirectory, MAX_PATH);
        if (!length || length >= MAX_PATH) return false;
        const fs::path schtasks = fs::path(systemDirectory) / L"schtasks.exe";
        std::wstring commandLine = QuoteWindowsArgument(schtasks.wstring()) + L" " + arguments;
        std::vector<wchar_t> mutableCommand(commandLine.begin(), commandLine.end());
        mutableCommand.push_back(L'\0');
        STARTUPINFOW startup{}; startup.cb = sizeof(startup); startup.dwFlags = STARTF_USESHOWWINDOW; startup.wShowWindow = SW_HIDE;
        PROCESS_INFORMATION process{};
        if (!CreateProcessW(schtasks.c_str(), mutableCommand.data(), nullptr, nullptr, FALSE,
                CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process))
            return false;
        CloseHandle(process.hThread);
        const DWORD wait = WaitForSingleObject(process.hProcess, 30000);
        if (wait == WAIT_TIMEOUT) {
            TerminateProcess(process.hProcess, ERROR_TIMEOUT);
            WaitForSingleObject(process.hProcess, 2000);
            CloseHandle(process.hProcess);
            SetLastError(ERROR_TIMEOUT);
            return false;
        }
        const BOOL gotExit = GetExitCodeProcess(process.hProcess, &exitCode);
        CloseHandle(process.hProcess);
        return gotExit && wait == WAIT_OBJECT_0 && exitCode == 0;
    }

    bool DeleteScheduledTask(const wchar_t* taskName)
    {
        // Use the Task Scheduler COM API so "task absent" can be distinguished from
        // "task exists but deletion failed" without parsing localized schtasks output.
        const HRESULT apartment = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const bool uninitialize = SUCCEEDED(apartment);
        if (FAILED(apartment) && apartment != RPC_E_CHANGED_MODE) {
            SetLastError(HRESULT_CODE(apartment));
            return false;
        }

        const HRESULT security = CoInitializeSecurity(nullptr, -1, nullptr, nullptr,
            RPC_C_AUTHN_LEVEL_PKT_PRIVACY, RPC_C_IMP_LEVEL_IMPERSONATE,
            nullptr, EOAC_NONE, nullptr);
        if (FAILED(security) && security != RPC_E_TOO_LATE) {
            if (uninitialize) CoUninitialize();
            SetLastError(HRESULT_CODE(security));
            return false;
        }

        ITaskService* service = nullptr;
        HRESULT hr = CoCreateInstance(CLSID_TaskScheduler, nullptr, CLSCTX_INPROC_SERVER,
            IID_ITaskService, reinterpret_cast<void**>(&service));
        if (FAILED(hr) || !service) {
            if (uninitialize) CoUninitialize();
            SetLastError(HRESULT_CODE(hr));
            return false;
        }

        VARIANT empty; VariantInit(&empty);
        hr = service->Connect(empty, empty, empty, empty);
        ITaskFolder* root = nullptr;
        BSTR rootName = SysAllocString(L"\\");
        if (SUCCEEDED(hr) && rootName) hr = service->GetFolder(rootName, &root);
        else if (SUCCEEDED(hr)) hr = E_OUTOFMEMORY;
        if (rootName) SysFreeString(rootName);

        IRegisteredTask* task = nullptr;
        BSTR taskBstr = SysAllocString(taskName ? taskName : L"");
        if (SUCCEEDED(hr) && taskBstr) hr = root->GetTask(taskBstr, &task);
        else if (SUCCEEDED(hr)) hr = E_OUTOFMEMORY;

        bool success = false;
        if (hr == HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND)) {
            success = true; // already absent
        } else if (SUCCEEDED(hr) && task) {
            task->Release(); task = nullptr;
            hr = root->DeleteTask(taskBstr, 0);
            success = SUCCEEDED(hr);
        }

        if (task) task->Release();
        if (root) root->Release();
        if (taskBstr) SysFreeString(taskBstr);
        service->Release();
        if (uninitialize) CoUninitialize();
        if (!success) SetLastError(HRESULT_CODE(hr));
        return success;
    }

    bool ApplyScheduledTasks()
    {
        const bool needTasks = gSettings.scanAtStartup != 0 || gSettings.scanDays != 0;
        if (!needTasks) {
            const bool startupRemoved = DeleteScheduledTask(L"VistasDefender-StartupScan");
            const bool weeklyRemoved = DeleteScheduledTask(L"VistasDefender-WeeklyScan");
            if (!startupRemoved || !weeklyRemoved) {
                gScheduleStatus = UiText(L"falha ao confirmar remoção das tarefas agendadas",
                    L"failed to confirm scheduled-task removal",
                    L"no se pudo confirmar la eliminación de tareas programadas");
                return false;
            }
            gScheduleStatus = UiText(L"Desativado", L"Disabled", L"Desactivado");
            return true;
        }
        if (!EnsureHtlkLoaded()) {
            gScheduleStatus = UiText(L"falha: HTLK inválida/indisponível", L"failed: HTLK invalid/unavailable", L"fallo: HTLK inválida/no disponible");
            return false;
        }
        wchar_t scannerBuffer[MAX_PATH]{};
        if (!gHtlkGetScannerPath(scannerBuffer, _countof(scannerBuffer)) || !scannerBuffer[0]) {
            gScheduleStatus = UiText(L"falha: Microsoft Defender confiável não encontrado", L"failed: trusted Microsoft Defender not found", L"fallo: no se encontró Microsoft Defender confiable");
            return false;
        }
        const std::wstring action = QuoteWindowsArgument(scannerBuffer) + L" -Scan -ScanType 2";
        bool success = true;
        if (gSettings.scanAtStartup) {
            const std::wstring args = L"/Create /TN \"VistasDefender-StartupScan\" /TR " +
                QuoteWindowsArgument(action) + L" /SC ONSTART /DELAY 0005:00 /RU SYSTEM /RL HIGHEST /F";
            DWORD exitCode = 0;
            success = RunTaskScheduler(args, exitCode) && success;
        } else {
            success = DeleteScheduledTask(L"VistasDefender-StartupScan") && success;
        }

        if (gSettings.scanDays) {
            static const wchar_t* names[7] = { L"MON", L"TUE", L"WED", L"THU", L"FRI", L"SAT", L"SUN" };
            std::wstring days;
            for (int i = 0; i < 7; ++i) {
                if (!(gSettings.scanDays & (1u << i))) continue;
                if (!days.empty()) days += L",";
                days += names[i];
            }
            const std::wstring args = L"/Create /TN \"VistasDefender-WeeklyScan\" /TR " +
                QuoteWindowsArgument(action) + L" /SC WEEKLY /D " + days + L" /ST 03:00 /RU SYSTEM /RL HIGHEST /F";
            DWORD exitCode = 0;
            success = RunTaskScheduler(args, exitCode) && success;
        } else {
            success = DeleteScheduledTask(L"VistasDefender-WeeklyScan") && success;
        }
        if (success) {
            gScheduleStatus = UiText(L"aplicado (Defender, 03:00; ao iniciar conforme opção)",
                                     L"applied (Defender, 03:00; startup if enabled)",
                                     L"aplicado (Defender, 03:00; al iniciar si está activado)");
        } else {
            gScheduleStatus = UiText(L"falha ao registrar uma tarefa do Windows; confira permissões/política", 
                                     L"failed to register a Windows task; check permissions/policy",
                                     L"falló el registro de una tarea; revise permisos/política");
        }
        return success;
    }

    DWORD WINAPI DiskScanThreadProc(void* raw)
    {
        std::unique_ptr<ScanWorkItem> work(static_cast<ScanWorkItem*>(raw));
        work->result.cbSize = sizeof(HTLK_SCAN_RESULT);
        if (gHtlkInitialize && gHtlkInitialize())
            work->callReturned = gHtlkScanPath(work->target.c_str(), &work->result);
        else {
            work->result.status = HTLK_SCAN_FAILED;
            work->result.win32Error = GetLastError();
            wcsncpy_s(work->result.message, _countof(work->result.message),
                L"HTLK não pôde inicializar.", _TRUNCATE);
        }
        if (gWindowAlive.load(std::memory_order_acquire) &&
            PostMessageW(work->window, WM_SCAN_COMPLETE, 0, reinterpret_cast<LPARAM>(work.get())))
            work.release();
        return 0;
    }

    void StartDiskScan()
    {
        if (gScanInProgress) return;
        if (!EnsureHtlkLoaded()) {
            MessageBoxW(gMainWindow, gScanStatus.c_str(), L"Vistas Defender 27K6", MB_OK | MB_ICONERROR);
            RefreshInterface();
            return;
        }
        BROWSEINFOW browse{};
        browse.hwndOwner = gMainWindow;
        browse.lpszTitle = UiText(L"Selecione a raiz de um disco ou uma pasta para verificar", 
                                  L"Select a disk root or folder to scan",
                                  L"Seleccione la raíz del disco o carpeta para analizar");
        browse.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_EDITBOX;
        LPITEMIDLIST item = SHBrowseForFolderW(&browse);
        if (!item) return;
        wchar_t path[MAX_PATH]{};
        const BOOL gotPath = SHGetPathFromIDListW(item, path);
        CoTaskMemFree(item);
        if (!gotPath || !path[0]) {
            MessageBoxW(gMainWindow, UiText(L"O caminho selecionado não é uma pasta local válida.",
                L"The selected path is not a valid local folder.", L"La ruta seleccionada no es una carpeta local válida."),
                L"Vistas Defender", MB_OK | MB_ICONWARNING);
            return;
        }
        std::wstring question = std::wstring(UiText(L"Iniciar uma verificação do Microsoft Defender em:\r\n\r\n",
            L"Start a Microsoft Defender scan of:\r\n\r\n", L"¿Iniciar un análisis de Microsoft Defender de:\r\n\r\n")) + path +
            UiText(L"\r\n\r\nA verificação pode demorar e o Defender pode colocar itens detectados em quarentena. Continuar?",
                   L"\r\n\r\nScanning may take a long time and Defender may quarantine detections. Continue?",
                   L"\r\n\r\nEl análisis puede tardar y Defender puede poner detecciones en cuarentena. ¿Continuar?");
        if (MessageBoxW(gMainWindow, question.c_str(), L"Vistas Defender 27K6",
                MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) return;

        auto* work = new (std::nothrow) ScanWorkItem();
        if (!work) return;
        work->window = gMainWindow;
        work->target = path;
        gScanTarget = path;
        gScanStatus = UiText(L"Verificação iniciada; resultado ainda não disponível.",
                             L"Scan started; result not available yet.",
                             L"Análisis iniciado; resultado aún no disponible.");
        gScanInProgress = true;
        RefreshInterface();
        gScanThread = CreateThread(nullptr, 0, DiskScanThreadProc, work, 0, nullptr);
        if (!gScanThread) {
            delete work;
            gScanInProgress = false;
            gScanStatus = UiText(L"Falha ao criar thread de verificação.", L"Could not create scan thread.", L"No se pudo crear el hilo de análisis.");
            AddEvent(L"Verificação", gScanStatus);
            RefreshInterface();
        }
    }

    void HandleScanComplete(ScanWorkItem* raw)
    {
        std::unique_ptr<ScanWorkItem> work(raw);
        if (gScanThread) { CloseHandle(gScanThread); gScanThread = nullptr; }
        gScanInProgress = false;
        gScanStatus = work->result.message[0] ? work->result.message : UiText(L"Resultado indisponível.", L"Result unavailable.", L"Resultado no disponible.");
        AddEvent(L"Verificação de disco", gScanStatus + L" | " + work->target);
        if (work->result.status == HTLK_SCAN_COMPLETED) {
            MessageBoxW(gMainWindow, gScanStatus.c_str(), L"Vistas Defender 27K6", MB_OK | MB_ICONINFORMATION);
        } else {
            MessageBoxW(gMainWindow, gScanStatus.c_str(), L"Vistas Defender 27K6",
                MB_OK | (work->result.status == HTLK_SCAN_ATTENTION_REQUIRED ? MB_ICONWARNING : MB_ICONERROR));
        }
        RefreshInterface();
    }

    void HandleSettingsCommand(int controlId)
    {
        if (controlId == ID_SETTINGS_LANGUAGE) {
            gSettings.language = (gSettings.language + 1) % 3;
        } else if (controlId == ID_SETTINGS_STARTUP) {
            gSettings.scanAtStartup = gSettings.scanAtStartup ? 0 : 1;
        } else if (controlId == ID_SETTINGS_MODE) {
            gSettings.protectionMode = (gSettings.protectionMode + 1) % 3;
        } else if (controlId >= ID_SETTINGS_DAY_BASE && controlId < ID_SETTINGS_DAY_BASE + 7) {
            const DWORD bit = 1u << (controlId - ID_SETTINGS_DAY_BASE);
            gSettings.scanDays ^= bit;
        } else {
            return;
        }

        if (controlId == ID_SETTINGS_LANGUAGE)
            RefreshLocalizedControls();

        if (!SaveSettings()) {
            MessageBoxW(gMainWindow, UiText(L"Não foi possível salvar as configurações no Registro.",
                L"Could not save settings to the Registry.", L"No se pudieron guardar los ajustes en el Registro."),
                L"Vistas Defender", MB_OK | MB_ICONERROR);
            LoadSettings();
            RefreshLocalizedControls();
            RefreshInterface();
            return;
        }
        if (controlId == ID_SETTINGS_STARTUP ||
            (controlId >= ID_SETTINGS_DAY_BASE && controlId < ID_SETTINGS_DAY_BASE + 7)) {
            if (!ApplyScheduledTasks()) {
                MessageBoxW(gMainWindow, gScheduleStatus.c_str(), L"Vistas Defender 27K6", MB_OK | MB_ICONWARNING);
            }
        }
        AddEvent(L"Configurações", UiText(L"Preferências atualizadas.", L"Preferences updated.", L"Preferencias actualizadas."));
        RefreshInterface();
    }

    // ========================================================================
    // Ações
    // ========================================================================

    void ActivateProtection()
    {
        if (StartDefender())
            RefreshInterface();
        else
            RefreshInterface();
    }

    void DeactivateProtection()
    {
        const int answer = MessageBoxW(
            gMainWindow,
            L"Deseja realmente desativar a proteção em tempo real?",
            L"Vistas Defender",
            MB_YESNO |
            MB_ICONQUESTION |
            MB_DEFBUTTON2
        );

        if (answer != IDYES)
            return;

        StopDefender();
        RefreshInterface();
    }

    void ToggleProtectionFromHome()
    {
        if (IsDefenderRunning())
            DeactivateProtection();
        else
            ActivateProtection();
    }

    void VerifyIntegrityManually()
    {
        CheckAllComponents();

        if (AllComponentsValid())
        {
            AddEvent(
                L"Integridade",
                L"Todos os componentes foram validados com sucesso."
            );
        }
        else
        {
            AddEvent(
                L"Integridade",
                L"A verificação encontrou um ou mais componentes inválidos."
            );
        }

        RefreshInterface();
    }

    void RefreshEventsManually()
    {
        LoadEvents();
        RefreshInterface();
    }

    void ClearEventsManually()
    {
        const int answer = MessageBoxW(
            gMainWindow,
            L"Deseja apagar todo o histórico de eventos?",
            L"Vistas Defender",
            MB_YESNO |
            MB_ICONQUESTION |
            MB_DEFBUTTON2
        );

        if (answer != IDYES)
            return;

        ClearEvents();

        AddEvent(
            L"Sistema",
            L"O histórico de eventos foi limpo."
        );

        LoadEvents();
        RefreshInterface();
    }

    // ========================================================================
    // Window procedure
    // ========================================================================

    LRESULT CALLBACK WindowProcedure(
        HWND window,
        UINT message,
        WPARAM wParam,
        LPARAM lParam
    )
    {
        switch (message)
        {
        case WM_CREATE:
        {
            gMainWindow = window;
            gWindowAlive.store(true, std::memory_order_release);

            CreateControls(window);

            LoadEvents();

            AddEvent(
                L"Sistema",
                L"Painel Vistas Defender iniciado."
            );

            CheckAllComponents();
            // Query the signed HTLK build metadata at startup so Settings can report the actual DLL build.
            EnsureHtlkLoaded();
            // Reconcile old/missing task registrations even when the current settings disable scanning.
            ApplyScheduledTasks();

            RefreshInterface();

            SetTimer(
                window,
                TIMER_STATUS,
                1000,
                nullptr
            );

            return 0;
        }

        case WM_TIMER:
        {
            if (wParam == TIMER_STATUS)
                RefreshInterface();

            return 0;
        }

        case WM_SCAN_COMPLETE:
        {
            HandleScanComplete(reinterpret_cast<ScanWorkItem*>(lParam));
            return 0;
        }

        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
            case ID_HOME:
                SetCurrentPage(
                    Page::Home
                );
                break;

            case ID_PROTECTION:
                SetCurrentPage(
                    Page::Protection
                );
                break;

            case ID_INTEGRITY:
                SetCurrentPage(
                    Page::Integrity
                );
                break;

            case ID_UPDATES:
                SetCurrentPage(
                    Page::Updates
                );
                break;

            case ID_EVENTS:
                SetCurrentPage(Page::Events);
                break;

            case ID_SETTINGS:
                SetCurrentPage(Page::Settings);
                break;

            case ID_HOME_ACTION:
                ToggleProtectionFromHome();
                break;

            case ID_PROTECTION_ENABLE:
                ActivateProtection();
                break;

            case ID_PROTECTION_DISABLE:
                DeactivateProtection();
                break;

            case ID_INTEGRITY_CHECK:
                VerifyIntegrityManually();
                break;

            case ID_UPDATES_CHECK:
                CheckUpdates();
                OpenRepositoryPage();
                RefreshInterface();
                break;

            case ID_EVENTS_REFRESH:
                RefreshEventsManually();
                break;

            case ID_EVENTS_CLEAR:
                ClearEventsManually();
                break;

            case ID_SCAN_DISK:
                StartDiskScan();
                break;

            case ID_SETTINGS_LANGUAGE:
            case ID_SETTINGS_STARTUP:
            case ID_SETTINGS_MODE:
                HandleSettingsCommand(LOWORD(wParam));
                break;

            default:
                if (LOWORD(wParam) >= ID_SETTINGS_DAY_BASE && LOWORD(wParam) < ID_SETTINGS_DAY_BASE + 7)
                    HandleSettingsCommand(LOWORD(wParam));
                break;
            }

            return 0;
        }

        case WM_DRAWITEM:
        {
            return DrawOwnerButton(
                reinterpret_cast<
                    const DRAWITEMSTRUCT*
                >(lParam)
            );
        }

        case WM_PAINT:
        {
            PAINTSTRUCT paint{};

            HDC dc = BeginPaint(
                window,
                &paint
            );

            RECT client{};
            GetClientRect(
                window,
                &client
            );

            FillRect(
                dc,
                &client,
                gWhiteBrush
            );

            DrawSidebar(
                dc,
                client
            );

            DrawHeader(
                dc,
                client
            );

            switch (gCurrentPage)
            {
            case Page::Home:
                DrawHomePage(dc);
                break;

            case Page::Protection:
                DrawProtectionPage(dc);
                break;

            case Page::Integrity:
                DrawIntegrityPage(dc);
                break;

            case Page::Updates:
                DrawUpdatesPage(dc);
                break;

            case Page::Events:
                DrawEventsPage(dc);
                break;

            case Page::Settings:
                DrawSettingsPage(dc);
                break;
            }

            EndPaint(
                window,
                &paint
            );

            return 0;
        }

        case WM_CLOSE:
        {
            AddEvent(
                L"Sistema",
                L"Painel Vistas Defender encerrado."
            );

            DestroyWindow(window);

            return 0;
        }

        case WM_DESTROY:
        {
            gWindowAlive.store(false, std::memory_order_release);
            if (gHtlkCancel) gHtlkCancel();
            if (gScanThread) { CloseHandle(gScanThread); gScanThread = nullptr; }
            KillTimer(window, TIMER_STATUS);

            PostQuitMessage(0);

            return 0;
        }
        }

        return DefWindowProcW(
            window,
            message,
            wParam,
            lParam
        );
    }

    // ========================================================================
    // Ajuste do tamanho da janela
    // ========================================================================

    void AdjustWindowForClientSize(
        DWORD style,
        DWORD extendedStyle,
        int clientWidth,
        int clientHeight,
        int& windowWidth,
        int& windowHeight
    )
    {
        RECT rectangle
        {
            0,
            0,
            clientWidth,
            clientHeight
        };

        AdjustWindowRectEx(
            &rectangle,
            style,
            FALSE,
            extendedStyle
        );

        windowWidth =
            rectangle.right -
            rectangle.left;

        windowHeight =
            rectangle.bottom -
            rectangle.top;
    }
}

// ============================================================================
// Entrada principal
// ============================================================================

int WINAPI wWinMain(
    HINSTANCE instance,
    HINSTANCE,
    PWSTR,
    int showCommand
)
{
    SetProcessDPIAware();

    if (!IsAdministrator())
    {
        if (!RelaunchElevated())
        {
            MessageBoxW(
                nullptr,
                L"O Vistas Defender precisa de privilégios de administrador.",
                L"Vistas Defender",
                MB_OK | MB_ICONERROR
            );
        }

        return 0;
    }

    gInstance = instance;
    LoadSettings();

    CreateFonts();

    gWhiteBrush =
        CreateSolidBrush(
            COLOR_WHITE
        );

    gSidebarBrush =
        CreateSolidBrush(
            COLOR_SIDEBAR
        );

    WNDCLASSEXW windowClass{};
    windowClass.cbSize =
        sizeof(windowClass);

    windowClass.lpfnWndProc =
        WindowProcedure;

    windowClass.hInstance =
        instance;

    windowClass.hCursor =
        LoadCursorW(
            nullptr,
            IDC_ARROW
        );

    windowClass.hIcon =
        LoadIconW(
            nullptr,
            IDI_SHIELD
        );

    windowClass.hIconSm =
        LoadIconW(
            nullptr,
            IDI_SHIELD
        );

    windowClass.hbrBackground =
        gWhiteBrush;

    windowClass.lpszClassName =
        WINDOW_CLASS;

    if (!RegisterClassExW(
            &windowClass
        ))
    {
        MessageBoxW(
            nullptr,
            L"Falha ao registrar a janela.",
            L"Vistas Defender",
            MB_OK | MB_ICONERROR
        );

        DestroyFonts();

        DeleteObject(
            gWhiteBrush
        );

        DeleteObject(
            gSidebarBrush
        );

        return 1;
    }

    constexpr DWORD windowStyle =
        WS_OVERLAPPED |
        WS_CAPTION |
        WS_SYSMENU |
        WS_MINIMIZEBOX;

    constexpr DWORD extendedStyle = 0;

    int windowWidth = 0;
    int windowHeight = 0;

    AdjustWindowForClientSize(
        windowStyle,
        extendedStyle,
        WINDOW_CLIENT_WIDTH,
        WINDOW_CLIENT_HEIGHT,
        windowWidth,
        windowHeight
    );

    HWND window = CreateWindowExW(
        extendedStyle,
        WINDOW_CLASS,
        L"Vistas Defender 27K6",
        windowStyle,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        windowWidth,
        windowHeight,
        nullptr,
        nullptr,
        instance,
        nullptr
    );

    if (!window)
    {
        MessageBoxW(
            nullptr,
            L"Falha ao criar a janela.",
            L"Vistas Defender",
            MB_OK | MB_ICONERROR
        );

        DestroyFonts();

        DeleteObject(
            gWhiteBrush
        );

        DeleteObject(
            gSidebarBrush
        );

        return 1;
    }

    ShowWindow(
        window,
        showCommand
    );

    UpdateWindow(window);

    MSG message{};

    while (GetMessageW(
               &message,
               nullptr,
               0,
               0
           ) > 0)
    {
        TranslateMessage(
            &message
        );

        DispatchMessageW(
            &message
        );
    }

    DestroyFonts();

    if (gWhiteBrush)
        DeleteObject(gWhiteBrush);

    if (gSidebarBrush)
        DeleteObject(gSidebarBrush);

    return static_cast<int>(
        message.wParam
    );
}