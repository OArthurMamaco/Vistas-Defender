// ============================================================================
// Visne.cpp
// Feito por Arthur Carvalho Rodrigues da Silva
// Motor auxiliar do Vistas Defender
//
// Compatibilidade:
// - Windows 7 SP1 ou superior
// - Win32 puro
// - MSVC C++17 ou anterior
//
// Funções:
// - Carrega htlk.dll
// - Lê Updates\info_vacina.txt
// - Mantém regras de bloqueio em memória
// - Permite ao Defender consultar caminhos e processos
// ============================================================================

#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wintrust.h>
#include <softpub.h>
#include <wincrypt.h>

#include <string>
#include <vector>
#include <filesystem>
#include <cstring>
#include <fstream>
#include <algorithm>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "crypt32.lib")

// ============================================================================
// Estado interno
// ============================================================================

static HMODULE g_hModule = NULL;
static HMODULE g_hHtlk = NULL;

static CRITICAL_SECTION g_lock;
static BOOL g_lockInitialized = FALSE;
static BOOL g_initialized = FALSE;

static std::wstring g_baseDirectory;
static std::wstring g_updatesDirectory;
static std::wstring g_lastError;

static std::vector<std::wstring> g_blockedPatterns;

// ============================================================================
// Utilidades
// ============================================================================

static void SetLastErrorText(const std::wstring& message)
{
    if (g_lockInitialized)
        EnterCriticalSection(&g_lock);

    g_lastError = message;

    if (g_lockInitialized)
        LeaveCriticalSection(&g_lock);
}

static std::wstring GetModuleDirectory(HMODULE module)
{
    wchar_t path[MAX_PATH] = {};

    DWORD length = GetModuleFileNameW(module, path, MAX_PATH);

    if (length == 0 || length >= MAX_PATH)
        return L"";

    for (DWORD i = length; i > 0; --i)
    {
        if (path[i - 1] == L'\\' || path[i - 1] == L'/')
        {
            path[i - 1] = L'\0';
            break;
        }
    }

    return path;
}

static std::wstring CombinePath(
    const std::wstring& directory,
    const std::wstring& fileName)
{
    if (directory.empty())
        return fileName;

    if (directory[directory.length() - 1] == L'\\')
        return directory + fileName;

    return directory + L"\\" + fileName;
}

static std::wstring Trim(const std::wstring& value)
{
    size_t start = 0;
    size_t end = value.length();

    while (start < end)
    {
        wchar_t ch = value[start];

        if (ch != L' ' &&
            ch != L'\t' &&
            ch != L'\r' &&
            ch != L'\n')
        {
            break;
        }

        ++start;
    }

    while (end > start)
    {
        wchar_t ch = value[end - 1];

        if (ch != L' ' &&
            ch != L'\t' &&
            ch != L'\r' &&
            ch != L'\n')
        {
            break;
        }

        --end;
    }

    return value.substr(start, end - start);
}

static std::wstring ToLower(const std::wstring& value)
{
    std::wstring result = value;

    if (!result.empty())
    {
        CharLowerBuffW(
            &result[0],
            static_cast<DWORD>(result.length())
        );
    }

    return result;
}

static std::wstring MultiByteToWide(
    const std::string& text,
    UINT codePage)
{
    if (text.empty())
        return L"";

    int required = MultiByteToWideChar(
        codePage,
        0,
        text.c_str(),
        static_cast<int>(text.length()),
        NULL,
        0
    );

    if (required <= 0)
        return L"";

    std::wstring result;
    result.resize(required);

    MultiByteToWideChar(
        codePage,
        0,
        text.c_str(),
        static_cast<int>(text.length()),
        &result[0],
        required
    );

    return result;
}

static std::wstring ConvertTextLine(const std::string& line)
{
    if (line.empty())
        return L"";

    std::wstring converted = MultiByteToWide(line, CP_UTF8);

    if (!converted.empty())
        return converted;

    return MultiByteToWide(line, CP_ACP);
}

static BOOL DirectoryExists(const std::wstring& path)
{
    DWORD attributes = GetFileAttributesW(path.c_str());

    if (attributes == INVALID_FILE_ATTRIBUTES)
        return FALSE;

    return (attributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

static BOOL FileExists(const std::wstring& path)
{
    DWORD attributes = GetFileAttributesW(path.c_str());

    if (attributes == INVALID_FILE_ATTRIBUTES)
        return FALSE;

    return (attributes & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

// ============================================================================
// Leitura recursiva das atualizações
// ============================================================================

static bool HasControlCharacters(const std::wstring& value)
{
    for (wchar_t ch : value) {
        if (ch < 0x20 && ch != L'\t') return true;
    }
    return false;
}

static bool ReadVaccineFile(const std::wstring& filePath, std::vector<std::wstring>& output)
{
    std::error_code ec;
    const auto size = std::filesystem::file_size(filePath, ec);
    if (ec || size == 0 || size > 1024 * 1024) return false;

    std::ifstream file(filePath.c_str(), std::ios::binary);
    if (!file.is_open()) return false;

    const std::wstring prefix = L"bloquearcaminho:";
    std::vector<std::wstring> parsed;
    std::string line;
    size_t lineCount = 0;
    size_t recognizedCount = 0;
    while (std::getline(file, line)) {
        if (++lineCount > 10000 || line.size() > 4096) return false;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        std::wstring wideLine = Trim(ConvertTextLine(line));
        if (wideLine.empty()) continue;
        if (!wideLine.empty() && wideLine[0] == 0xFEFF) wideLine.erase(0, 1);
        const std::wstring lowerLine = ToLower(wideLine);
        if (lowerLine.compare(0, prefix.size(), prefix) != 0) continue;
        ++recognizedCount;
        std::wstring pattern = ToLower(Trim(wideLine.substr(prefix.size())));
        if (pattern.empty() || pattern.size() > 512 || HasControlCharacters(pattern)) return false;
        // Reject global kill-switch patterns; a manifest must not ban every executable.
        if (pattern == L"*" || pattern == L"*.*" || pattern == L"?" || pattern == L"**") return false;
        if (std::find(parsed.begin(), parsed.end(), pattern) == parsed.end()) parsed.push_back(std::move(pattern));
    }
    if (file.bad() || recognizedCount == 0 || parsed.empty()) return false;
    output.swap(parsed);
    return true;
}

static bool WildcardMatch(const std::wstring& pattern, const std::wstring& text)
{
    size_t p = 0, t = 0, star = std::wstring::npos, retry = 0;
    while (t < text.size()) {
        if (p < pattern.size() && (pattern[p] == L'?' || pattern[p] == text[t])) { ++p; ++t; continue; }
        if (p < pattern.size() && pattern[p] == L'*') { star = p++; retry = t; continue; }
        if (star != std::wstring::npos) { p = star + 1; t = ++retry; continue; }
        return false;
    }
    while (p < pattern.size() && pattern[p] == L'*') ++p;
    return p == pattern.size();
}

static bool HasWildcard(const std::wstring& value)
{
    return value.find_first_of(L"*?") != std::wstring::npos;
}

static bool IsPathRule(const std::wstring& value)
{
    return value.find_first_of(L"\\/:") != std::wstring::npos;
}

static bool IsTrustedHtlkSignature(const std::wstring& path)
{
    WINTRUST_FILE_INFO file{}; file.cbStruct = sizeof(file); file.pcwszFilePath = path.c_str();
    WINTRUST_DATA data{}; data.cbStruct = sizeof(data); data.dwUIChoice = WTD_UI_NONE;
    data.fdwRevocationChecks = WTD_REVOKE_NONE; data.dwUnionChoice = WTD_CHOICE_FILE;
    data.pFile = &file; data.dwStateAction = WTD_STATEACTION_VERIFY;
    data.dwProvFlags = WTD_CACHE_ONLY_URL_RETRIEVAL;
    GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    const LONG trust = WinVerifyTrust(nullptr, &action, &data);
    data.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(nullptr, &action, &data);
    if (trust != ERROR_SUCCESS) return false;

    HCERTSTORE store = nullptr; HCRYPTMSG message = nullptr;
    DWORD encoding = 0, contentType = 0, formatType = 0;
    if (!CryptQueryObject(CERT_QUERY_OBJECT_FILE, path.c_str(), CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED,
            CERT_QUERY_FORMAT_FLAG_BINARY, 0, &encoding, &contentType, &formatType, &store, &message, nullptr)) return false;
    bool valid = false;
    DWORD signerBytes = 0;
    if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, nullptr, &signerBytes)) {
        std::vector<BYTE> buffer(signerBytes);
        if (CryptMsgGetParam(message, CMSG_SIGNER_INFO_PARAM, 0, buffer.data(), &signerBytes)) {
            auto signer = reinterpret_cast<PCMSG_SIGNER_INFO>(buffer.data());
            if (signer->HashAlgorithm.pszObjId && strcmp(signer->HashAlgorithm.pszObjId, szOID_NIST_sha256) == 0) {
                CERT_INFO ci{}; ci.Issuer = signer->Issuer; ci.SerialNumber = signer->SerialNumber;
                PCCERT_CONTEXT cert = CertFindCertificateInStore(store, encoding, 0, CERT_FIND_SUBJECT_CERT, &ci, nullptr);
                if (cert) {
                    wchar_t publisher[512]{};
                    const DWORD n = CertGetNameStringW(cert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, nullptr, publisher, _countof(publisher));
                    valid = n > 1 && _wcsicmp(publisher, L"OArthurMamaco Security") == 0;
                    CertFreeCertificateContext(cert);
                }
            }
        }
    }
    if (store) CertCloseStore(store, 0);
    if (message) CryptMsgClose(message);
    return valid;
}


// ============================================================================
// htlk.dll
// ============================================================================

static BOOL LoadHtlk()
{
    if (g_hHtlk)
        return TRUE;

    std::wstring htlkPath = CombinePath(
        g_baseDirectory,
        L"htlk.dll"
    );

    if (!FileExists(htlkPath))
    {
        SetLastErrorText(
            L"A dependência htlk.dll não foi encontrada."
        );

        return FALSE;
    }

    if (!IsTrustedHtlkSignature(htlkPath))
    {
        SetLastErrorText(L"htlk.dll não passou pela validação Authenticode/publicador/SHA-256.");
        return FALSE;
    }

    // Carrega exatamente a DLL indicada, sem ampliar o caminho de busca.
    g_hHtlk = LoadLibraryExW(
        htlkPath.c_str(),
        NULL,
        LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR |
        LOAD_LIBRARY_SEARCH_DEFAULT_DIRS
    );

    if (!g_hHtlk)
    {
        SetLastErrorText(
            L"Não foi possível carregar htlk.dll."
        );

        return FALSE;
    }

    return TRUE;
}

// ============================================================================
// API exportada
// ============================================================================

extern "C" __declspec(dllexport)
BOOL WINAPI Visne_Initialize(const wchar_t* productDirectory)
{
    if (g_initialized)
        return TRUE;

    if (productDirectory && productDirectory[0] != L'\0')
        g_baseDirectory = productDirectory;
    else
        g_baseDirectory = GetModuleDirectory(g_hModule);

    if (g_baseDirectory.empty())
    {
        SetLastErrorText(
            L"Não foi possível determinar o diretório da Visne.dll."
        );

        return FALSE;
    }

    g_updatesDirectory = CombinePath(
        g_baseDirectory,
        L"Updates"
    );

    if (!LoadHtlk())
        return FALSE;

    g_initialized = TRUE;
    SetLastErrorText(L"");

    return TRUE;
}

extern "C" __declspec(dllexport)
BOOL WINAPI Visne_ReloadUpdates()
{
    if (!g_initialized) {
        SetLastErrorText(L"A Visne.dll ainda não foi inicializada.");
        return FALSE;
    }
    if (!DirectoryExists(g_updatesDirectory)) {
        SetLastErrorText(L"A pasta Updates não foi encontrada; regras antigas foram preservadas.");
        return FALSE;
    }
    const std::wstring manifest = CombinePath(g_updatesDirectory, L"info_vacina.txt");
    if (!FileExists(manifest)) {
        SetLastErrorText(L"Manifesto info_vacina.txt ausente; regras antigas foram preservadas.");
        return FALSE;
    }

    std::vector<std::wstring> stagedRules;
    if (!ReadVaccineFile(manifest, stagedRules)) {
        SetLastErrorText(L"Manifesto inválido, vazio, excessivo ou sem regras reconhecidas; regras antigas foram preservadas.");
        return FALSE;
    }

    EnterCriticalSection(&g_lock);
    g_blockedPatterns.swap(stagedRules);
    LeaveCriticalSection(&g_lock);
    SetLastErrorText(L"");
    return TRUE;
}

extern "C" __declspec(dllexport)
BOOL WINAPI Visne_IsBlocked(const wchar_t* processNameOrPath)
{
    if (!g_initialized ||
        !processNameOrPath ||
        processNameOrPath[0] == L'\0')
    {
        return FALSE;
    }

    const std::wstring candidate = ToLower(processNameOrPath);
    const std::wstring basename = ToLower(std::filesystem::path(candidate).filename().wstring());
    BOOL blocked = FALSE;

    EnterCriticalSection(&g_lock);
    for (const std::wstring& pattern : g_blockedPatterns) {
        if (pattern.empty()) continue;
        if (HasWildcard(pattern)) {
            const bool pathPattern = IsPathRule(pattern);
            if (WildcardMatch(pattern, pathPattern ? candidate : basename)) { blocked = TRUE; break; }
        } else if (IsPathRule(pattern)) {
            std::wstring normalizedCandidate = std::filesystem::path(candidate).lexically_normal().wstring();
            std::wstring normalizedPattern = std::filesystem::path(pattern).lexically_normal().wstring();
            if (normalizedCandidate == normalizedPattern) { blocked = TRUE; break; }
        } else if (basename == pattern) {
            blocked = TRUE; break;
        }
    }
    LeaveCriticalSection(&g_lock);
    return blocked;
}

extern "C" __declspec(dllexport)
DWORD WINAPI Visne_GetRuleCount()
{
    if (!g_initialized)
        return 0;

    EnterCriticalSection(&g_lock);

    DWORD count = static_cast<DWORD>(
        g_blockedPatterns.size()
    );

    LeaveCriticalSection(&g_lock);

    return count;
}

extern "C" __declspec(dllexport)
BOOL WINAPI Visne_GetLastErrorText(
    wchar_t* output,
    DWORD outputCharacters)
{
    if (!output || outputCharacters == 0)
        return FALSE;

    EnterCriticalSection(&g_lock);

    lstrcpynW(
        output,
        g_lastError.c_str(),
        static_cast<int>(outputCharacters)
    );

    LeaveCriticalSection(&g_lock);

    return TRUE;
}

extern "C" __declspec(dllexport)
void WINAPI Visne_Shutdown()
{
    if (!g_initialized && !g_hHtlk)
        return;
    g_initialized = FALSE; // Caller must stop concurrent API calls before shutdown.

    EnterCriticalSection(&g_lock);
    g_blockedPatterns.clear();
    LeaveCriticalSection(&g_lock);

    if (g_hHtlk)
    {
        FreeLibrary(g_hHtlk);
        g_hHtlk = NULL;
    }

    g_baseDirectory.clear();
    g_updatesDirectory.clear();
}

// ============================================================================
// Entrada da DLL
// ============================================================================

BOOL WINAPI DllMain(
    HINSTANCE hInstance,
    DWORD reason,
    LPVOID reserved)
{
    UNREFERENCED_PARAMETER(reserved);

    switch (reason)
    {
        case DLL_PROCESS_ATTACH:
        {
            g_hModule = hInstance;

            InitializeCriticalSection(&g_lock);
            g_lockInitialized = TRUE;

            DisableThreadLibraryCalls(hInstance);
            break;
        }

        case DLL_PROCESS_DETACH:
        {
            // Não chamamos FreeLibrary dentro do DllMain.
            // O Defender deve executar Visne_Shutdown antes de descarregar.

            if (g_lockInitialized)
            {
                DeleteCriticalSection(&g_lock);
                g_lockInitialized = FALSE;
            }

            break;
        }
    }

    return TRUE;
}